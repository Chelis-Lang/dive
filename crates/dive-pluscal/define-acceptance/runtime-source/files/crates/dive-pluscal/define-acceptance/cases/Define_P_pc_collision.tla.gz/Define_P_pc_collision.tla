---- MODULE Define_P_pc_collision ----
EXTENDS Naturals, Integers, Sequences, TLC
(*
--algorithm A
 variables x=0, y=0;
 define
 pc == 1
 end define;
begin L: x := pc; end algorithm;
*)
====
