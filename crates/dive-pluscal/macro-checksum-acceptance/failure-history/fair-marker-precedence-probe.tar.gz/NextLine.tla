---- MODULE NextLine ----
EXTENDS Integers
(* --fair algorithm A { variable x = 0; { L: x := 1; } }
--algorithm B { variable x = 0; { L: x := 2; } } *)
====
