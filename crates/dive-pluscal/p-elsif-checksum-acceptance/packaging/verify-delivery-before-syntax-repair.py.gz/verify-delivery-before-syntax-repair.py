#!/usr/bin/env python3
"""Read all portable P-elsif source/runtime bytes; preserve stage qualifications."""
import argparse,base64,gzip,hashlib,json,re
from collections import Counter
from pathlib import Path,PurePosixPath
HERE=Path(__file__).resolve().parent
SOURCE='37ace0360d4d9ae89f358161602f71898178b793'
def need(v,m):
 if not v:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def rel(n):
 p=PurePosixPath(n);need(not p.is_absolute() and '..'not in p.parts,'unsafe path');return p.as_posix()
def verify(base=HERE,binaries=None):
 d=json.loads((base/'delivery.json').read_bytes());need(d['source_commit']==SOURCE and d['all_consumers_closed'] and d['family_certified']is False and d['model_proved']is False,'qualification')
 raw=(base/rel(d['records_archive'])).read_bytes();need(sha(raw)==d['records_archive_sha256'],'pack identity');records={};size=0
 for row in json.loads(gzip.decompress(raw)):
  n=rel(row['path']);need(n not in records,'duplicate record');b=base64.b64decode(row['data'],validate=True);need(sha(b)==row['sha256']==d['files_sha256'].get(n),'record changed:'+n);records[n]=b;size+=len(b)
 need(set(records)==set(d['files_sha256']) and len(records)==d['records_count'] and size==d['raw_bytes'],'complete census')
 def doc(n):return json.loads(records[rel(n)])
 def packed(n):return gzip.decompress(records[rel(n)])
 producer=doc('native-first/producer.json');need(producer['source_commit']==SOURCE and len(producer['inputs'])==7291,'source authority')
 for n,e in producer['inputs'].items():need(sha(packed('native-first/'+rel(e['archive'])))==e['sha256'],'source archive:'+n)
 need(d['binary_sha256']==producer['binaries_sha256'],'binary authority')
 if binaries:
  for n,s in d['binary_sha256'].items():need(sha((binaries/rel(n)).read_bytes())==s,'binary changed:'+n)
 prefix='crates/dive-pluscal/p-elsif-checksum-acceptance/';old='crates/dive-pluscal/nested-procedure-checksum-acceptance/'
 def source(n):return packed('native-first/source/'+rel(n)+'.gz')
 def raw_report(name,scope,total,summary):
  report=doc('native-first/'+name+'/report.json');need(report['selected']==len(report['rows'])==total and report['summary']==summary and report['family_certified']is False,'raw census:'+name)
  primary=json.loads(source(scope+'primary/manifest.json'));references={r['id']:r for r in primary['rows']};need(set(references)=={r['id']for r in report['rows']},'raw selection:'+name)
  for r in report['rows']:
   o=r['document'];need(o['model_proved']is False and o['artifact_admitted']is False and o.get('exhaustive',False)is False,'raw false proof')
   if r['outcome']in ['exact-raw-ast','primary-invalid-raw-uncredited']:
    crc=o['checksum']['Ok'];need(crc['serialized_ast'].encode()==source(scope+'primary/'+r['id']+'.translated.ast') and crc['checksum']==references[r['id']]['stages']['translated']['crc'],'raw byte/CRC')
   else:need(r['outcome']in ['named-refusal','rejection-accounted'],'raw outcome')
 raw_report('raw-new',prefix,32,{'exact-raw-ast':32})
 raw_report('raw-original',old,180,{'exact-raw-ast':137,'primary-invalid-raw-uncredited':2,'named-refusal':24,'rejection-accounted':17})
 raw_report('raw-while-tail',old+'while-tail/',4,{'exact-raw-ast':4})
 raw_report('raw-while-lines',old+'while-lines/',8,{'exact-raw-ast':8})
 def public(name,total,summary):
  folder='native-first/'+name+'/';report=doc(folder+'report.json');need(report['selected']==len(report['rows'])==total and report['summary']==summary and report['model_proved']is False and report['family_certified']is False,'public census:'+name)
  for r in report['rows']:
   data=packed(folder+r['id']+'.native.stdout.gz');o=json.loads(data);need(sha(data)==r['native']['stdout_sha256'] and o['profile']==r['profile'] and o['model_proved']is False and o['exhaustive']is False and o['result']!='internal-error' and o['exit_code']==r['native']['exit_code'],'public claims')
   if r['outcome']=='admitted-exact-cst-sany-validator':
    need(o['accepted'] and o['exit_code']==0 and o['result']=='replacement' and o['algorithm_checksum_verified']is True and o['body_checksum_verified']is True,'admission')
    need(o['translation_options']==o['option_context']['effective'] and o['requested_translation_options']==o['option_context']['requested'],'effective context')
    l=json.loads(packed(folder+r['id']+'.native-cst.stdout.gz'));rr=json.loads(packed(folder+r['id']+'.primary-cst.stdout.gz'));need(l['accepted'] and rr['accepted'] and l['tree']==rr['tree'],'whole CST')
    for tag in ['native','primary']:need(b'Semantic errors:'not in packed(folder+r['id']+'.'+tag+'-sany.stdout.gz'),'SANY')
    need('NO_DIVERGENCE'in r['validator']['configured'],'Validator')
   else:need(not o['accepted'] and o['exit_code']in [1,3] and o['result']in ['unsupported','rejected'] and 'replacement'not in o,'unsupported falsely admitted')
 public('public-new',64,{'admitted-exact-cst-sany-validator':64})
 public('public-original',360,{'admitted-exact-cst-sany-validator':274,'rejection-accounted':38,'named-public-refusal':36,'invalid-primary-uncredited':12})
 public('public-while-tail',8,{'admitted-exact-cst-sany-validator':8})
 public('public-while-lines',16,{'admitted-exact-cst-sany-validator':8,'named-public-refusal':8})
 first=doc('native-first/campaign.json');need(not first['passed'] and first['source_commit']==SOURCE and len(first['completed'])==10 and all(r['exit_code']==0for r in first['completed'][:-1]) and first['completed'][-1]['exit_code']!=0,'original driver failure preserved')
 repair=doc('verification-driver-repair/delta.json');before=records['verification-driver-repair/replay-before.py'];after=records['verification-driver-repair/replay-corrected.py'];need(sha(before)==repair['before_sha256'] and sha(after)==repair['after_sha256'] and after==before.replace(b"A/'models'",b'a.models') and repair['tracked_source_unchanged'],'verification repair scope')
 remainder=doc('native-first/campaign-remainder.json');need(remainder['source_commit']==SOURCE and remainder['passed'] and len(remainder['completed'])==8 and all(r['exit_code']==0 for r in remainder['completed']),'complete repaired campaign')
 gate=doc('full-gate-first/report.json');need(gate['source_commit']==SOURCE and gate['passed'] and gate['all_stages']==len(gate['completed'])==51 and all(r['exit_code']==0 for r in gate['completed']),'full gate')
 logs=records['full-gate-first/45.log'];need(re.search(rb'1189 tests run:\s*1189 passed,\s*0 skipped',logs),'nextest complete inventory')
 for name in ['models-new','models-original']:
  root='native-first/'+name+'/';m=doc(root+'report.json');need(m['selected']==len(m['rows'])==64 and m['worker_store_controls']==768 and not m['family_certified'],'finite selected settings')
  for r in m['rows']:
   need(len(r['settings'])==12 and r['outcome']=='finite-model-match','finite row')
   for setting in r['settings']:
    capture=setting['capture'];o=json.loads(packed(root+capture['stdout']['path']));violation=r['id'].endswith('.violation');need(o['verdict']==('invariant-violation'if violation else'success') and all(o['statistics'][k]==v for k,v in r['primary_counts'].items()) and o['exit_code']==capture['exit_code']==((12 if setting['profile']=='tlc'else10)if violation else0),'model class/count/exit')
   for v in r['independent_validation']:
    o=json.loads(packed(root+v['capture']['stdout']['path']));need((o['result']=='valid'if v['outcome']=='valid'else o['result']!='valid'),'independent witness')
 for name in ['replay-new-repaired','replay-original']:
  root='native-first/'+name+'/';m=doc(root+'report.json');need(m['selected']==len(m['rows'])==320 and m['qualified_canonical_is_not_tlc_validation'] and not m['family_certified'],'replay scope')
  for r in m['rows']:
   o=json.loads(packed(root+r['id']+'.stdout.gz'));need(o['result']==r['actual_result'] and o['exit_code']==r['exit_code'] and sha(packed(root+r['id']+'.stdout.gz'))==r['stdout_sha256'],'replay byte claims')
   if r['control']!='original':need(o['result']!='valid','mutant falsely validated')
 guides=doc('native-first/guides-final/report.json');need(guides['selected']==len(guides['rows'])==20 and all(r['outcome']=='executed-guide-match'for r in guides['rows']),'actual guides')
 crc=doc('native-first/crc/report.json');need(crc['selected']==len(crc['rows'])==24 and all(r['model_proved']is False and r['outcome']in ['valid-unchanged','corruption-refused']for r in crc['rows']),'CRC controls')
 forged=doc('native-first/forgeries/report.json');need(forged['selected']==28 and forged['genuine_controls']==4 and forged['forged_controls']==24 and all(r['exit_code']==int(r['mutation']!='baseline')for r in forged['rows']),'forgeries')
 return {'records':len(records),'source_inputs':7291,'gate_tests':1189,'public_rows':448,'raw_rows':224,'model_settings':1536,'family_certified':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=HERE);p.add_argument('--binaries',type=Path);a=p.parse_args()
 try:print(json.dumps(verify(a.base,a.binaries),sort_keys=True))
 except (ValueError,KeyError,TypeError,AssertionError,FileNotFoundError)as error:raise SystemExit('P elsif delivery verification failed: '+str(error))
