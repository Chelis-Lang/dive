---- MODULE Forms_P_local_chain ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 LOCAL G(a)==a+1 LOCAL F(a)==G(a)
 end define;
begin L:y:=F(x); E:skip;
end algorithm;
*)
\* BEGIN TRANSLATION (chksum(pcal) = "7839a02d" /\ chksum(tla) = "bf14963")
VARIABLES pc, x, y

(* define statement *)
LOCAL G(a)==a+1 LOCAL F(a)==G(a)


vars == << pc, x, y >>

Init == (* Global variables *)
        /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = F(x)
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")

\* END TRANSLATION 
====
