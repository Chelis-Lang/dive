# LOCAL/function DEFINE evidence

The complete selection retains all136 original DEFINE rows plus98 paired C/P
delta rows. LOCAL ordinary helpers, function/LOCAL function/tuple/multiple
bounds, dependency domains, pre-state lookup, process contexts, layouts,
recursive/action/temporal/name/unknown boundaries and invalid primary outputs
stay separately accounted. No family is certified by this bounded increment.

The first native raw234-row run yields152 exact AST/CRC,28 primary-invalid raw
outputs kept uncredited,52 named refusals and2 accounted primary rejections.
Four existing Context_C/P_local and Context_C/P_function_definition rows are
new exact matches; all other historical comparisons remain unchanged.

Two original fixture filename captures are preserved. They failed SANY because
the temporary filename did not match the module name; they are test-fixture
failures, not upstream bugs. The complete corrected98 capture has80SANYvalid
modules and18invalid primary artifacts. Those18 never earn public admission.

verify.py reads every original+delta raw source/stage/stream identity.
compare.py checks234 raw rows; public-controls.py compares all468 profile rows
through actual CLI, whole-module CST, SANY and configured/unconfigured Validator.
models.py supplies independent finite count/witness/mutant controls; guides.py
and checksum-controls.py execute the actual Markdown/Cargo examples and corrupt
CRC controls. Campaign dispositions and source-bound receipts are retained in
reports/ after closure. Generation, admission, reference CRC derivation and
model proof remain distinct. See docs/pluscal-definition-forms.md and ADR0056.
