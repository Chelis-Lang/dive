//! `dive-compile`: Compilation of specifications to native code. It must pass the same conformance suite as interpreted checking.
//!
//! Status: placeholder. See `docs/ROADMAP.md` for when this crate is built
//! and `docs/CHARTER.md` for its responsibilities. Permitted internal
//! dependencies are listed in `xtask/src/layering.rs`.
#![forbid(unsafe_code)]
