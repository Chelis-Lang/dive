from pathlib import Path
import re,json,hashlib
root=Path('/Users/jeff/code/dive-native-operator-integration-work');out=Path('/tmp/dive-ci-matrix-splitting')
# Preserve strings/character tokens verbatim; discard only Rust whitespace/comments.
token=re.compile(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'[^\'\n]*\'|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[^\s]',re.S)
def tokens(s):return [m[0] for m in token.finditer(s) if not m[0].startswith(('//','/*'))]
def body(s,name):
 a=s.index('fn '+name+'(');a=s.index('{',a);ts=tokens(s[a:]);depth=0
 for i,t in enumerate(ts):
  depth+=int(t=='{')-int(t=='}')
  if depth==0:return ts[:i+1]
 raise AssertionError(name)
rows=[]
for stem,names,loop in [('storage_tuple_function',['verify','witness','independent','observable','storage'],13),('native_checkpoint_spill',['recovery_case','storage','observable'],19),('view_normalization',['verify','observables'],19)]:
 old=(out/(stem+'.before.rs')).read_text();new=(root/f'crates/dive-api/tests/{stem}.rs').read_text()
 normalized=new.replace('for &store in stores {','for store in [Store::Fingerprint, Store::Exact] {') if stem!='view_normalization' else new
 normalized=normalized.replace('for &workers in widths {','for workers in [1, 4, 8] {').replace('for &chaos in schedules {',f'for chaos in [None, Some({loop})] {{')
 for name in names:assert body(old,name)==body(normalized,name),(stem,name)
 # Confirm the old source/profile/store/spill declarations exactly match new macros.
 if stem=='storage_tuple_function':
  before=re.findall(r'fn (apply_tlc|apply_dive|witness_tlc|witness_dive)\(\) \{\s*verify\("(\w+)", (true|false)\);',old)
  after=re.findall(r'controls!\(\s*((?:apply|witness)_(?:tlc|dive)),\s*"(\w+)",\s*(true|false)\s*\);',new)
 elif stem=='native_checkpoint_spill':
  before=re.findall(r'fn (cp\w+_spill_recovery)\(\) \{\s*recovery_case\("(\w+)", &\[(false|true)\], ([123])\);',old)
  after=re.findall(r'controls!\(\s*(cp\w+_spill_recovery),\s*"(\w+)",\s*(false|true),\s*([123])\s*\);',new)
 else:
  pattern=r'controls!\(\s*(\w+),\s*("(?:[^"\\]|\\.)*"),\s*(true|false),\s*Store::(Fingerprint|Exact)\s*\);'
  before=re.findall(pattern,old);after=re.findall(pattern,new)
 assert before==after and len(before)>0,(stem,before,after)
 rows.append({'file':stem,'all_original_declarations_retained':len(before),'unchanged_helper_bodies':names,'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest()})
(out/'token-audit.json').write_text(json.dumps({'original_commit':'c0d8e1a54111449afd87245951695f652e4a7d8f','rows':rows,'comparison':'Rust token equality after only explicit loop-selector substitutions; no assertion/count/word/filter changes'},indent=2)+'\n')
print('All original helpers, declarations and assertions preserved')
