from pathlib import Path
import gzip,hashlib,io,json,re,tarfile,subprocess
root=Path('/Users/jeff/code/dive-native-operator-integration-work');epoch=Path('/tmp/dive-ci16-qualified-epoch')
sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads((epoch/'source-index.json').read_text());gate=json.loads((epoch/'gate-receipt.json').read_text());producer=source['producer']
assert producer=='3dcabae15a7dbfcbd093cc1eb654beeaf693addf'
assert gate['producer']==producer and gate['source_index_sha256']==sha((epoch/'source-index.json').read_bytes())
assert len(gate['rows'])==72 and all(row['exit']==0 for row in gate['rows'])
for row in gate['rows']:assert row['log_sha256']==sha((epoch/(row['name']+'.log')).read_bytes()),row['name']
m=re.search(r'(\d+) tests run:\s*(\d+) passed(?: \(\d+ slow\))?, (\d+) skipped',(epoch/'stage-2.log').read_text());assert m and tuple(map(int,m.groups()))==(1648,1648,0)
census=json.loads((epoch/'offline-62.log').read_text().splitlines()[-1]);assert census['selected_tests']==1648 and census['ignored_tests']==0 and census['disjoint_and_complete'] and len(census['hash_partitions'])==16 and sum(census['hash_partitions'])==1648
assert census['rejected_workflow_mutants']==3
for rel,row in source['inputs'].items():assert sha(gzip.decompress((epoch/row['archive']).read_bytes()))==row['sha256']
compiled=source['compiled_rust_sources'];previous='d21ea2c699c6514f61038c6fe8205219b83fa2f5'
for rel in compiled+[r for r in source['inputs'] if r.endswith('Cargo.toml') or r in ['Cargo.lock','rust-toolchain.toml']]:
 old=subprocess.check_output(['git','show',previous+':'+rel],cwd=root)
 assert old==gzip.decompress((epoch/source['inputs'][rel]['archive']).read_bytes()),rel
out=Path('/tmp/dive-ci16-package')/producer;out.mkdir(parents=True,exist_ok=False);archives={}
def pack(name,files):
 stream=io.BytesIO()
 with tarfile.open(fileobj=stream,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for rel,path in sorted(files.items()):
   data=path.read_bytes();info=tarfile.TarInfo(rel);info.mode=0o644;info.mtime=0;info.size=len(data);tar.addfile(info,io.BytesIO(data))
 data=gzip.compress(stream.getvalue(),mtime=0);(out/name).write_bytes(data);archives[name]={'sha256':sha(data),'members_sha256':{rel:sha(path.read_bytes()) for rel,path in sorted(files.items())}}
pack('source-and-gate.tar.gz',{str(p.relative_to(epoch)):p for p in epoch.rglob('*') if p.is_file()})
pack('capture-driver.tar.gz',{n:Path('/tmp')/n for n in ['dive-ci16-full-gate.py','dive-package-ci16-gate.py','dive-ci16-root-readback.py']})
index={'schema_version':1,'producer':producer,'source_tree':source['tree'],'all_consumers_closed':True,'source_inputs':len(source['inputs']),'gate_commands':72,'literal_ci_python_commands':64,'workspace_tests':1648,'skipped_tests':0,'ci_partitions':16,'family_certified':False,'archives':archives,'unchanged_compiled_producer':previous,'production_runtime_producer':'05b3a1ef498ea1609c0413383b81bebb1b411749','new_runtime_reexecution_claim':False,'scope':'Scheduling-only CI qualification; selected source archive, not hermetic environment/compiler closure. Native runtime and matrix-splitting qualification retain original producers.'}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'out':str(out),'index_sha256':sha((out/'index.json').read_bytes())},indent=2))
