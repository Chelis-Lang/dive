from pathlib import Path
import subprocess,json,hashlib,gzip,re,posixpath,os,time
root=Path('/Users/jeff/code/dive-native-operator-integration-work')
out=Path('/tmp/dive-ci16-qualified-epoch');out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
run=lambda args:subprocess.check_output(([args[0],'--no-optional-locks']+args[1:]) if args[0]=='git' else args,cwd=root,text=True).strip()
producer=run(['git','rev-parse','HEAD']);tree=run(['git','rev-parse','HEAD^{tree}'])
assert run(['git','status','--porcelain'])==''
tracked=set(run(['git','ls-files']).splitlines());compiled={n for n in tracked if n.endswith('.rs') and (re.match(r'^crates/[^/]+/(src|tests|examples|benches)/',n) or n.startswith('xtask/src/') or re.match(r'^crates/[^/]+/build\.rs$',n))}
paths=compiled|{n for n in tracked if n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','clippy.toml','deny.toml','.config/nextest.toml','AGENTS.md','.github/workflows/ci.yml','.cargo/config.toml','.rustfmt.toml','rustfmt.toml'] or (n.startswith(('scripts/','docs/')) and n.endswith(('.py','.sh','.md'))) or (n.endswith('Cargo.toml') and n.startswith(('crates/','xtask/')))}
references=[]
for rel in sorted(compiled):
 text=(root/rel).read_text();matches=list(re.finditer(r'\b(include_str|include_bytes|include)!\s*\(\s*"([^"\\]+)"\s*\)',text));assert len(matches)==len(list(re.finditer(r'\b(?:include_str|include_bytes|include)!\s*\(',text))),rel
 for m in matches:
  target=posixpath.normpath(str(Path(rel).parent/m[2]));assert target in tracked and not target.startswith('../'),target
  paths.add(target);references.append({'source':rel,'macro':m[1],'literal':m[2],'target':target})
current=json.loads((root/'conformance/probes/native-parity-integration/current-source.json').read_text());outputs=set(current['generated_manifest_paths']);paths|=outputs
paths.update(str(p.relative_to(root)) for p in (root/'conformance/probes/ci-storage-matrices').iterdir() if p.is_file())
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);inputs={}
for rel in sorted(paths):
 data=(root/rel).read_bytes();proc.stdin.write((producer+':'+rel+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().split();assert header[1]==b'blob';git=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n' and git==data,rel
 target=out/'source'/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));inputs[rel]={'sha256':sha(data),'archive':str(target.relative_to(out))}
proc.stdin.close();assert proc.wait()==0
for r in references:r['sha256']=inputs[r['target']]['sha256']
source={'producer':producer,'tree':tree,'inputs':inputs,'compiled_rust_sources':sorted(compiled),'embedded_references':references,'scope':'Current combined receiving Rust/Cargo, explicit literal embedded inputs, CI/toolchain configuration and user/developer guides. Selected source archive; not a hermetic dependency/compiler/environment bundle. Historical component receipts retain their own producers.','family_certified':False}
(out/'source-index.json').write_text(json.dumps(source,indent=2)+'\n');print('Frozen',producer,len(inputs),'inputs',len(references),'literal sites',flush=True)
def unchanged():
 assert run(['git','rev-parse','HEAD'])==producer
 for rel,row in inputs.items():assert sha((root/rel).read_bytes())==row['sha256'],rel
 unchanged_status=run(['git','status','--porcelain']);assert not unchanged_status,unchanged_status[:1000]
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache','RUST_TEST_THREADS':'2'}
rows=[]
def execute(name,command,extra=None):
 unchanged();start=time.monotonic();log=out/(name+'.log')
 with log.open('wb') as output:r=subprocess.run(command,cwd=root,env={**env,**(extra or {})},stdout=output,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(log.read_bytes())};rows.append(row);(out/'gate-receipt.json').write_text(json.dumps({'producer':producer,'source_index_sha256':sha((out/'source-index.json').read_bytes()),'jobs':2,'test_threads':2,'profile':'ci','family_certified':False,'rows':rows},indent=2)+'\n');print(name,r.returncode,flush=True);unchanged()
 if r.returncode:raise SystemExit(r.returncode)
import shlex
commands=[shlex.split(line[line.index('python3'):].strip()) for line in (root/'.github/workflows/ci.yml').read_text().splitlines() if re.search(r'(?:^\s*|run:\s*)python3(?:\s|$)',line)]
assert len(commands)==64,len(commands)
(out/'offline-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for i,command in enumerate(commands):execute('offline-'+str(i),command)
stages=[['cargo','fmt','--all','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','nextest','run','--workspace','--locked','--profile','ci','--test-threads','2'],['cargo','test','--workspace','--doc','--locked'],['cargo','doc','--workspace','--no-deps','--locked'],['cargo','xtask','check-layering'],['cargo','build','-p','dive-trace','--locked'],['cargo','deny','--locked','check']]
for i,command in enumerate(stages):execute('stage-'+str(i),command,{'RUSTDOCFLAGS':'-D warnings'} if i==4 else None)
print('Full combined receiving gate closed',flush=True)
