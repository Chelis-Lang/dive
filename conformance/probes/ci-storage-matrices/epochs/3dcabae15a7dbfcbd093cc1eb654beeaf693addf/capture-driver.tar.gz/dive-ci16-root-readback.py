from pathlib import Path
import copy,gzip,hashlib,io,json,re,shlex,subprocess,sys,tarfile
ROOT=Path('/Users/jeff/code/dive-native-operator-integration-work')
PRODUCER='3dcabae15a7dbfcbd093cc1eb654beeaf693addf';OLD='d21ea2c699c6514f61038c6fe8205219b83fa2f5';RUNTIME='05b3a1ef498ea1609c0413383b81bebb1b411749'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):
 ix=json.loads((path/'index.json').read_bytes());packets={}
 for name,row in ix['archives'].items():
  data=(path/name).read_bytes();assert sha(data)==row['sha256']
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
   ms=t.getmembers();assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in ms)
   assert len({m.name for m in ms})==len(ms);p={m.name:t.extractfile(m).read() for m in ms}
  assert {n:sha(b) for n,b in p.items()}==row['members_sha256'];packets[name]=p
 return ix,packets
def check(ix,p,git=False):
 assert ix['producer']==PRODUCER and ix['family_certified'] is False and ix['all_consumers_closed'] is True
 assert ix['unchanged_compiled_producer']==OLD and ix['production_runtime_producer']==RUNTIME and ix['new_runtime_reexecution_claim'] is False
 assert (ix['source_inputs'],ix['gate_commands'],ix['literal_ci_python_commands'],ix['workspace_tests'],ix['skipped_tests'],ix['ci_partitions'])==(857,72,64,1648,0,16)
 pack=p['source-and-gate.tar.gz'];src=json.loads(pack['source-index.json']);gate=json.loads(pack['gate-receipt.json'])
 assert src['producer']==gate['producer']==PRODUCER and src['tree']==ix['source_tree']
 assert gate['source_index_sha256']==sha(pack['source-index.json']) and len(src['inputs'])==857 and len(src['compiled_rust_sources'])==479 and len(src['embedded_references'])==70
 assert gate['jobs']==gate['test_threads']==2 and gate['profile']=='ci' and gate['family_certified'] is False
 assert len(gate['rows'])==72 and [r['name'] for r in gate['rows']]==['offline-'+str(i) for i in range(64)]+['stage-'+str(i) for i in range(8)]
 assert all(r['exit']==0 and r['log_sha256']==sha(pack[r['name']+'.log']) for r in gate['rows'])
 match=re.search(r'(\d+) tests run:\s*(\d+) passed(?: \(\d+ slow\))?, (\d+) skipped',pack['stage-2.log'].decode());assert match and tuple(map(int,match.groups()))==(1648,1648,0)
 decoded={}
 for name,row in src['inputs'].items():
  b=gzip.decompress(pack[row['archive']]);assert sha(b)==row['sha256'];decoded[name]=b
  if git:assert subprocess.check_output(['git','show',PRODUCER+':'+name],cwd=ROOT)==b,name
 for r in src['embedded_references']:assert sha(decoded[r['target']])==r['sha256']
 if git:
  for n in src['compiled_rust_sources']+[n for n in decoded if n.endswith('Cargo.toml') or n in ['Cargo.lock','rust-toolchain.toml']]:assert subprocess.check_output(['git','show',OLD+':'+n],cwd=ROOT)==decoded[n],n
 ci=decoded['.github/workflows/ci.yml'].decode()
 matrix=re.search(r'^        partition: \[([^\]\n]+)\]$',ci,re.M);assert matrix and [int(x.strip()) for x in matrix[1].split(',')]==list(range(1,17))
 assert '--partition hash:${{ matrix.partition }}/16' in ci
 commands=[shlex.split(line[line.index('python3'):].strip()) for line in ci.splitlines() if re.search(r'(?:^\s*|run:\s*)python3(?:\s|$)',line)]
 assert len(commands)==64 and json.loads(pack['offline-commands.json'])==commands and [r['command'] for r in gate['rows'][:64]]==commands
 rust_commands=[['cargo','fmt','--all','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','nextest','run','--workspace','--locked','--profile','ci','--test-threads','2'],['cargo','test','--workspace','--doc','--locked'],['cargo','doc','--workspace','--no-deps','--locked'],['cargo','xtask','check-layering'],['cargo','build','-p','dive-trace','--locked'],['cargo','deny','--locked','check']]
 assert [r['command'] for r in gate['rows'][64:]]==rust_commands

 census=json.loads(pack['offline-62.log'].decode().splitlines()[-1]);assert census['selected_tests']==1648 and census['ignored_tests']==0 and census['disjoint_and_complete'] is True
 assert len(census['hash_partitions'])==16 and sum(census['hash_partitions'])==1648 and census['rejected_workflow_mutants']==3
 policy=json.loads(decoded['conformance/probes/ci-storage-matrices/selection.json']);assert (policy['matrix_tests_before'],policy['matrix_tests_after'],policy['inner_cases'])==(34,336,768)
 assert census['preserved_matrix_cases']==336 and census['rejected_matrix_mutants']==9
 declaration=json.loads(decoded['conformance/probes/ci-storage-matrices/parallelism-16.json']);assert declaration['new_ci_partitions']==16
 return {'producer':PRODUCER,'selected_inputs':857,'literal_sites':70,'tests':1648,'ci_partitions':16,'gate_commands':72,'family_certified':False}
if __name__=='__main__':
 ix,p=read(Path(sys.argv[1]));result=check(ix,p,git=True);rejected=[]
 for case in ['family','unfinished','runtime-retag','runtime-claim','failed-command','missing-command','skipped-tests','incomplete-partitions']:
  ci,cp=copy.deepcopy(ix),copy.deepcopy(p);pack=cp['source-and-gate.tar.gz']
  if case=='family':ci['family_certified']=True
  elif case=='unfinished':ci['all_consumers_closed']=False
  elif case=='runtime-retag':ci['production_runtime_producer']=PRODUCER
  elif case=='runtime-claim':ci['new_runtime_reexecution_claim']=True
  elif case in ['failed-command','missing-command','skipped-tests']:
   g=json.loads(pack['gate-receipt.json'])
   if case=='failed-command':g['rows'][0]['exit']=1
   elif case=='missing-command':g['rows'].pop(20)
   else:
    pack['stage-2.log']=re.sub(rb'1648 tests run:.*?0 skipped',b'1648 tests run: 1647 passed, 1 skipped',pack['stage-2.log']);g['rows'][66]['log_sha256']=sha(pack['stage-2.log'])
   pack['gate-receipt.json']=json.dumps(g).encode()
  else:
   x=json.loads(pack['offline-62.log'].decode().splitlines()[-1]);x['hash_partitions']=x['hash_partitions'][:-1];pack['offline-62.log']=json.dumps(x).encode();g=json.loads(pack['gate-receipt.json']);g['rows'][62]['log_sha256']=sha(pack['offline-62.log']);pack['gate-receipt.json']=json.dumps(g).encode()
  try:check(ci,cp)
  except (AssertionError,KeyError):rejected.append(case)
  else:raise AssertionError('Accepted '+case)
 result['rejected_rehashed_semantic_controls']=rejected;print(json.dumps(result,indent=2))
