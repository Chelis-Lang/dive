"""Extract literal CI Python commands; execute only a frozen cleanup body in tiny fixtures."""
import hashlib,json,re,shlex,subprocess,tempfile,os
from pathlib import Path
HEADER="python3 -I - <<'PY'"
STEP='Dispose completed temporary Clippy outputs'
def digest(data):return hashlib.sha256(data).hexdigest()
def extract(text,expected_body_sha256,expected_inline=1):
 lines=text.splitlines();records=[];i=0;step=None;inline=0
 while i<len(lines):
  line=lines[i]
  match=re.match(r'^      - name: (.+)$',line)
  if match:step=match[1]
  match=re.match(r'^\s*(?:run:\s*)?(python3(?:\s|$).*)$',line)
  if not match:i+=1;continue
  command=match[1].strip()
  if command==HEADER:
   if step!=STEP:raise ValueError('cleanup inline body outside approved step')
   indent=line[:len(line)-len(line.lstrip())];start=i+1;end=start
   while end<len(lines) and lines[end]!=indent+'PY':end+=1
   if end==len(lines):raise ValueError('missing exact heredoc delimiter')
   body=[]
   for source in lines[start:end]:
    if source and not source.startswith(indent):raise ValueError('heredoc indentation differs from YAML run body')
    body.append(source[len(indent):] if source else '')
   body=('\n'.join(body)+'\n').encode()
   if digest(body)!=expected_body_sha256:raise ValueError('unqualified inline Python source')
   compile(body,'frozen-ci-cleanup','exec')
   records.append({'kind':'inline-fixture','argv':['python3','-I','-'],'step':step,'header':HEADER,'body':body.decode(),'body_sha256':digest(body),'line':i+1})
   inline+=1;i=end+1;continue
  argv=shlex.split(command)
  # Scripts remain exact, ordered, duplicated invocations. No shell redirection
  # or unknown Python source form can accidentally count as an executed script.
  args=argv[1:];args=args[1:] if args[:1]==['-I'] else args
  if len(args)!=1 or not args[0].endswith('.py') or args[0].startswith('-') or '<' in command or '>' in command:
   raise ValueError('unknown Python invocation: '+command)
  records.append({'kind':'script','argv':argv,'line':i+1});i+=1
 if inline!=expected_inline:raise ValueError('changed inline selection')
 return records
def fixture(record,case='normal',run_id='123',attempt='2'):
 if record['kind']!='inline-fixture' or digest(record['body'].encode())!=record['body_sha256']:raise ValueError('body identity changed')
 with tempfile.TemporaryDirectory(prefix='dive-ci-cleanup-contract-') as folder:
  parent=Path(folder);target=parent/'dive-ci-clippy-123-2';sibling=parent/'unrelated';sibling.mkdir();(sibling/'keep').write_bytes(b'unchanged')
  expected=0
  if case=='normal':target.mkdir();(target/'closed').write_bytes(b'disposable')
  elif case=='missing':pass
  elif case=='symlink':target.symlink_to(sibling,target_is_directory=True);expected=1
  elif case=='file':target.write_bytes(b'not directory');expected=1
  elif case=='nested-symlink':target.mkdir();(target/'outside').symlink_to(sibling,target_is_directory=True)
  elif case=='invalid-id':target.mkdir();(target/'closed').write_bytes(b'disposable');expected=1
  else:raise ValueError('unknown fixture case')
  env={**os.environ,'RUNNER_TEMP':str(parent),'GITHUB_RUN_ID':run_id,'GITHUB_RUN_ATTEMPT':attempt}
  result=subprocess.run(record['argv'],input=record['body'].encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=parent)
  assert result.returncode==expected,(case,result.returncode,result.stderr.decode())
  assert (sibling/'keep').read_bytes()==b'unchanged'
  if expected:assert target.exists() or target.is_symlink()
  else:assert not target.exists() and not target.is_symlink()
  return {'case':case,'run_id':run_id,'attempt':attempt,'argv':record['argv'],'body_sha256':record['body_sha256'],'exit':result.returncode,'stdout_sha256':digest(result.stdout),'stderr_sha256':digest(result.stderr),'owned_removed':not(target.exists() or target.is_symlink()),'sibling_retained':True,'scope':'Tiny synthetic fixture; not actual CI footprint or Cargo evidence.'}
