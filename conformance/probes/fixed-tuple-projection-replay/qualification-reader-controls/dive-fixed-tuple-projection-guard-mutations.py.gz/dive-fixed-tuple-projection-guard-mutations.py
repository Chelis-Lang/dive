from pathlib import Path
import tempfile,shutil,json,gzip,hashlib,subprocess
root=Path('/Users/jeff/code/dive-tuple-only-replay-work'); epoch=root/'conformance/probes/fixed-tuple-projection-replay/implemented-epoch'
assert epoch.is_dir()
receipt=Path('/tmp/dive-fixed-tuple-projection-guard-mutation-receipt.json'); rows=[]
for label in ['omit-epoch','producer-retag','gate-nonzero','conditional-false-proof','width-missing-control','procedure-count-inflation','gate-missing-width','source-payload-retag']:
 with tempfile.TemporaryDirectory(prefix='dive-fixed-projection-guard-') as directory:
  base=Path(directory); (base/'scripts').mkdir(); probes=base/'conformance/probes/fixed-tuple-projection-replay'; probes.mkdir(parents=True)
  shutil.copytree(root/'conformance/probes/fixed-tuple-projection-replay/preimplementation',probes/'preimplementation')
  dst=probes/'implemented-epoch'; shutil.copytree(epoch,dst)
  code=(root/'scripts/check-fixed-tuple-projection.py').read_bytes(); (base/'scripts/check-fixed-tuple-projection.py').write_bytes(code)
  idx=json.loads((dst/'index.json').read_text())
  def rewrite(rel,fn):
   p=dst/(rel+'.gz'); raw=gzip.decompress(p.read_bytes()); doc=json.loads(raw); fn(doc); p.write_bytes(gzip.compress((json.dumps(doc,indent=2)+'\n').encode(),mtime=0)); idx['files_sha256'][rel+'.gz']=hashlib.sha256(p.read_bytes()).hexdigest()
  if label=='omit-epoch': shutil.rmtree(dst)
  elif label=='producer-retag': idx['producer']='0000000000000000000000000000000000000000'
  elif label=='gate-nonzero': rewrite('gate/steps.json',lambda d:d[2].update(exit=1))
  elif label=='conditional-false-proof':
   names=[s for s in idx['files_sha256'] if s.startswith('conditional-refusal/') and s.endswith('tlc-original.stdout.gz')]; assert len(names)==1
   rewrite(names[0][:-3],lambda d:d.update(result='valid'))
  elif label=='width-missing-control': rewrite('alias-width-controls/replays.json',lambda d:d['rows'].pop())
  elif label=='procedure-count-inflation': idx['counts']['strict_procedure_valid']+=1
  elif label=='gate-missing-width':
   names=[s for s in idx['files_sha256'] if s.startswith('binary-production/report-examples/') and s.endswith('.json.gz')]; assert len(names)==1
   rewrite(names[0][:-3],lambda d:d['models'][0]['runs'].pop())
  elif label=='source-payload-retag':
   rel='source/crates/dive-trace/src/tuple_history.rs.gz'; p=dst/rel; p.write_bytes(gzip.compress(gzip.decompress(p.read_bytes())+b'\n// altered\n',mtime=0));idx['files_sha256'][rel]=hashlib.sha256(p.read_bytes()).hexdigest()
  if dst.exists(): (dst/'index.json').write_text(json.dumps(idx,indent=2)+'\n')
  r=subprocess.run(['python3','-I',str(base/'scripts/check-fixed-tuple-projection.py')],capture_output=True)
  assert r.returncode!=0,label
  rows.append({'mutation':label,'exit':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'stderr':r.stderr.decode()}); print(label,r.returncode,flush=True)
  receipt.write_text(json.dumps({'all_rejected':True,'rows':rows},indent=2)+'\n')
