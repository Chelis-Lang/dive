from pathlib import Path
import json,gzip,hashlib,subprocess,re,posixpath,sys
root=Path(sys.argv[1]); frozen=Path(sys.argv[2]); destination=Path(sys.argv[3]); producer=sys.argv[4]
sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads((frozen/'source.json').read_text());assert source['source_commit']==producer
compiled={rel for rel in source['source_sha256'] if rel.endswith('.rs') and (re.match(r'^crates/[^/]+/(src|tests|examples|benches)/',rel) or rel.startswith('xtask/src/') or re.match(r'^crates/[^/]+/build\.rs$',rel))}
references=[];inputs={};gaps=[]
for rel in sorted(compiled):
 data=gzip.decompress((frozen/'source'/(rel+'.gz')).read_bytes());assert sha(data)==source['source_sha256'][rel]
 text=data.decode();matches=list(re.finditer(r'\b(include_str|include_bytes|include)!\s*\(\s*"([^"\\]+)"\s*\)',text))
 # Refuse silently omitting non-literal embedded inputs.
 assert len(matches)==len(list(re.finditer(r'\b(?:include_str|include_bytes|include)!\s*\(',text))),rel
 for match in matches:
  target=posixpath.normpath(str(Path(rel).parent/match.group(2)));assert not target.startswith('../')
  git=subprocess.check_output(['git','show',producer+':'+target],cwd=root);assert (root/target).read_bytes()==git,target
  digest=sha(git);inputs[target]=git
  references.append({'source':rel,'macro':match.group(1),'literal':match.group(2),'target':target,'sha256':digest})
  if target not in source['source_sha256']:gaps.append(target)
  else:assert source['source_sha256'][target]==digest,target
assert references
# Whole tree is explicitly a selected source subset, not a hermetic build archive.
destination.mkdir(parents=True,exist_ok=False)
files={}
for rel,data in sorted(inputs.items()):
 p=destination/'inputs'/(rel+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files[str(p.relative_to(destination))]=sha(p.read_bytes())
audit={'schema_version':1,'producer':producer,'qualification':'Post-gate Git/live qualification of literal Rust embedded inputs. Original frozen source subset and gate receipts remain unchanged; this supplement carries no new runtime credit and is not a hermetic toolchain/dependency archive.','original_source_index_sha256':sha((frozen/'source.json').read_bytes()),'compiled_rust_source_sha256':{rel:source['source_sha256'][rel] for rel in sorted(compiled)},'references':references,'original_source_map_missing':sorted(set(gaps)),'input_sha256':{rel:sha(data) for rel,data in sorted(inputs.items())},'files_sha256':files,'dynamic_includes':0,'family_certified':False}
(destination/'index.json').write_text(json.dumps(audit,indent=2)+'\n')
(destination/'original-archive-gap.json').write_text(json.dumps({'producer':producer,'audit_result':'Original selected compile-source archive did not independently carry embedded non-Rust inputs','missing_from_selected_archive':sorted(set(inputs)-{rel for rel in source['source_sha256'] if rel.endswith(('.rs','.toml')) or rel=='Cargo.lock'}),'missing_from_original_source_map':sorted(set(gaps)),'original_gate_results_unchanged':True},indent=2)+'\n')
print(json.dumps({'compiled_sources':len(compiled),'references':len(references),'inputs':len(inputs),'original_source_map_missing':len(set(gaps)),'destination':str(destination)}))
