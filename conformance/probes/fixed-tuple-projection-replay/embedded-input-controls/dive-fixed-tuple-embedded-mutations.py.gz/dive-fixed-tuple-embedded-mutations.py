from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');base=root/'conformance/probes/fixed-tuple-projection-replay/embedded-input-supplement';idx=base/'index.json';original=idx.read_bytes();doc=json.loads(original);payload=base/next(iter(doc['files_sha256']));blob=payload.read_bytes();gap=base/'original-archive-gap.json';gap_original=gap.read_bytes();out=Path('/tmp/dive-fixed-tuple-embedded-controls');out.mkdir(exist_ok=False);rows=[]
def run(label):
 r=subprocess.run(['python3','scripts/check-fixed-tuple-projection.py'],cwd=root,capture_output=True);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);rows.append({'label':label,'exit':r.returncode});assert r.returncode!=0,label
try:
 payload.unlink();run('missing-embedded-input');payload.write_bytes(blob)
 altered=gzip.compress(gzip.decompress(blob)+b'\nforged input\n',mtime=0);payload.write_bytes(altered);new=json.loads(original);new['files_sha256'][str(payload.relative_to(base))]=hashlib.sha256(altered).hexdigest();target=str(payload.relative_to(base/'inputs'))[:-3];new['input_sha256'][target]=hashlib.sha256(gzip.decompress(altered)).hexdigest()
 for row in new['references']:
  if row['target']==target:row['sha256']=new['input_sha256'][target]
 idx.write_text(json.dumps(new,indent=2)+'\n');run('rehashed-forged-input');payload.write_bytes(blob);idx.write_bytes(original)
 new=json.loads(original);new['references'].pop();idx.write_text(json.dumps(new,indent=2)+'\n');run('omitted-include-site');idx.write_bytes(original)
 new=json.loads(gap_original);new['missing_from_original_source_map']=[];gap.write_text(json.dumps(new,indent=2)+'\n');run('concealed-original-gap');gap.write_bytes(gap_original)
 new=json.loads(original);new['producer']='5f440f8fda37e609966cc444831f25e96659b7c6';idx.write_text(json.dumps(new,indent=2)+'\n');run('retagged-producer');idx.write_bytes(original)
finally:
 payload.write_bytes(blob);idx.write_bytes(original);gap.write_bytes(gap_original)
r=subprocess.run(['python3','scripts/check-fixed-tuple-projection.py'],cwd=root,capture_output=True);assert r.returncode==0;rstdout=out/'restored.stdout';rstdout.write_bytes(r.stdout)
receipt={'producer':doc['producer'],'controls':rows,'restored_verifier_exit':r.returncode,'index_sha256':hashlib.sha256(original).hexdigest(),'new_runtime_credit':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
