---- MODULE TupleHistory ----
EXTENDS Naturals, Sequences, TLC
VARIABLES x,s
Pack(v) == <<x,v>>
vars == Pack(s)
Init == x=0 /\ s = <<0,1>>
Next == (x=0 /\ x'=1 /\ s'=Tail(s)) \/ (x#0 /\ UNCHANGED vars)
Inv == x=0
====
