from pathlib import Path
import subprocess,json,hashlib,os,time
root=Path.cwd();sha=lambda data:hashlib.sha256(data).hexdigest()
frozen=json.loads(Path('/tmp/dive-fixed-tuple-projection-frozen-frozen-source/source.json').read_text());hashes=frozen['source_sha256'];integrity=frozen['integrity_output_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==frozen['source_commit']
commands=[['cargo','fmt','--all','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','nextest','run','--workspace','--locked','--profile','ci','--test-threads','2'],['cargo','test','--workspace','--doc','--locked'],['cargo','doc','--workspace','--no-deps','--locked'],['cargo','xtask','check-layering'],['cargo','build','-p','dive-trace','--locked'],['cargo','deny','--locked','check']]
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-tuple-only-replay-cache'}
steps=[]
with Path('/tmp/dive-fixed-tuple-projection-frozen-gate-driver.log').open('w') as log:
 for i,command in enumerate(commands):
  for rel,h in hashes.items():assert sha((root/rel).read_bytes())==h,rel
  for rel,h in integrity.items():assert sha((root/rel).read_bytes())==h,rel
  step_env={**env,'RUSTDOCFLAGS':'-D warnings'} if i==4 else env
  path=Path(f'/tmp/dive-fixed-tuple-projection-frozen-gate-{i}.log');start=time.monotonic();log.write('RUN '+' '.join(command)+'\n');log.flush()
  with path.open('w') as output:r=subprocess.run(command,env=step_env,stdout=output,stderr=subprocess.STDOUT)
  row={'command':command,'exit':r.returncode,'log':str(path),'log_sha256':sha(path.read_bytes()),'seconds':time.monotonic()-start};steps.append(row);Path('/tmp/dive-fixed-tuple-projection-frozen-gate-steps.json').write_text(json.dumps(steps,indent=2)+'\n');log.write(f'RESULT {r.returncode} {path}\n');log.flush();print('Stage '+str(i)+' exit '+str(r.returncode),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
for rel,h in hashes.items():assert sha((root/rel).read_bytes())==h,rel
print('All8 current gate stages closed with unchanged source',flush=True)
