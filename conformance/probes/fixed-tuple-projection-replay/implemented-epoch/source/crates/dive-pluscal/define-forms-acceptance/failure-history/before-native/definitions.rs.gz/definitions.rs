//! DEFINE helpers preserve reference declaration scope, AST bytes and budgets.
use dive_pluscal::{
    Code, FairnessOption, TranslationOptions, algorithm_checksum_at,
    rewrite::{RewriteOptions, select_rewrite},
    translate_at,
};
use std::{fmt::Write, path::Path};

#[test]
fn every_selected_define_ast_is_exact_or_named_refusal() -> Result<(), Box<dyn std::error::Error>> {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("define-acceptance");
    let mut counts = [0usize; 4];
    for folder in ["", "contexts", "corpus", "promoted"] {
        let base = root.join(folder);
        let manifest: serde_json::Value = serde_json::from_str(&std::fs::read_to_string(
            base.join("primary/manifest.json"),
        )?)?;
        for row in manifest["rows"].as_array().ok_or("missing rows")? {
            let id = row["id"].as_str().ok_or("missing id")?;
            let source = std::fs::read_to_string(base.join("cases").join(format!("{id}.tla")))?;
            let flags = row["flags"].as_array().ok_or("missing flags")?;
            let has = |flag: &str| flags.iter().any(|actual| actual == flag);
            let options = TranslationOptions {
                insert_missing_labels: has("-label"),
                fairness: if has("-wf") {
                    FairnessOption::Weak
                } else {
                    FairnessOption::Declared
                },
                ..TranslationOptions::default()
            };
            let selected = select_rewrite(&source, &RewriteOptions::default())?;
            match algorithm_checksum_at(
                &source,
                selected.algorithm.start..selected.algorithm.end,
                &options,
            ) {
                Ok(actual) => {
                    assert_eq!(row["translated"], true, "{folder}/{id}");
                    assert_eq!(row["reference_errors"], false, "{folder}/{id}");
                    assert_eq!(
                        actual.serialized_ast,
                        std::fs::read_to_string(
                            base.join("primary").join(format!("{id}.translated.ast"))
                        )?,
                        "{folder}/{id}"
                    );
                    assert_eq!(
                        actual.checksum, row["stages"]["translated"]["crc"],
                        "{folder}/{id}"
                    );
                    counts[usize::from(row["sany"]["accepted"] != true)] += 1;
                }
                Err(error) if error.diagnostic.code == Code::Unsupported => {
                    assert_ne!(error.diagnostic.message, "");
                    counts[2] += 1;
                }
                Err(error) => {
                    assert_eq!(row["reference_errors"], true, "{folder}/{id}: {error}");
                    assert!(matches!(
                        error.diagnostic.code,
                        Code::Syntax | Code::Lexical | Code::Expression | Code::Label
                    ));
                    counts[3] += 1;
                }
            }
        }
    }
    assert_eq!(counts, [80, 18, 36, 2]);
    Ok(())
}
#[test]
fn scoped_definitions_and_prestate_helpers_keep_reference_order()
-> Result<(), Box<dyn std::error::Error>> {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("define-acceptance/cases");
    for id in [
        "Define_C_constant_process",
        "Define_P_constant_process",
        "Define_C_state",
        "Define_P_state",
    ] {
        let source = std::fs::read_to_string(root.join(format!("{id}.tla")))?;
        let selected = select_rewrite(&source, &RewriteOptions::default())?;
        let actual = translate_at(
            &source,
            selected.algorithm.start..selected.algorithm.end,
            &TranslationOptions::default(),
        )?;
        if id.ends_with("process") {
            let global = actual
                .tla
                .find("VARIABLES pc, x, y")
                .ok_or("missing global declaration")?;
            let definition = actual.tla.find("F == 1").ok_or("missing helper")?;
            let local = actual
                .tla
                .find("VARIABLE z")
                .ok_or("missing local declaration")?;
            assert!(global < definition && definition < local);
        } else {
            assert!(actual.tla.contains("x' = 1"));
            assert!(actual.tla.contains("y' = F"));
            assert!(!actual.tla.contains("F == x'"));
        }
    }
    Ok(())
}
#[test]
fn define_byte_work_and_invalid_scope_boundaries_refuse() -> Result<(), Box<dyn std::error::Error>>
{
    let source =
        "--algorithm A variable x=0; define F(a)==a+1 end define; begin L:x:=F(1); end algorithm;";
    for limit in [0, 1, 8] {
        let options = TranslationOptions {
            max_output_bytes: limit,
            ..TranslationOptions::default()
        };
        let result = algorithm_checksum_at(source, 0..source.len(), &options);
        assert!(result.is_err_and(|e| e.diagnostic.code == Code::Resource));
    }
    let mut definitions = "F0==0 ".to_string();
    for i in 1..50 {
        write!(definitions, "F{i}==F{} ", i - 1)?;
    }
    let graph = format!(
        "--algorithm A variable x=0; define {definitions} end define; begin L:x:=F49; end algorithm;"
    );
    let graph_options = TranslationOptions {
        parser: dive_pluscal::Options {
            max_nodes: 100,
            ..dive_pluscal::Options::default()
        },
        ..TranslationOptions::default()
    };
    let failure = algorithm_checksum_at(&graph, 0..graph.len(), &graph_options);
    assert!(
        failure.is_err_and(|e| e.diagnostic.code == Code::Resource
            && e.diagnostic.message.contains("dependency-work"))
    );
    let chain = "--algorithm A variable x=0; define A==1 B==A C==B D==C E==D end define; begin L:x:=E; end algorithm;";
    let options = TranslationOptions {
        parser: dive_pluscal::Options {
            max_nodes: 3,
            ..dive_pluscal::Options::default()
        },
        ..TranslationOptions::default()
    };
    assert!(algorithm_checksum_at(chain, 0..chain.len(), &options).is_err());
    for definition in [
        "RECURSIVE F(_) F(a)==IF a=0 THEN 0 ELSE F(a-1)",
        "F(a)==G(a) G(a)==F(a)",
        "F==x'",
        "LOCAL F==1",
        "Init==TRUE",
    ] {
        let source = format!(
            "--algorithm A variable x=0; define {definition} end define; begin L:x:=1; end algorithm;"
        );
        assert!(
            algorithm_checksum_at(&source, 0..source.len(), &TranslationOptions::default())
                .is_err_and(|e| e.diagnostic.code == Code::Unsupported)
        );
    }
    Ok(())
}
