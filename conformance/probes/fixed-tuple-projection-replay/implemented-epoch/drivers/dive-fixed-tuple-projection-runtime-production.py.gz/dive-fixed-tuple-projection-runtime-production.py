from pathlib import Path
import subprocess,json,hashlib,os,shutil,time
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');out=Path('/tmp/dive-fixed-tuple-projection-fresh-binaries');out.mkdir(exist_ok=False)
frozen=json.loads(Path('/tmp/dive-fixed-tuple-projection-frozen-frozen-source/source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-tuple-only-replay-cache'}
def unchanged():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
 for rel,h in frozen['source_sha256'].items():assert sha(root/rel)==h,rel
 for rel,h in frozen['integrity_output_sha256'].items():assert sha(root/rel)==h,rel
gate=json.loads(Path('/tmp/dive-fixed-tuple-projection-complete-gate-steps.json').read_text());assert len(gate)==8 and all(row['exit']==0 for row in gate)
unchanged();steps=[]
def run(label,command):
 unchanged();start=time.monotonic()
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'label':label,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(out/(label+'.stdout')),'stderr_sha256':sha(out/(label+'.stderr'))};steps.append(row);(out/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');unchanged();print(label,r.returncode,flush=True);assert r.returncode==0,label
run('release',['cargo','build','--release','--locked','-p','dive-cli','-p','dive-conformance'])
for name in ['dive','dive-conformance']:
 src=Path(env['CARGO_TARGET_DIR'])/'release'/name;dest=out/name;shutil.copy2(src,dest);assert sha(src)==sha(dest);dest.chmod(0o555)
producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'source_index_sha256':sha(Path('/tmp/dive-fixed-tuple-projection-frozen-frozen-source/source.json')),'binary_sha256':{name:sha(out/name) for name in ['dive','dive-conformance']},'family_certified':False}
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
run('guide',['cargo','run','--locked','-p','dive-api','--example','inductive_tuple_replay'])
run('fresh-primary-and-words',['python3','-I','/tmp/dive-fixed-tuple-projection-fresh-runtime.py'])
run('fixed-alias-controls',['python3','-I','/tmp/dive-fixed-tuple-projection-alias-runtime.py'])
run('conditional-refusal-controls',['python3','-I','/tmp/dive-fixed-tuple-projection-conditional-runtime.py'])
run('original-generated-procedure-words',['python3','-I','/tmp/dive-inductive-procedure-history-correct-name.py','--binary',str(out/'dive'),'--producer',str(out/'producer.json'),'--out','/tmp/dive-fixed-tuple-projection-procedure-words'])
run('projection-width-controls',['python3','-I','/tmp/dive-fixed-tuple-projection-width-controls.py','--binary',str(out/'dive'),'--producer',str(out/'producer.json'),'--out','/tmp/dive-fixed-tuple-projection-alias-width-controls'])
run('width-controls',['python3','-I','/tmp/dive-inductive-tuple-width-controls.py','--binary',str(out/'dive'),'--producer',str(out/'producer.json'),'--out','/tmp/dive-fixed-tuple-projection-width-controls'])
for corpus,listfile in [('examples','conformance/gates/cm1.txt'),('validation-smoke','conformance/gates/validation-smoke.txt')]:
 selection=[s.split('#',1)[0].strip()for s in (root/listfile).read_text().splitlines()];selection=[s for s in selection if s]
 args=[str(out/'dive-conformance'),'run','--impl','dive','--impl-profile','tlc','--corpus',corpus,'--tier','all','--no-sany','--no-summary','--report-dir',str(out/('report-'+corpus)),'--dive-bin',str(out/'dive'),'--workers','1,4,8']
 for model in selection:args+=['--filter',model]
 run('gate-'+corpus,args)
 reports=list((out/('report-'+corpus)).glob('*.json'));assert len(reports)==1;report=json.loads(reports[0].read_text());assert report['summary']['models_selected']==report['summary']['models']['agree']==len(selection)
 for model in report['models']:
  assert model['outcome']=='agree' and {r['workers']for r in model['runs']}=={1,4,8};assert all(r['outcome']=='agree'and not r['diffs']for r in model['runs'])
unchanged();(out/'closure.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'all_consumers_closed':True,'steps':steps,'family_certified':False},indent=2)+'\n')
