from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');frozen=json.loads(Path('/tmp/dive-fixed-tuple-projection-frozen-frozen-source/source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=Path('/tmp/dive-fixed-tuple-projection-gate-resume');out.mkdir(exist_ok=False)
original=Path('/tmp/dive-fixed-tuple-projection-frozen-gate-steps.json');steps=json.loads(original.read_text());assert len(steps)==5 and all(r['exit']==0 for r in steps)
failed=out/'interrupted-epoch';failed.mkdir()
paths=[original,Path('/tmp/dive-fixed-tuple-projection-full-gate.py'),Path('/tmp/dive-fixed-tuple-projection-full-gate.log'),Path('/tmp/dive-fixed-tuple-projection-frozen-gate-driver.log')]+list(Path('/tmp').glob('dive-fixed-tuple-projection-frozen-gate-[0-9].log'))
for p in paths:shutil.copy2(p,failed/p.name)
(failed/'index.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'files':{p.name:sha(p)for p in paths},'qualification':'Five actual zero stages retained,1219/1219zero-skip; ENOSPC receipt-write interrupts sixth stage, its zero-byte layering output grants no completion credit. Lastthree stages run again on unchanged exactproducer.'},indent=2)+'\n')
for row in steps:assert sha(Path(row['log']))==row['log_sha256']
assert '1219 tests run: 1219 passed, 0 skipped' in Path(steps[2]['log']).read_text()
def unchanged():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
 for field in ['source_sha256','integrity_output_sha256']:
  for rel,h in frozen[field].items():assert sha(root/rel)==h,rel
commands=[['cargo','xtask','check-layering'],['cargo','build','-p','dive-trace','--locked'],['cargo','deny','--locked','check']]
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-tuple-only-replay-cache'}
for ordinal,command in enumerate(commands,5):
 unchanged();log=out/(str(ordinal)+'.log');start=time.monotonic()
 with log.open('w')as stdout:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=subprocess.STDOUT)
 steps.append({'command':command,'exit':r.returncode,'log':str(log),'log_sha256':sha(log),'seconds':time.monotonic()-start,'resumed_after_original_enospc':True})
 Path('/tmp/dive-fixed-tuple-projection-complete-gate-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print('resumed stage',ordinal,r.returncode,flush=True);assert r.returncode==0;unchanged()
assert len(steps)==8
(out/'closure.json').write_text(json.dumps({'producer':frozen['source_commit'],'all8closed':True,'zero_skip_tests':1219,'scope':'Original closedfive stages plus fresh lastthree; no repeated test credit; original ENOSPC retained'},indent=2)+'\n')
