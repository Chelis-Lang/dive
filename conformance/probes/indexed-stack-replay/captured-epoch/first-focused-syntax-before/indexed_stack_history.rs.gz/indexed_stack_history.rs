//! Source-owned range facts must not be inferred from supplied frame values.
#![allow(clippy::expect_used, clippy::panic, reason = "test assertions")]

use dive_model::Model;
use dive_trace::{Ending, TraceDoc, Validation, validate_doc};
use serde_json::json;
use std::sync::Arc;

fn model(init: &str, next: &str, definitions: &str, compat: bool) -> Model {
    let source = format!(
        "---- MODULE IndexedStack ----\nEXTENDS Naturals, Sequences, TLC\nVARIABLES x,s\n{definitions}\nInit == x=0 /\\ s={init}\nNext == {next}\nInv == x<2\n====\n"
    );
    let analysis =
        dive_sema::analyze_source("IndexedStack.tla", &source, &dive_sema::Options::default());
    assert!(analysis.accepted(), "{:?}", analysis.diagnostics());
    dive_model::bind(
        Arc::new(dive_ir::lower(&analysis).expect("lower indexed stack")),
        &dive_config::parse("INIT Init\nNEXT Next\nINVARIANT Inv\n")
            .into_config()
            .expect("config"),
        &if compat {
            dive_model::BindOptions::tlc()
        } else {
            dive_model::BindOptions::default()
        },
    )
    .expect("bind indexed stack")
}

fn word() -> TraceDoc {
    TraceDoc::behavior(vec![
        json!({"x":0,"s":{"fcn":[{"key":1,"value":{"seq":[0,1]}},{"key":2,"value":{"seq":[0,1]}}]}}),
        json!({"x":1,"s":{"fcn":[{"key":1,"value":{"seq":[1]}},{"key":2,"value":{"seq":[0,1]}}]}}),
        json!({"x":2,"s":{"fcn":[{"key":1,"value":{"seq":[1]}},{"key":2,"value":{"seq":[4,0,1]}}]}}),
    ]).expect("stored owner stacks").with_ending(Ending::Invariant("Inv".to_owned()))
}

const NEXT: &str = "(x=0 /\\ x'=1 /\\ s'=[s EXCEPT ![1]=Tail(s[1])]) \\/ (x=1 /\\ x'=2 /\\ s'=[s EXCEPT ![2]=<<4>> \\o s[2]]) \\/ (x>1 /\\ UNCHANGED <<x,s>>)";

#[test]
fn tuple_ranges_preserve_actual_indexed_next_and_ending() {
    for compat in [true, false] {
        let model = model("[i \\in {1,2} |-> <<0,1>>]", NEXT, "", compat);
        let original = word();
        let (report, decoded) = validate_doc(&model, &original, &[], None);
        assert_eq!(report.validation, Validation::Valid, "{report:?}");
        assert_eq!(
            dive_trace::validate(&model, &decoded.expect("decoded original"), None).validation,
            Validation::Valid
        );
        assert!(model.take_output().is_empty());
        let mut changed = original.to_json();
        changed["states"][1]["values"]["s"]["fcn"][1]["value"]["seq"] = json!([1]);
        let changed = TraceDoc::from_json(&changed).expect("wrong other-owner stack");
        assert!(matches!(
            validate_doc(&model, &changed, &[], None).0.validation,
            Validation::Invalid(_)
        ));
        let altered = original
            .clone()
            .with_ending(Ending::Invariant("MissingProperty".to_owned()));
        assert!(matches!(
            validate_doc(&model, &altered, &[], None).0.validation,
            Validation::Invalid(_)
        ));
    }
}

#[test]
fn finite_quantified_and_scoped_range_sources_preserve_original_word() {
    for (definitions, next) in [
        (
            "Owners == {1,2}\nRead(f,k) == f[k]",
            NEXT.replace("s[1]", "Read(s,1)")
                .replace("s[2]", "Read(s,2)"),
        ),
        (
            "Step(k) == (x=0 /\\ x'=1 /\\ s'=[s EXCEPT ![k]=Tail(s[k])])",
            NEXT.replace(
                "(x=0 /\\ x'=1 /\\ s'=[s EXCEPT ![1]=Tail(s[1])])",
                "(\\E owner \\in {1}: Step(owner))",
            ),
        ),
        (
            "",
            NEXT.replace("Tail(s[1])", "LET Dropped == Tail(s[1]) IN Dropped"),
        ),
    ] {
        let model = model("[i \\in {1,2} |-> <<0,1>>]", &next, definitions, true);
        assert_eq!(
            validate_doc(&model, &word(), &[], None).0.validation,
            Validation::Valid,
            "{next}"
        );
        assert!(model.take_output().is_empty());
    }
}

#[test]
fn unvisited_disjuncts_cannot_borrow_range_facts_from_the_word() {
    for bad in [
        "s'=[s EXCEPT ![1]=\"text\"]",
        "s'=[s EXCEPT ![1]=IF x=0 THEN <<0>> ELSE \"text\"]",
        "s'=s'",
        "TRUE",
        "s'=[t EXCEPT ![1]=<<0>>]",
    ] {
        let declarations = if bad.contains("[t ") {
            "t == [i \\in {1,2} |-> \"text\"]"
        } else {
            ""
        };
        let next = format!("{NEXT} \\/ (x=99 /\\ x'=100 /\\ {bad})");
        let strict = model("[i \\in {1,2} |-> <<0,1>>]", &next, declarations, true);
        assert_eq!(
            validate_doc(&strict, &word(), &[], None).0.validation,
            Validation::Unsupported(dive_trace::RUNTIME_NAMES_UNSUPPORTED.to_owned()),
            "{bad}"
        );
        assert!(strict.take_output().is_empty());
        let canonical = model("[i \\in {1,2} |-> <<0,1>>]", &next, declarations, false);
        assert_eq!(
            validate_doc(&canonical, &word(), &[], None).0.validation,
            Validation::Valid,
            "{bad}"
        );
    }
}

#[test]
fn supplied_tuple_values_cannot_discharge_string_init_ranges() {
    for init in [
        "[i \\in {1,2} |-> \"text\"]",
        "[i \\in {1,2} |-> IF i=1 THEN <<0,1>> ELSE \"text\"]",
    ] {
        let strict = model(init, NEXT, "", true);
        assert_eq!(
            validate_doc(&strict, &word(), &[], None).0.validation,
            Validation::Unsupported(dive_trace::RUNTIME_NAMES_UNSUPPORTED.to_owned())
        );
        assert!(strict.take_output().is_empty());
    }
}

#[test]
fn range_facts_do_not_hide_effects_or_unknown_domains() {
    for (init, next) in [
        ("[i \\in Nat |-> <<0,1>>]", NEXT.to_owned()),
        (
            "[i \\in {1,2} |-> <<0,1>>]",
            format!("PrintT(\"\") /\\ ({NEXT})"),
        ),
    ] {
        let strict = model(init, &next, "", true);
        assert_eq!(
            validate_doc(&strict, &word(), &[], None).0.validation,
            Validation::Unsupported(dive_trace::RUNTIME_NAMES_UNSUPPORTED.to_owned())
        );
        assert!(strict.take_output().is_empty());
    }
}
