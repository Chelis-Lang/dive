from pathlib import Path
import os,re,subprocess,json,hashlib,time
root=Path('/Users/jeff/code/dive-trace-representation-work');out=Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-preparation-offline-retry1');out.mkdir()
required={'CARGO_TARGET_DIR':'/Users/jeff/code/dive-trace-representation-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-trace-representation-cache'}
for k,v in required.items():assert os.environ.get(k)==v,k
workflow=(root/'.github/workflows/ci.yml').read_bytes();all_commands=re.findall(r'^\s+(?:run: )?(python3[^\n]+)$',workflow.decode(),re.M);commands=[s for s in all_commands if s!='python3 -I scripts/check-test-partitions.py'];assert len(all_commands)==69 and len(commands)==68
rows=[]
for i,command in enumerate(commands):
 log=out/f'guard-{i:02}.log';start=time.monotonic()
 with log.open('wb') as stream:r=subprocess.run(command.split(),cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 assert (root/'.github/workflows/ci.yml').read_bytes()==workflow
 rows.append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});(out/'receipt.json').write_text(json.dumps({'scope':'Bounded pre-freeze metadata preparation only. Full final gate/16-way inventory remain separate and held for capacity. Literal invocations, including inherited duplicates, are preserved in order.','workflow_sha256':hashlib.sha256(workflow).hexdigest(),'ci_total_invocations':len(all_commands),'ci_distinct_commands':len(set(all_commands)),'executed_invocations':len(commands),'omitted_invocation':'python3 -I scripts/check-test-partitions.py','rows':rows},indent=2)+'\n');print(i,command,r.returncode,flush=True)
print('CLOSED bounded68literal preparation; failures=',sum(r['exit']!=0 for r in rows),flush=True)
