from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,os
root=Path('/Users/jeff/code/dive-trace-representation-work');external=Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-metadata-exit-controls');external.mkdir(exist_ok=False)
for key,value in {'CARGO_TARGET_DIR':'/Users/jeff/code/dive-trace-representation-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-trace-representation-cache'}.items():assert os.environ.get(key)==value,key
current=json.loads((root/'conformance/probes/indexed-stack-replay/qualified-epoch/current-source.json').read_text()); rows=[]
with tempfile.TemporaryDirectory(prefix='dive-indexed-final-reader-') as tmp:
 work=Path(tmp); shutil.copytree(root/'conformance/probes/indexed-stack-replay',work/'conformance/probes/indexed-stack-replay')
 for name in current['current_sha256']:
  dst=work/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dst)
 base=work/'conformance/probes/indexed-stack-replay/qualified-epoch';idx=base/'index.json';original_index=idx.read_bytes();oldindex=json.loads(original_index)
 cmd=['python3','-I',str(work/'scripts/check-indexed-stack-replay.py')]
 controls=[('census-invalid-exit','native/census/receipt.json.gz',lambda d:d['rows'][0]['mutant'].update(exit=0)),('frame-invalid-exit','native/process-semantic-mutants/receipt.json.gz',lambda d:d['rows'][0].update(exit=0)),('primary-seed','native/primary-process/receipt.json.gz',lambda d:d.update(seed=7))]
 for label,name,mutate in controls:
  path=base/name;old=path.read_bytes();doc=json.loads(gzip.decompress(old));mutate(doc);path.write_bytes(gzip.compress((json.dumps(doc,indent=2)+'\n').encode(),mtime=0));index=json.loads(original_index);index['files_sha256'][name]=hashlib.sha256(path.read_bytes()).hexdigest();idx.write_text(json.dumps(index,indent=2)+'\n');r=subprocess.run(cmd,capture_output=True)
  (external/(label+'.stdout')).write_bytes(r.stdout);(external/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode!=0 and b'AssertionError' in r.stderr,label
  rows.append({'case':label,'exit':r.returncode,'changed_payload':name,'original_sha256':hashlib.sha256(old).hexdigest(),'mutated_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'envelope_rehashed':True,'result':'rejected'})
  path.write_bytes(old);idx.write_bytes(original_index)
 r=subprocess.run(cmd,capture_output=True);(external/'restored.stdout').write_bytes(r.stdout);(external/'restored.stderr').write_bytes(r.stderr);assert r.returncode==0
(external/'receipt.json').write_text(json.dumps({'scope':'Post-runtime reader controls only; complete packets copied privately, wrong observed exits/pinnedseed rehashed, native producer unchanged. No current-case omissions or runtime retag.','reader_sha256':hashlib.sha256((root/'scripts/check-indexed-stack-replay.py').read_bytes()).hexdigest(),'rows':rows,'restored_exit':r.returncode},indent=2)+'\n');print('CLOSED three rehashed final reader controls rejected/restoredPASS')
