import pathlib,json,subprocess,hashlib,time,copy
base=pathlib.Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-qualified/native');binary=base/'dive';producer=json.loads((base/'producer.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==producer['binary_sha256']
selection=json.loads((base/'declared-selection.json').read_text())['selection'];out=base/'census';out.mkdir(exist_ok=False);rows=[]
for model in selection:
 for profile in ['tlc','dive']:
  prefix=model['family']+'-'+model['case']+'-'+profile;command=[str(binary),'check',model['file'],'--config',model['config'],'--compat',profile,'--seed','0','--fp','0','--workers','1','--trace-format','representation-v2','--output','json']
  start=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=120);(out/(prefix+'.check.stdout')).write_bytes(r.stdout);(out/(prefix+'.check.stderr')).write_bytes(r.stderr);doc=json.loads(r.stdout);row={'family':model['family'],'case':model['case'],'profile':profile,'check_exit':r.returncode,'check_verdict':doc['verdict'],'statistics':doc['statistics'],'word_present':doc.get('counterexample') is not None,'check_command':command,'seconds':time.monotonic()-start}
  if doc.get('counterexample') is not None:
   word=doc['counterexample']['trace'];path=out/(prefix+'.word.json');path.write_text(json.dumps(word,indent=2)+'\n');mutant=copy.deepcopy(word);assert len(mutant['states'])>=2;mutant['states'][1]['values']['x']=99;mpath=out/(prefix+'.mutant.json');mpath.write_text(json.dumps(mutant,indent=2)+'\n')
   for label,file in [('original',path),('mutant',mpath)]:
    cmd=[str(binary),'validate-trace',model['file'],'--config',model['config'],'--trace',str(file),'--compat',profile,'--seed','0','--fp','0','--output','json'];v=subprocess.run(cmd,capture_output=True,timeout=120);(out/(prefix+'.'+label+'.stdout')).write_bytes(v.stdout);(out/(prefix+'.'+label+'.stderr')).write_bytes(v.stderr);row[label]={'exit':v.returncode,'result':json.loads(v.stdout),'command':cmd}
  rows.append(row);(out/'receipt.json').write_text(json.dumps({'producer':producer['producer'],'binary_sha256':producer['binary_sha256'],'selection':40,'rows':rows,'scope':'Fresh indexed-range selected corpus census; canonical and strict classifications remain separate. No new admission/whole-family claim.'},indent=2)+'\n');print(len(rows),prefix,row.get('original',{}).get('result'),flush=True)
assert len(rows)==80
print('CLOSED eighty native checks and complete emitted original/mutant selections',flush=True)
