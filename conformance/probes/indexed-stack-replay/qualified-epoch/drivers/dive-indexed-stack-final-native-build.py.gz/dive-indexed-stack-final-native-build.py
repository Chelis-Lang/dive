import pathlib,os,subprocess,json,hashlib,time,shutil
root=pathlib.Path('/Users/jeff/code/dive-trace-representation-work')
base=pathlib.Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-qualified')
out=base/'native'; out.mkdir(exist_ok=False)
expected='dd4edf337c70be1c5b5efdcb72ca805425fd48b1'
for k,v in {'CARGO_TARGET_DIR':'/Users/jeff/code/dive-trace-representation-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-trace-representation-cache'}.items(): assert os.environ.get(k)==v,k
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
index=json.loads((base/'source-index.json').read_text()); assert index['producer']==expected
gate=json.loads((base/'gate/receipt.json').read_text()); assert len(gate['rows'])==8 and all(row['exit']==0 for row in gate['rows'])
for name,row in index['inputs'].items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==row['sha256']
local=json.loads(json.dumps(index))
for row in local['inputs'].values(): row['archive']='../'+row['archive']
(out/'source-index.json').write_text(json.dumps(local,indent=2)+'\n')
selection=pathlib.Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/first-native/declared-selection.json')
shutil.copy2(selection,out/'declared-selection.json')
command=['cargo','build','--release','--locked','-p','dive-cli','-p','dive-conformance']; start=time.monotonic(); log=out/'build.log'
with log.open('wb') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
receipt={'producer':expected,'command':command,'exit':r.returncode,'jobs':2,'incremental':False,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'source_index_sha256':hashlib.sha256((out/'source-index.json').read_bytes()).hexdigest(),'gate_receipt_sha256':hashlib.sha256((base/'gate/receipt.json').read_bytes()).hexdigest()}
(out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n'); assert r.returncode==0
for name,row in index['inputs'].items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==row['sha256']
for name in ['dive','dive-conformance']:
 binary=pathlib.Path(os.environ['CARGO_TARGET_DIR'])/'release'/name; dest=out/name; shutil.copy2(binary,dest); assert binary.read_bytes()==dest.read_bytes(); receipt[name+'_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
receipt['binary_sha256']=receipt['dive_sha256']; (out/'producer.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt),flush=True)
