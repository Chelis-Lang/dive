from pathlib import Path
import json,subprocess,hashlib,copy,os
for key,value in {'CARGO_TARGET_DIR':'/Users/jeff/code/dive-trace-representation-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-trace-representation-cache'}.items():assert os.environ.get(key)==value,key
base=Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-qualified/native');out=base/'process-semantic-mutants';out.mkdir(exist_ok=False);binary=base/'dive';producer=json.loads((base/'producer.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==producer['binary_sha256'];selected=[r for r in json.loads((base/'census/receipt.json').read_text())['rows'] if r['family']=='process'];rows=[]
def alter_frame(value):
 if isinstance(value,dict):
  if value.get('repr')=='record':
   for entry in value['items']:
    if entry[0]=='pc':entry[1]='L';return True
  for item in value.values():
   if alter_frame(item):return True
 if isinstance(value,list):
  for item in value:
   if alter_frame(item):return True
 return False
for row in selected:
 prefix='process-'+row['case']+'-'+row['profile'];word=json.loads((base/'census'/(prefix+'.word.json')).read_text());changes={}
 m=copy.deepcopy(word);m['states'][0]['values']['x']=99;changes['initial']=m
 m=copy.deepcopy(word);m['states'][1]['values']['stack']=copy.deepcopy(word['states'][0]['values']['stack']);changes['indexed-update']=m
 m=copy.deepcopy(word);assert alter_frame(m['states'][1]['values']['stack']);changes['return-frame']=m
 m=copy.deepcopy(word);m['states'][-1]['values']['x']=99;changes['final']=m
 m=copy.deepcopy(word);m['ending']['name']='MissingProperty';changes['ending']=m
 for label,mutant in changes.items():
  path=out/(prefix+'.'+label+'.word.json');path.write_text(json.dumps(mutant,indent=2)+'\n');checkcommand=row['check_command'];file=checkcommand[2];cfg=checkcommand[checkcommand.index('--config')+1];cmd=[str(binary),'validate-trace',file,'--config',cfg,'--compat',row['profile'],'--seed','0','--fp','0','--trace',str(path),'--output','json'];r=subprocess.run(cmd,capture_output=True,timeout=120);(out/(prefix+'.'+label+'.stdout')).write_bytes(r.stdout);(out/(prefix+'.'+label+'.stderr')).write_bytes(r.stderr);result=json.loads(r.stdout);assert result['result']=='invalid',(prefix,label,result);assert result.get('failure',{}).get('check')!='shape',(prefix,label,result)
  rows.append({'case':row['case'],'profile':row['profile'],'mutant':label,'command':cmd,'exit':r.returncode,'result':result});(out/'receipt.json').write_text(json.dumps({'producer':producer['producer'],'binary_sha256':producer['binary_sha256'],'selection':'all eight declared process cases, two profiles, five semantic mutants each','rows':rows},indent=2)+'\n')
assert len(rows)==80
print('CLOSED 80 actual semantic mutants across all eight process cases/two profiles; no shape credit')
