import pathlib,os,subprocess,json,hashlib,time,copy
root=pathlib.Path('/Users/jeff/code/dive-trace-representation-work'); base=pathlib.Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/final-qualified'); expected='dd4edf337c70be1c5b5efdcb72ca805425fd48b1'
for k,v in {'CARGO_TARGET_DIR':'/Users/jeff/code/dive-trace-representation-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','DIVE_CACHE_DIR':'/Users/jeff/code/dive-trace-representation-cache'}.items():assert os.environ.get(k)==v,k
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
gate=json.loads((base/'gate/receipt.json').read_text()); assert len(gate['rows'])==8 and all(row['exit']==0 for row in gate['rows'])
steps=[('build',['python3','-u','/tmp/dive-indexed-stack-final-native-build.py']),('census',['python3','-u','/tmp/dive-indexed-stack-final-first-native-census.py']),('primary',['python3','-u','/tmp/dive-indexed-stack-final-primary.py']),('semantic-mutants',['python3','-u','/tmp/dive-indexed-stack-final-process-mutants.py']),('width-store-transport',['python3','-u','/tmp/dive-indexed-stack-final-width-store-transport.py']),('guide-cli-primary',['python3','-u','/tmp/dive-indexed-stack-final-guide-controls.py']),('guide-cargo',['cargo','run','--locked','-p','dive-api','--example','indexed_stack_replay']),('cm1',['bash','scripts/conformance-gate.sh','conformance/gates/cm1.txt','--workers','1,4,8','--dive-bin',str(base/'native/dive')]),('validation-smoke',['bash','scripts/conformance-gate.sh','conformance/gates/validation-smoke.txt','--workers','1,4,8','--dive-bin',str(base/'native/dive')])]
out=base/'runtime';out.mkdir(exist_ok=False); rows=[];start=time.monotonic(); inputs=json.loads((base/'source-index.json').read_text())['inputs']
for name,cmd in steps:
 env=os.environ.copy();env['HARNESS']=str(base/'native/dive-conformance')
 if name=='validation-smoke':env['DIVE_GATE_CORPUS']='validation-smoke'
 log=out/(name+'.log');t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (out/'receipt.json').write_text(json.dumps({'producer':expected,'steps':rows,'elapsed_seconds':time.monotonic()-start,'jobs':2,'incremental':False,'scope':'Fresh exact-source release, complete original census and process selections, clean primary pairs, actual CLI/Cargo guide and37model1/4/8 gates. Historical first runtime remains separate.'},indent=2)+'\n')
 print(name,'exit',r.returncode,'seconds',rows[-1]['seconds'],flush=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected
 assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==row['sha256'] for p,row in inputs.items())
 if r.returncode:raise SystemExit(r.returncode)
old=pathlib.Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/indexed-stack-replay/first-native'); new=base/'native'; comparisons=[]
for item in json.loads((new/'census/receipt.json').read_text())['rows']:
 prefix=item['family']+'-'+item['case']+'-'+item['profile']; a=json.loads((old/'census'/(prefix+'.check.stdout')).read_text());b=json.loads((new/'census'/(prefix+'.check.stdout')).read_text());a.pop('elapsed_ms');b.pop('elapsed_ms');assert a==b,(prefix,'fullreport changed outside elapsed_ms');assert (old/'census'/(prefix+'.word.json')).read_bytes()==(new/'census'/(prefix+'.word.json')).read_bytes();assert item['original']['result']['result']=='valid' and item['mutant']['result']['result']=='invalid';assert item['mutant']['result']['failure']['check']!='shape'; comparisons.append({'case':item['case'],'profile':item['profile'],'family':item['family'],'full_report_except_elapsed_ms_equal':True,'emitted_word_bytes_equal':True})
assert len(comparisons)==80
(new/'first-final-equality.json').write_text(json.dumps({'first_producer':json.loads((old/'producer.json').read_text())['producer'],'final_producer':expected,'excluded_report_fields':['elapsed_ms'],'rows':comparisons},indent=2)+'\n');print('CLOSED final current runtime9steps plus80exactreport/word equality',flush=True)
