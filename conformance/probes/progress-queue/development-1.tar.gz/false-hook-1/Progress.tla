---- MODULE Progress ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..0
Next == x' = IF x < 3 THEN x+1 ELSE x
Live == <>(x >= 2)
Bad == <>(x=999)
Inv == FALSE
Hook == FALSE
====
