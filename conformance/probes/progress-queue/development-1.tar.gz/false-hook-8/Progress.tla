---- MODULE Progress ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..7
Next == x' = IF x < 24 THEN x+8 ELSE x
Live == <>(x >= 16)
Bad == <>(x=999)
Inv == FALSE
Hook == FALSE
====
