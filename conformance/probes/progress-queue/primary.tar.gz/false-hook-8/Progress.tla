---- MODULE Progress ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..7
Gate(v) == TRUE
Next == Gate(x) /\ x' = IF x < 24 THEN x+8 ELSE x
Live == <>(x >= 16)
Bad == <>(x=999)
Inv == x < 0
Hook == FALSE
====
