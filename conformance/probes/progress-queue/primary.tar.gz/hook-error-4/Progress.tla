---- MODULE Progress ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..3
Gate(v) == TRUE
Next == Gate(x) /\ x' = IF x < 12 THEN x+4 ELSE x
Live == <>(x >= 8)
Bad == <>(x=999)
Inv == x < 0
Hook == 1 \div 0
====
