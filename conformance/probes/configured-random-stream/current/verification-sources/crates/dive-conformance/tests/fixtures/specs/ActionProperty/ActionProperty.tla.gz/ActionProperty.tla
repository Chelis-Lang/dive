---- MODULE ActionProperty ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Monotone == [][x' > x]_x
====
