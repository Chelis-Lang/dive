---- MODULE SuPrintSubstBase ----
CONSTANT K
====
