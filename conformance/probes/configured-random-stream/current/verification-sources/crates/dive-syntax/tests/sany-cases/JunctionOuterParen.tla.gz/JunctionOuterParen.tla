---- MODULE JunctionOuterParen ----
x == (/\ TRUE
)
====
