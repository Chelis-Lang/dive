---- MODULE PrecSetminusChain ----
x == {} \ {} \ {}
====
