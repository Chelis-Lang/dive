---- MODULE JunctionParenLeft ----
x == /\ (TRUE
)
====
