---- MODULE StringBadEscape ----
x == "\q"
====
