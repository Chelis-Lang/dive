just text
