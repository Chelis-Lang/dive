---- MODULE RecordSetKeyword ----
x == [ELSE : {}]
====
