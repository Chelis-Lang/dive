---- MODULE AssumeTemporal ----
ASSUME []TRUE
====
