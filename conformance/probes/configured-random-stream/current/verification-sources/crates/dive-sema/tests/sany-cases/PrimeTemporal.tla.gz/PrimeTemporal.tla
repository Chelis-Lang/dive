---- MODULE PrimeTemporal ----
P == ([]TRUE)'
====
