---- MODULE ProofDefOfTheoremStep ----
THEOREM TRUE
<1>1. TRUE
  OBVIOUS
<1>2. QED
  BY DEF <1>1
====
