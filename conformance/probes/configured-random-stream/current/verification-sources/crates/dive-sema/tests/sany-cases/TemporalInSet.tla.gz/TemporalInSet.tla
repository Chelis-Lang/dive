---- MODULE TemporalInSet ----
P == {[]TRUE}
====
