---- MODULE ErPostNonBool ----
\* WP-C4 error-class matrix: a non-boolean where a formula is expected in a POSTCONDITION after a complete search.
EXTENDS Integers, TLC
VARIABLES x, y
Err(v) == IF v = 2 THEN 7 ELSE TRUE
Init == x = 0 /\ y = 0
Step == \/ x < 3 /\ x' = x + 1 /\ y' = y
        \/ x' = x /\ y' = 1 - y
Next == Step
Post == Err(2)
====
