//! Supplied pure hook admission, actual pause composition and failure precedence.
#![allow(
    clippy::expect_used,
    reason = "bounded hook controls assert explicit outcomes"
)]
use dive_check::CheckOptions;
use dive_liveness::{periodic, periodic_hook, periodic_lifecycle, phase_graph};
use dive_model::Pred;
use std::sync::Arc;

fn model(hook: &str, live: &str) -> (dive_model::Model, Pred) {
    let source = format!(
        "---- MODULE Hook ----\nEXTENDS Integers\nCONSTANT Token\nVARIABLE x\nInit == x=0\nNext == x'=IF x=0 THEN 1 ELSE 1\nLive == {live}\nHook == {hook}\n====\n"
    );
    let a = dive_sema::analyze_source("Hook.tla", &source, &Default::default());
    let ir = Arc::new(dive_ir::lower(&a).expect("IR"));
    let def = ir
        .defs()
        .iter()
        .position(|d| d.name == "Hook")
        .expect("Hook");
    let def = dive_ir::DefId(u32::try_from(def).expect("id"));
    let cfg = dive_config::parse(
        "CONSTANT Token=Atom\nINIT Init\nNEXT Next\nPROPERTY Live\nCHECK_DEADLOCK FALSE\n",
    )
    .into_config()
    .expect("config");
    let m = dive_model::bind(ir, &cfg, &dive_model::BindOptions::tlc()).expect("bind");
    let p = Pred::new(m.ir.def(def).body, m.evaluator.scope(def).expect("scope"));
    (m, p)
}
fn policy() -> periodic_lifecycle::Options {
    periodic_lifecycle::Options {
        progress_interval: 0,
        ratio_limit: 0.0,
        ..Default::default()
    }
}
#[test]
fn actual_hooks_resume_stop_or_retain_original_errors_under_real_pauses() {
    for width in [1, 3, 4, 8] {
        for (expr, false_value, code) in [
            ("TRUE", false, 0),
            ("FALSE", true, 0),
            ("1", false, 1000),
            ("\"text\"", false, 1000),
            ("{1}", false, 1000),
            ("<<1>>", false, 1000),
            ("[a |-> 1]", false, 1000),
            ("1 \\div 0", false, 2179),
            ("Token", false, 0),
        ] {
            let (m, p) = model(expr, "[]<>(x>=0)");
            let opts = CheckOptions {
                workers: width,
                chaos: Some(7),
                ..CheckOptions::tlc(0, 0)
            };
            let run = periodic_hook::execute(&m, &p, &opts, Default::default(), policy())
                .expect("admitted");
            let e = run.hook_evaluations().first().expect("actual hook");
            assert_eq!(e.expression(), p.expr);
            assert_eq!(run.invocations()[0].workers(), width);
            if code != 0 {
                let error = e
                    .result()
                    .as_ref()
                    .expect_err("comparison/evaluation error");
                assert_eq!(error.ec().code(), code);
                assert!(error.origin().is_some());
                assert!(matches!(
                    run.backend().stop().expect("stop").error,
                    phase_graph::Error::PeriodicEvaluation(_)
                ));
                assert!(!run.invocations()[0].resume_requested());
                assert!(run.safety_eof().is_none());
            } else {
                assert_eq!(e.result().as_ref().expect("result"), &false_value);
                if false_value {
                    assert!(matches!(
                        run.invocations()[0].outcome(),
                        Ok(periodic::Outcome::PeriodicAssumptionFalse)
                    ));
                    assert!(!run.invocations()[0].resume_requested());
                    assert!(run.safety_eof().is_none());
                } else {
                    assert!(run.invocations().iter().all(|i| i.resume_requested()));
                    assert!(run.safety_eof().is_some());
                }
            }
            assert!(!run.model_proof());
        }
    }
}
#[test]
fn earlier_temporal_candidate_skips_false_hook_and_leaves_force_pending() {
    let (m, p) = model("FALSE", "<>(x=3)");
    for width in [1, 3, 4, 8] {
        let opts = CheckOptions {
            workers: width,
            ..CheckOptions::tlc(0, 0)
        };
        let run = periodic_hook::execute(
            &m,
            &p,
            &opts,
            Default::default(),
            periodic_lifecycle::Options {
                force: true,
                progress_interval: 0,
                ..Default::default()
            },
        )
        .expect("admitted");
        assert!(run.hook_evaluations().is_empty());
        assert_eq!(run.invocations()[0].force(), (true, true));
        assert!(matches!(
            run.invocations()[0].outcome(),
            Ok(periodic::Outcome::LivenessStopped(2116))
        ));
        assert!(run.safety_eof().is_none());
    }
}
#[test]
fn zero_state_guard_rejects_state_temporal_unknown_or_unbounded_before_execution() {
    for expr in [
        "x=0",
        "x'=0",
        "FALSE /\\ x=0",
        "<>(x=0)",
        "\\E i \\in 1..100 : i=0",
        "SUBSET {1}",
    ] {
        let (m, p) = model(expr, "[]<>(x>=0)");
        let err = periodic_hook::execute(
            &m,
            &p,
            &CheckOptions::tlc(0, 0),
            Default::default(),
            policy(),
        )
        .expect_err("named refusal");
        assert_eq!(err.class(), dive_eval::ErrorClass::Unsupported);
        assert!(err.to_string().contains("DIVE-L0057"));
    }
    let (m, mut p) = model("TRUE", "[]<>(x>=0)");
    p.expr = dive_ir::ExprId(u32::MAX);
    assert!(
        periodic_hook::execute(
            &m,
            &p,
            &CheckOptions::tlc(0, 0),
            Default::default(),
            policy()
        )
        .is_err()
    );
    let (_, foreign) = model("TRUE", "[]<>(x>=0)");
    assert!(
        periodic_hook::execute(
            &m,
            &foreign,
            &CheckOptions::tlc(0, 0),
            Default::default(),
            policy()
        )
        .is_err()
    );
    let mut foreign_model = m.clone();
    foreign_model.names = Arc::new(dive_value::Interner::new());
    let (_, p) = model("TRUE", "[]<>(x>=0)");
    assert!(
        periodic_hook::execute(
            &foreign_model,
            &p,
            &CheckOptions::tlc(0, 0),
            Default::default(),
            policy()
        )
        .is_err()
    );
}
#[test]
fn graph_quota_is_charged_before_hook_and_configured_binder_still_refuses() {
    let (m, p) = model("TRUE", "[]<>(x>=0)");
    let mut limits = phase_graph::Limits::default();
    limits.graph.steps = 1;
    let run = periodic_hook::execute(&m, &p, &CheckOptions::tlc(0, 0), limits, policy())
        .expect("admitted shape");
    assert!(run.hook_evaluations().is_empty());
    assert!(run.backend().stop().is_some());
    assert!(run.safety_eof().is_none());
    let cfg = dive_config::parse(
        "CONSTANT Token=Atom\nINIT Init\nNEXT Next\nPROPERTY Live\n_PERIODIC Hook\n",
    )
    .into_config()
    .expect("config");
    let error = dive_model::bind(m.ir.clone(), &cfg, &dive_model::BindOptions::tlc())
        .expect_err("still unsupported");
    assert!(error.to_string().contains("_PERIODIC"));
}

#[test]
fn captured_effects_unused_effect_arguments_and_redirects_do_not_print() {
    for body in [
        "PrintT(v)",
        "LET Ignore(ignored) == TRUE IN Ignore(PrintT(v))",
    ] {
        let source = format!(
            "---- MODULE EffectHook ----\nEXTENDS Integers,TLC\nVARIABLE x\nInit == x=0\nNext == UNCHANGED x\nLive == []<>(x>=0)\nHook(v) == {body}\n====\n"
        );
        let a = dive_sema::analyze_source("EffectHook.tla", &source, &Default::default());
        let ir = Arc::new(dive_ir::lower(&a).expect("IR"));
        let def = dive_ir::DefId(
            u32::try_from(
                ir.defs()
                    .iter()
                    .position(|d| d.name == "Hook")
                    .expect("Hook"),
            )
            .expect("id"),
        );
        let cfg = dive_config::parse("INIT Init\nNEXT Next\nPROPERTY Live\nCHECK_DEADLOCK FALSE\n")
            .into_config()
            .expect("cfg");
        let m = dive_model::bind(ir, &cfg, &dive_model::BindOptions::tlc()).expect("model");
        let root = m.evaluator.scope(def).expect("scope");
        let called = m
            .evaluator
            .scope_call_values(&root, def, vec![dive_value::Value::Bool(true)])
            .expect("captured scope");
        let p = Pred::new(m.ir.def(def).body, called);
        assert!(m.evaluator.take_output().is_empty());
        assert!(
            periodic_hook::execute(
                &m,
                &p,
                &CheckOptions::tlc(0, 0),
                Default::default(),
                policy()
            )
            .is_err()
        );
        assert!(m.evaluator.take_output().is_empty());
    }
    let (m, p) = model("Token", "[]<>(x>=0)");
    let cfg = dive_config::parse(
        "CONSTANT Token <- Init\nINIT Init\nNEXT Next\nPROPERTY Live\nCHECK_DEADLOCK FALSE\n",
    )
    .into_config()
    .expect("cfg");
    let redirected = dive_model::bind(m.ir.clone(), &cfg, &dive_model::BindOptions::tlc())
        .expect("redirected model");
    let def = dive_ir::DefId(
        u32::try_from(
            m.ir.defs()
                .iter()
                .position(|d| d.name == "Hook")
                .expect("Hook"),
        )
        .expect("id"),
    );
    let redirected_pred = Pred::new(p.expr, redirected.evaluator.scope(def).expect("own scope"));
    assert!(
        periodic_hook::execute(
            &redirected,
            &redirected_pred,
            &CheckOptions::tlc(0, 0),
            Default::default(),
            policy()
        )
        .is_err()
    );
}
