---- MODULE Periodic ----
EXTENDS Integers,TLC
CONSTANT Token
VARIABLE x
Init == x=0
Next == x'=1-x
Live == []<>(x=1)
Hook == {1}
HookArg(v) == v
====
