from pathlib import Path
import hashlib,json,re
b=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((b/'capture.json').read_text());assert len(c['rows'])==9
for n,h in c['sources'].items():assert sha(b/n)==h
for r in c['rows']:
 d=b/f"{r['scenario']}-{r['width']}";s=r['scenario'];w=r['width'];assert not r['timeout']
 for n,h in r['sha256'].items():assert sha(d/n)==h
 e=[l[6:]for l in(d/'stdout').read_text().splitlines()if l.startswith('EVENT\t')];assert e==r['events']
 assert not any(x.startswith('injector-error:')for x in e)
 assert e.index('actual-root0-written-before-request')<e.index('controlled-request-in-flight')<e.index('suspend-enter')<e.index('real-stop-before-next-release')<e.index('suspend-return:true')
 before=[x for x in e if x.startswith('root-record-identity:before-request:')and ':0:15040402659625261443:'in x];assert before and any(0<=int(x.rsplit(':',1)[1])<0x4000000000000000 for x in before)
 assert 'resumeAll'not in e
 stderr=(d/'stderr').read_text()
 if s=='nonempty-hook-error':
  assert r['exit']==2 and 'exception-code:2179'in e and 'cleanup-joined'not in e
  assert stderr.splitlines().count('"actual-hook-service"')==2
 elif s=='nonempty-hook-false-repeat':
  assert r['exit']==0 and 'runTLC-result:2104'in e and 'second-service-result:2104'in e
  assert stderr.splitlines().count('"actual-hook-service"')==3
  first=[x.replace(':run-return:',':same:')for x in e if x.startswith(('graph-size:run-return:','root-record-identity:run-return:'))]
  second=[x.replace(':second-service-return:',':same:')for x in e if x.startswith(('graph-size:second-service-return:','root-record-identity:second-service-return:'))];assert first==second
 else:
  assert r['exit']==0 and 'runTLC-result:2116'in e
  assert stderr.splitlines().count('"actual-hook-service"')==1 #startup only, deciding candidate precedes periodic hook
  assert re.search(r'State 1: <Initial predicate>\s+x = 0\s+State 2: Stuttering',stderr)
  source=(d/'Prefix.tla').read_text();assert "Next == Gate(x) /\\ x' = x"in source and 'Live == <>(x=999)'in source
  #Retained word0 stutter satisfies actual Init/Next, no WF/SF, falsifies eventual999. This syntactic witness check is not native independent validator credit.
files={str(p.relative_to(b)):sha(p)for p in b.rglob('*')if p.is_file()and'meta'not in p.relative_to(b).parts and p.name not in ['independent-readback.json','readback-closed.log']}
(b/'independent-readback.json').write_text(json.dumps(dict(all9_rows_passed=True,artifact_sha256=files,scope='Actual controlled nonempty service/unchanged graph repeat/candidate-before-hook. Simple exact original stuttering word retained and checked syntactically, no native validator or ordinary schedule credit'),indent=2)+'\n')
print('PASS9 controlled nonempty-service rows',len(files),'artifacts')
