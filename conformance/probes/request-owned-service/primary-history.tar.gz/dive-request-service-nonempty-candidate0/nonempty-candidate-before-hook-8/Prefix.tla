---- MODULE Prefix ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..8
Gate(v) == TRUE
Next == Gate(x) /\ x' = x
Live == <>(x=999)
Hook == PrintT("actual-hook-service") /\ (FALSE)
====
