---- MODULE Prefix ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..10
Gate(v) == TRUE
Next == Gate(x) /\ x' = x
Live == []<>(x >= 0)
Hook == PrintT("actual-hook-service") /\ (FALSE)
====
