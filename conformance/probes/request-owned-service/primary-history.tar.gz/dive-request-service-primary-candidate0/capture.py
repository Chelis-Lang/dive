from pathlib import Path
import hashlib,json,subprocess,time
base=Path(__file__).resolve().parent
cache=Path('/Users/jeff/code/dive-periodic-snapshot-cache')
java=cache/'jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java'
javac=Path('/tmp/claude-501/-Users-jeff-code-dive/7ef721df-a0bf-48ac-94b6-f7c0c8e766e7/scratchpad/jdk/jdk-17.0.20.1+1/Contents/Home/bin/javac')
jar=cache/'sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(jar)=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
r=subprocess.run([str(javac),'-cp',str(jar),'-d',str(base/'classes'),str(base/'EmptyServiceProbe.java'),str(base/'Prefix.java'),str(base/'ObservedTool.java'),str(base/'PrefixSignals.java')],capture_output=True)
(base/'compile.stdout').write_bytes(r.stdout);(base/'compile.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode()
rows=[]
for width in [1,4,8]:
 for scenario in ['empty-hook-true','empty-hook-false','empty-hook-false-repeat','empty-hook-error','empty-candidate','empty-failed-init']:
  d=base/f'{scenario}-{width}';d.mkdir(exist_ok=True)
  hook='FALSE' if scenario in ['empty-hook-false','empty-hook-false-repeat'] else '1 \div 0' if scenario=='empty-hook-error' else 'TRUE'
  source=f"---- MODULE Prefix ----\nEXTENDS Integers,TLC\nVARIABLE x\nInit == x \\in 0..{width-1}\nGate(v) == TRUE\nNext == Gate(x) /\\ x' = x\nLive == []<>(x >= 0)\nBad == <>(x=999)\nInv == x < 0\nHook == PrintT(\"actual-hook-service\") /\\ ({hook})\n====\n"
  config='INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE\nPROPERTY '+('Bad' if scenario=='empty-candidate' else 'Live')+'\n_PERIODIC Hook\n'
  if scenario=='empty-failed-init':config+='INVARIANT Inv\n'
  (d/'Prefix.tla').write_text(source);(d/'Prefix.cfg').write_text(config)
  cmd=[str(java),'-cp',str(base/'classes')+':'+str(jar),'EmptyServiceProbe',str(width),scenario]
  start=time.monotonic()
  try:r=subprocess.run(cmd,cwd=d,capture_output=True,timeout=22);code=r.returncode;out=r.stdout;err=r.stderr;timeout=False
  except subprocess.TimeoutExpired as e:code=None;out=e.stdout or b'';err=e.stderr or b'';timeout=True
  (d/'stdout').write_bytes(out);(d/'stderr').write_bytes(err)
  rows.append(dict(scenario=scenario,width=width,exit=code,timeout=timeout,seconds=time.monotonic()-start,command=cmd,events=[line[6:] for line in out.decode(errors='replace').splitlines() if line.startswith('EVENT\t')],sha256={name:sha(d/name) for name in ['Prefix.tla','Prefix.cfg','stdout','stderr']}))
  print(scenario,width,code,timeout,flush=True)
record=dict(oracle_sha256=sha(jar),java_sha256=sha(java),javac_sha256=sha(javac),sources={name:sha(base/name) for name in ['EmptyServiceProbe.java','Prefix.java','ObservedTool.java','PrefixSignals.java','FastTool.java.pinned','capture.py']},rows=rows,scope='Actual doPeriodicWork with genuine StateQueue stop observed before actual Worker construction/start. Real queue proxy installed before Worker constructor, delegates all methods unchanged. Init/graph/liveness/hook bodies are original model authorities. Forced request/start gate is controlled, not natural clock or ordinary verdict/count evidence. Queue stop/reflection read only. Resume may admit real Next work before service-return observation. Cleanup finish/join separate from doPeriodicWork.' )
(base/'capture.json').write_text(json.dumps(record,indent=2)+'\n')
