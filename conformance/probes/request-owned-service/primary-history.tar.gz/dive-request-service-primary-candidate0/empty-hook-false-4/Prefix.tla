---- MODULE Prefix ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..3
Gate(v) == TRUE
Next == Gate(x) /\ x' = x
Live == []<>(x >= 0)
Bad == <>(x=999)
Inv == x < 0
Hook == PrintT("actual-hook-service") /\ (FALSE)
====
