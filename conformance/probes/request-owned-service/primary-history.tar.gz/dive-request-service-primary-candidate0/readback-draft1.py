from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((b/'capture.json').read_text());assert len(c['rows'])==18
for name,d in c['sources'].items():assert sha(b/name)==d
for row in c['rows']:
 d=b/f"{row['scenario']}-{row['width']}"
 for name,h in row['sha256'].items():assert sha(d/name)==h
 assert not row['timeout']
 raw=(d/'stdout').read_text();events=[line[6:]for line in raw.splitlines()if line.startswith('EVENT\t')];assert events==row['events']
 s=row['scenario'];w=row['width']
 if s=='empty-failed-init':
  assert 'failed-init-no-start'in events and not any(e in events for e in ['start-workers','actual-service-start','suspend-enter'])
  assert row['exit']==0
  assert (d/'stderr').read_text().splitlines().count('\"actual-hook-service\"')==1 #startup, no periodic service
  continue
 assert events.index('suspend-enter')<events.index('real-queue-stop-before-worker-start')<events.index('start-workers')<events.index('suspend-return:true')
 first=events.index('suspend-return:true');assert not any(e.startswith('next-body-enter:')for e in events[:first+1])
 assert 'graph-size:suspend-return:0:0'in events
 roots=[e for e in events if e.startswith('root-record:suspend-return:')];assert len(roots)==w*(2 if s=='empty-hook-false-repeat'else 1)and all(e.endswith(':-1')for e in roots)
 assert (d/'stderr').read_text().splitlines().count('\"actual-hook-service\"')==(3 if s=='empty-hook-false-repeat'else 2) #one baseline startup evaluation, retained separately
 if s=='empty-hook-error':
  assert row['exit']==2 and 'actual-service-exception-code:2179'in events and 'resumeAll'not in events
 elif s in ['empty-hook-false','empty-hook-false-repeat']:
  assert row['exit']==0 and 'actual-service-result:2104'in events and 'resumeAll'not in events
  if s.endswith('repeat'):assert 'second-service-result:2104'in events
 else:
  assert row['exit']==0 and 'actual-service-result:0'in events and 'resumeAll'in events
 assert 'observer-cleanup-start'in events and 'cleanup-joined'in events
files={str(p.relative_to(b)):sha(p)for p in b.rglob('*')if p.is_file()and'meta'not in p.relative_to(b).parts and p.name!='independent-readback.json'}
(b/'independent-readback.json').write_text(json.dumps(dict(all18_rows_passed=True,artifact_sha256=files,scope='Controlled actual empty-service reference, no ordinary native/clock/count certification'),indent=2)+'\n')
print('PASS18 complete controlled empty-service rows',len(files),'artifacts')
