import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.nio.file.*;
import tlc2.*;
import tlc2.tool.*;
import tlc2.tool.impl.*;
import tlc2.tool.fp.*;
import tlc2.tool.queue.*;
import tlc2.util.*;
import util.*;

/** Real local Worker/runTLC/queue execution; request injection is controlled. */
public final class EmptyServiceProbe {
 static void event(String s){PrefixSignals.event(s);}
 static class Observed extends ModelChecker {
  Observed(ITool t,String dir)throws Exception{super(t,dir,writer(),false,null,new FPSetConfiguration(),System.currentTimeMillis());}
  protected IWorker[] startWorkers(AbstractChecker c,int depth){event("start-workers");return super.startWorkers(c,depth);}
  protected void runTLCContinueDoing(int count,int depth)throws Exception{event("progress-wait");super.runTLCContinueDoing(count,depth);}
  protected void updateRuntimeRatio(long delta){event("ratio-update:"+delta);super.updateRuntimeRatio(delta);}
  void snapshot(String phase)throws Exception {
   for(int i=0;i<liveCheck.getNumChecker();i++){
    var check=liveCheck.getChecker(i);
    synchronized(check.getSolution()){
     var graph=check.getDiskGraph();
     event("graph-size:"+phase+":"+i+":"+graph.size());
     for(var entry:roots.entrySet())event("root-record:"+phase+":"+i+":"+PrefixSignals.x(entry.getValue())+":"+Long.toUnsignedString(entry.getKey())+":"+graph.getPtr(entry.getKey(),-1));
    }
   }
  }
  int error()throws Exception {Field f=AbstractChecker.class.getDeclaredField("errorCode");f.setAccessible(true);synchronized(this){return (int)f.get(this);}}
  void releaseInitialWait(){synchronized(this){notifyAll();}}
  void closeWorkers()throws Exception{theStateQueue.finishAll();for(IWorker w:workers)((Thread)w).join(5000);for(IWorker w:workers)if(((Thread)w).isAlive())throw new AssertionError("unjoined cleanup worker");event("cleanup-joined");}
  int alive(){int n=0;for(IWorker w:workers)if(((Thread)w).isAlive())n++;return n;}
  int finalCheck()throws Exception{return liveCheck.finalCheck(tool.noDebug());}
 }
 static final Map<Long,TLCState> roots=new ConcurrentHashMap<>();
 static IStateWriter writer(){
  NoopStateWriter real=new NoopStateWriter();
  return (IStateWriter)Proxy.newProxyInstance(EmptyServiceProbe.class.getClassLoader(),new Class<?>[]{IStateWriter.class},(p,m,args)->{
   if(m.getName().equals("writeState")&&args.length==1){TLCState st=(TLCState)args[0];roots.put(st.fingerPrint(),st);event("initial-record:"+PrefixSignals.x(st));}
   if(m.getName().equals("writeState")&&args.length==4&&args[3]==IStateWriter.Visualization.STUTTERING){event("before-doNextCheckLiveness-write:"+PrefixSignals.x((TLCState)args[0])+":"+Thread.currentThread().getName());}
   return invoke(real,m,args);
  });
 }
 static Object invoke(Object target,Method method,Object[] args)throws Throwable{try{return method.invoke(target,args);}catch(InvocationTargetException e){throw e.getCause();}}
 public static void run(String[] a)throws Throwable{
  int width=Integer.parseInt(a[0]);String scenario=a[1];
  ToolIO.setUserDir(System.getProperty("user.dir"));ToolIO.out=System.err;FP64.Init(0);
  TLCGlobals.setNumWorkers(width);TLCGlobals.chkptDuration=0;
  Tool real=new ObservedTool("Prefix","Prefix",new SimpleFilenameToStream(),Tool.Mode.MC,new HashMap<>());
  PrefixSignals.scenario=scenario;PrefixSignals.width=width;
  CountDownLatch expanding=PrefixSignals.early,release=PrefixSignals.release,suspend=new CountDownLatch(1);
  Observed checker=new Observed(real,Files.createDirectories(Path.of("meta")).toString());
  IStateQueue actual=checker.theStateQueue;
  checker.theStateQueue=(IStateQueue)Proxy.newProxyInstance(EmptyServiceProbe.class.getClassLoader(),new Class<?>[]{IStateQueue.class},(p,m,args)->{
   String name=m.getName();
   if(name.equals("suspendAll")){event("suspend-enter");checker.snapshot("suspend-enter");suspend.countDown();Object r=invoke(actual,m,args);event("suspend-return:"+r);event("first-next-gate-at-suspend-return:"+(!PrefixSignals.first.get()));checker.snapshot("suspend-return");return r;}
   if(name.equals("resumeAll")||name.equals("finishAll"))event(name);
   if(name.equals("sDequeue")){Object r=invoke(actual,m,args);event("dequeue:"+(r==null?"EOF":"state"));return r;}
   return invoke(actual,m,args);
  });
  event("assumptions:"+checker.checkAssumptions());int init=checker.doInit(false);event("init-result:"+init);
  if(init!=0){event("failed-init-no-start");System.exit(0);}
  if(!scenario.startsWith("empty-"))throw new AssertionError("unknown selection");
  checker.forceLiveCheck();
  final int[] result={-999};final Throwable[] failure={null};
  Thread service=new Thread(()->{try{event("actual-service-start");result[0]=checker.doPeriodicWork();event("actual-service-result:"+result[0]);}catch(Throwable t){failure[0]=t;event("actual-service-exception:"+t.getClass().getName());}},"actual-periodic-controller");
  service.start();
  Field stop=StateQueue.class.getDeclaredField("stop");stop.setAccessible(true);
  long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);boolean observed=false;
  while(System.nanoTime()<deadline){synchronized(actual){observed=stop.getBoolean(actual);}if(observed)break;Thread.sleep(1);}
  if(!observed)throw new AssertionError("no actual stop before Worker construction");
  event("real-queue-stop-before-worker-start");
  checker.startWorkers(checker,Integer.MAX_VALUE);
  service.join(10000);if(service.isAlive())throw new AssertionError("service did not finish");
  event("next-entered-at-service-return:"+(!PrefixSignals.first.get()));
  checker.snapshot("empty-service-return");event("generated-at-service-return:"+checker.getStatesGenerated());event("queue-at-service-return:"+actual.size());
  if(failure[0]!=null){event("actual-service-exception-code:"+(failure[0] instanceof EvalException?((EvalException)failure[0]).getErrorCode():-1));}
  if(scenario.equals("empty-hook-false-repeat")&&result[0]==2104){event("second-service-start");int second=checker.doPeriodicWork();event("second-service-result:"+second);checker.snapshot("second-service-return");}
  event("observer-cleanup-start");release.countDown();checker.closeWorkers();event("done");System.exit(failure[0]==null?0:2);
 }
 public static void main(String[] a)throws Throwable{
  try{run(a);}catch(Throwable t){event("exception-class:"+t.getClass().getName());
   int code=t instanceof EvalException?((EvalException)t).getErrorCode():t instanceof Assert.TLCRuntimeException?((Assert.TLCRuntimeException)t).errorCode:-1;
   event("exception-code:"+code);t.printStackTrace(System.err);System.exit(2);}
 }
}
