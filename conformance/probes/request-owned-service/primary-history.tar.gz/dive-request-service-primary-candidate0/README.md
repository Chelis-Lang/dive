# Controlled actual empty request service

This18-row selection uses the pinned real ModelChecker.doPeriodicWork with real
local Worker, StateQueue, LiveCheck, model binding and hook evaluation at widths
1/4/8. The controller starts first; read-only reflection waits for genuine
StateQueue.stop before actual Worker construction/start. Queue proxy delegates
all operations unchanged and is installed before workers cache their queue.

This is controlled startup/forced request evidence, not natural clock, ordinary
native suspension, count or model-verdict certification. No graph/queue facts are
supplied to the decision methods. Init and actual graph root registration come
from the model. TLC creates unwritten tableau registrations even where DiskGraph
size stays0. Every suspend-return has no preceding Next-body entry; successful
resume admits real Next execution which may race with later snapshots.

The configured hook has one real startup PrintT evaluation before Init, retained
separately from service output. Hook false returns2104 without resume; a repeated
second service on that same paused empty graph returns2104 again. Hook division
by zero yields actual EvalException2179/exit2. Failed Init starts neither workers
nor controller. A false eventual property with only unwritten initial tableau
registrations produces partial0, not a candidate and never Holds.

Cleanup finishAll/join is explicitly observer-owned after service, not original
doPeriodicWork behavior. All raw stdout/stderr including startup effects are
kept. The first two failed readback assumptions (startup marker count and using
DiskGraph size for tableau registration) are preserved alongside the corrected
closed readback; raw producer inputs/outputs were never rewritten.
