//! Genuine request service, empty-source provenance and stopping controls.
#![allow(clippy::expect_used, reason = "paired source-owned service controls")]
use dive_liveness::{periodic_lifecycle, periodic_snapshot, phase_graph};
use std::{sync::Arc, time::Duration};

fn snapshot(init: &str, next: &str, hook: &str, live: &str) -> periodic_snapshot::Snapshot {
    let source = format!(
        "---- MODULE Service ----\nEXTENDS Integers\nVARIABLE x\nInit == {init}\nNext == {next}\nLive == {live}\nHook == {hook}\n====\n"
    );
    let analysis =
        dive_sema::analyze_source("Service.tla", &source, &dive_sema::Options::default());
    let ir = Arc::new(dive_ir::lower(&analysis).expect("control IR"));
    let cfg = dive_config::parse(
        "INIT Init\nNEXT Next\nPROPERTY Live\n_PERIODIC Hook\nCHECK_DEADLOCK FALSE\n",
    )
    .into_config()
    .expect("config");
    periodic_snapshot::bind(ir, &cfg).expect("pure actual configured snapshot")
}
fn options(width: usize) -> dive_check::CheckOptions {
    dive_check::CheckOptions {
        workers: width,
        chaos: Some(7),
        ..dive_check::CheckOptions::tlc(0, 0)
    }
}
fn requests() -> dive_check::progress::Options {
    dive_check::progress::Options {
        interval: Duration::from_secs(3600),
        force: true,
    }
}
#[test]
fn initial_empty_false_service_has_no_invented_source_and_no_elapsed_suppression() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x=0", "UNCHANGED x", "FALSE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options {
                    progress_interval: i32::MAX,
                    ..periodic_lifecycle::Options::default()
                },
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.invocations().is_empty());
        assert!(run.hook_evaluations().is_empty());
        assert_eq!(run.request_services().len(), 1);
        assert_eq!(run.service_evaluations().len(), 1);
        let service = &run.request_services()[0];
        assert_eq!(service.graph_source(), None);
        assert!(service.committed().is_empty());
        assert!(service.request().forced());
        assert_eq!(service.initial_stats().distinct, 1);
        assert_eq!(service.stats().distinct, 1);
        assert_eq!(service.pool().0, width);
        assert!(!service.resume_requested());
        assert!(matches!(
            service.outcome(),
            Ok(dive_liveness::periodic::Outcome::PeriodicAssumptionFalse)
        ));
        assert_eq!(run.service_evaluations()[0].graph_source(), None);
        assert_eq!(
            run.service_evaluations()[0].request().sequence(),
            service.request().sequence()
        );
        assert_eq!(
            run.service_evaluations()[0].expression(),
            snapshot.predicate().expr
        );
        assert_eq!(
            run.service_evaluations()[0]
                .result()
                .as_ref()
                .expect("FALSE equals"),
            &true
        );
        assert!(run.safety_eof().is_none());
        assert!(run.final_checks().is_empty());
        assert!(!service.model_proof());
        assert!(!run.model_proof());
    }
}
#[test]
fn actual_empty_true_service_resumes_before_real_safety_eof() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x=0", "UNCHANGED x", "TRUE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert_eq!(run.request_services().len(), 1);
        let service = &run.request_services()[0];
        assert_eq!(service.graph_source(), None);
        assert!(service.committed().is_empty());
        assert!(service.resume_requested());
        assert!(matches!(
            service.outcome(),
            Ok(dive_liveness::periodic::Outcome::Complete)
        ));
        assert_eq!(run.safety_eof().expect("real EOF").left_on_queue, 0);
        assert!(run.backend().complete().is_some());
        assert!(!run.final_checks().is_empty());
        assert!(!run.model_proof());
        assert!(run.invocations().is_empty());
    }
}
#[test]
fn failed_init_never_services_the_initial_request() {
    for width in [1, 4, 8] {
        let snapshot = snapshot("x=1 \\div 0", "UNCHANGED x", "FALSE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.backend().stop().is_some());
        assert!(run.request_services().is_empty());
        assert!(run.service_evaluations().is_empty());
        assert!(run.expansion_pauses().is_empty());
        assert!(run.safety_eof().is_none());
    }
}

#[test]
fn real_nonempty_request_service_observes_the_appended_transaction_once() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x \\in 0..512", "x' \\in 0..512", "TRUE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options {
                    progress_interval: i32::MAX,
                    ..periodic_lifecycle::Options::default()
                },
                dive_check::progress::Options {
                    interval: Duration::from_millis(1),
                    force: false,
                },
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.invocations().is_empty());
        assert!(run.hook_evaluations().is_empty());
        assert_eq!(run.request_services().len(), run.expansion_pauses().len());
        assert_eq!(
            run.request_services().len(),
            run.service_evaluations().len()
        );
        let mut nonempty = 0;
        for (service, pause) in run.request_services().iter().zip(run.expansion_pauses()) {
            let receipt = pause.receipt();
            assert_eq!(service.request().sequence(), receipt.request().sequence());
            assert_eq!(service.submitted(), receipt.submitted());
            assert_eq!(service.committed(), receipt.committed());
            assert_eq!(service.committed(), receipt.frontier_appended());
            assert_eq!(service.stats(), receipt.committed_stats());
            assert_eq!(service.pool(), pause.pool());
            assert!(service.resume_requested());
            if !service.committed().is_empty() {
                nonempty += 1;
                assert_eq!(service.graph_source(), Some(service.committed().end - 1));
            }
        }
        assert!(nonempty > 0, "actual nonempty service required w{width}");
        assert_eq!(run.safety_eof().expect("real EOF").distinct, 513);
        assert!(!run.model_proof());
    }
}
