//! Genuine request service, empty-source provenance and stopping controls.
#![allow(clippy::expect_used, reason = "paired source-owned service controls")]
use dive_liveness::{periodic_lifecycle, periodic_snapshot, phase_graph};
use std::{sync::Arc, time::Duration};

fn snapshot(init: &str, next: &str, hook: &str, live: &str) -> periodic_snapshot::Snapshot {
    let source = format!(
        "---- MODULE Service ----\nEXTENDS Integers\nVARIABLE x\nInit == {init}\nNext == {next}\nLive == {live}\nHook == {hook}\n====\n"
    );
    let analysis =
        dive_sema::analyze_source("Service.tla", &source, &dive_sema::Options::default());
    let ir = Arc::new(dive_ir::lower(&analysis).expect("control IR"));
    let cfg = dive_config::parse(
        "INIT Init\nNEXT Next\nPROPERTY Live\n_PERIODIC Hook\nCHECK_DEADLOCK FALSE\n",
    )
    .into_config()
    .expect("config");
    periodic_snapshot::bind(ir, &cfg).expect("pure actual configured snapshot")
}
fn options(width: usize) -> dive_check::CheckOptions {
    dive_check::CheckOptions {
        workers: width,
        chaos: Some(7),
        ..dive_check::CheckOptions::tlc(0, 0)
    }
}
fn requests() -> dive_check::progress::Options {
    dive_check::progress::Options {
        interval: Duration::from_secs(3600),
        force: true,
    }
}
#[test]
fn initial_empty_false_service_has_no_invented_source_and_no_elapsed_suppression() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x=0", "UNCHANGED x", "FALSE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options {
                    progress_interval: i32::MAX,
                    ..periodic_lifecycle::Options::default()
                },
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.invocations().is_empty());
        assert!(run.hook_evaluations().is_empty());
        assert_eq!(run.request_services().len(), 1);
        assert_eq!(run.service_evaluations().len(), 1);
        let service = &run.request_services()[0];
        assert_eq!(service.graph_source(), None);
        assert!(service.committed().is_empty());
        assert!(service.request().forced());
        assert_eq!(service.initial_stats().distinct, 1);
        assert_eq!(service.stats().distinct, 1);
        assert_eq!(service.pool().0, width);
        assert!(!service.resume_requested());
        assert!(matches!(
            service.outcome(),
            Ok(dive_liveness::periodic::Outcome::PeriodicAssumptionFalse)
        ));
        assert_eq!(run.service_evaluations()[0].graph_source(), None);
        assert_eq!(
            run.service_evaluations()[0].request().sequence(),
            service.request().sequence()
        );
        assert_eq!(
            run.service_evaluations()[0].expression(),
            snapshot.predicate().expr
        );
        assert_eq!(
            run.service_evaluations()[0]
                .result()
                .as_ref()
                .expect("FALSE equals"),
            &true
        );
        assert!(run.safety_eof().is_none());
        assert!(run.final_checks().is_empty());
        assert!(!service.model_proof());
        assert!(!run.model_proof());
    }
}
#[test]
fn actual_empty_true_service_resumes_before_real_safety_eof() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x=0", "UNCHANGED x", "TRUE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert_eq!(run.request_services().len(), 1);
        let service = &run.request_services()[0];
        assert_eq!(service.graph_source(), None);
        assert!(service.committed().is_empty());
        assert!(service.resume_requested());
        assert!(matches!(
            service.outcome(),
            Ok(dive_liveness::periodic::Outcome::Complete)
        ));
        assert_eq!(run.safety_eof().expect("real EOF").left_on_queue, 0);
        assert!(run.backend().complete().is_some());
        assert!(!run.final_checks().is_empty());
        assert!(!run.model_proof());
        assert!(run.invocations().is_empty());
    }
}
#[test]
fn failed_init_never_services_the_initial_request() {
    for width in [1, 4, 8] {
        let snapshot = snapshot("x=1 \\div 0", "UNCHANGED x", "FALSE", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.backend().stop().is_some());
        assert!(run.request_services().is_empty());
        assert!(run.service_evaluations().is_empty());
        assert!(run.expansion_pauses().is_empty());
        assert!(run.safety_eof().is_none());
    }
}

#[test]
fn requested_default_or_mixed_evaluator_mode_refuses_before_service_setup() {
    let snapshot = snapshot("x=0", "UNCHANGED x", "FALSE", "[]<>(x=0)");
    for options in [
        dive_check::CheckOptions::dive(0),
        dive_check::CheckOptions {
            eval: dive_eval::Options::dive(),
            ..options(4)
        },
    ] {
        let error = snapshot
            .execute_service(
                &options,
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .err()
            .expect("mode refusal");
        assert!(
            error
                .to_string()
                .contains("matching TLC checker/evaluator mode")
        );
        assert!(snapshot.model().output.is_empty());
    }
}

#[test]
fn empty_request_preserves_actual_hook_evaluation_error_and_does_not_resume() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot("x=0", "UNCHANGED x", "1 \\div 0", "[]<>(x=0)");
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options::default(),
                requests(),
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert_eq!(run.request_services().len(), 1);
        assert_eq!(run.service_evaluations().len(), 1);
        let service = &run.request_services()[0];
        assert_eq!(service.graph_source(), None);
        assert!(service.committed().is_empty());
        assert!(service.outcome().is_err());
        assert!(!service.resume_requested());
        assert_eq!(
            run.service_evaluations()[0]
                .result()
                .as_ref()
                .expect_err("typed eval error")
                .ec()
                .code(),
            2179
        );
        assert!(run.safety_eof().is_none());
        assert!(run.final_checks().is_empty());
    }
}

#[test]
fn real_nonempty_request_service_observes_the_appended_transaction_once() {
    for width in [1, 3, 4, 8] {
        let snapshot = snapshot(
            "x \\in 0..8",
            "IF x=0 THEN x' \\in 0..8 ELSE \\E i \\in 1..4096: x'=x",
            "TRUE",
            "[]<>(x>=0)",
        );
        let result = snapshot
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options {
                    progress_interval: i32::MAX,
                    ..periodic_lifecycle::Options::default()
                },
                dive_check::progress::Options {
                    interval: Duration::from_millis(1),
                    force: false,
                },
            )
            .expect("admitted");
        let run = result.lifecycle();
        assert!(run.invocations().is_empty());
        assert!(run.hook_evaluations().is_empty());
        assert_eq!(run.request_services().len(), run.expansion_pauses().len());
        assert_eq!(
            run.request_services().len(),
            run.service_evaluations().len()
        );
        let mut nonempty = 0;
        for (service, pause) in run.request_services().iter().zip(run.expansion_pauses()) {
            let receipt = pause.receipt();
            assert_eq!(service.request().sequence(), receipt.request().sequence());
            assert_eq!(service.submitted(), receipt.submitted());
            assert_eq!(service.committed(), receipt.committed());
            assert_eq!(service.committed(), receipt.frontier_appended());
            assert_eq!(service.stats(), receipt.committed_stats());
            assert_eq!(service.pool(), pause.pool());
            assert!(service.resume_requested());
            if !service.committed().is_empty() {
                nonempty += 1;
                assert_eq!(service.graph_source(), Some(service.committed().end - 1));
            }
        }
        assert!(nonempty > 0, "actual nonempty service required w{width}");
        assert_eq!(run.safety_eof().expect("real EOF").distinct, 9);
        assert!(!run.model_proof());
    }
}

fn concrete_word(
    run: &dive_liveness::periodic_backend::Run,
    check: &dive_liveness::phase_execution::PartialCheck,
) -> (Vec<dive_eval::next::StateVals>, usize) {
    use std::collections::BTreeMap;
    let c = check.selection().candidate().expect("candidate");
    let ids = check.identities();
    let groups = run
        .stop()
        .map(|s| &s.groups)
        .or_else(|| run.complete().map(|s| &s.groups))
        .expect("actual groups");
    let representatives: BTreeMap<_, _> = groups[check.group()]
        .commits
        .iter()
        .map(|commit| {
            let original = commit
                .receipt
                .successors
                .iter()
                .find(|s| s.fingerprint == commit.fingerprint)
                .expect("actual source stutter");
            (commit.fingerprint, original.state.clone())
        })
        .collect();
    let mut prefix = Vec::new();
    for i in c.prefix_reverse.iter().rev() {
        let fp = ids[*i].fingerprint;
        if prefix.last() != Some(&fp) {
            prefix.push(fp);
        }
    }
    let anchor = ids[c.anchor].fingerprint;
    assert_eq!(prefix.last(), Some(&anchor));
    let back = prefix.len() - 1;
    let mut reverse = c.closure_reverse.clone();
    for i in c.cycle_stack.iter().rev() {
        let fp = ids[*i].fingerprint;
        if reverse.last() != Some(&fp) {
            reverse.push(fp);
        }
    }
    reverse.dedup();
    if reverse.last() == Some(&anchor) {
        reverse.pop();
    }
    prefix.extend(reverse.into_iter().rev());
    (
        prefix
            .into_iter()
            .map(|fp| representatives[&fp].clone())
            .collect(),
        back,
    )
}

#[test]
fn appended_request_candidate_precedes_hook_and_replays_against_fresh_binding() {
    for width in [1, 3, 4, 8] {
        let bound = snapshot("x=0", "\\E i \\in 1..1024: x'=x+1", "TRUE", "<>(x=2)");
        let run = bound
            .execute_service(
                &options(width),
                phase_graph::Limits::default(),
                periodic_lifecycle::Options {
                    force: true,
                    progress_interval: i32::MAX,
                    ..periodic_lifecycle::Options::default()
                },
                dive_check::progress::Options {
                    interval: Duration::from_millis(1),
                    force: true,
                },
            )
            .expect("actual admitted service");
        let run = run.lifecycle();
        let service = run.request_services().last().expect("deciding request");
        assert!(!service.committed().is_empty());
        assert!(!service.resume_requested());
        assert!(matches!(
            service.outcome(),
            Ok(dive_liveness::periodic::Outcome::LivenessStopped(_))
        ));
        assert_eq!(
            run.request_services().len(),
            run.service_evaluations().len() + 1
        );
        assert_eq!(
            run.expansion_pauses()
                .last()
                .expect("actual append")
                .receipt()
                .frontier_appended(),
            service.committed()
        );
        assert!(run.safety_eof().is_none());
        let check = run
            .backend()
            .checks()
            .iter()
            .find(|c| c.selection().candidate().is_some())
            .expect("candidate");
        let (states, back_to) = concrete_word(run.backend(), check);
        let fresh = snapshot("x=0", "\\E i \\in 1..1024: x'=x+1", "TRUE", "<>(x=2)");
        assert!(
            !dive_trace::temporal::evaluate_lasso(
                fresh.model(),
                &fresh.model().implied_temporals[0].pred,
                &states,
                back_to
            )
            .expect("independent word")[0]
        );
        let trace = dive_trace::Trace {
            labels: vec![None; states.len()],
            length: Some(states.len()),
            states,
            ending: dive_trace::Ending::Lasso { back_to },
            properties: vec!["Live".into()],
        };
        assert_eq!(
            dive_trace::validate(fresh.model(), &trace, None).validation,
            dive_trace::Validation::Valid
        );
        let doc = trace.to_doc(fresh.model()).expect("transport");
        let doc = dive_trace::TraceDoc::from_json(
            &serde_json::from_slice(&serde_json::to_vec(&doc.to_json()).expect("serialize"))
                .expect("JSON"),
        )
        .expect("decode");
        assert_eq!(
            dive_trace::validate_doc(fresh.model(), &doc, &[], None)
                .0
                .validation,
            dive_trace::Validation::Valid
        );
        for mutation in 0..4 {
            let mut bad = doc.clone();
            match mutation {
                0 => bad.properties = vec!["Forged".into()],
                1 => {
                    bad.states[0] =
                        serde_json::from_value(serde_json::json!({"x":99})).expect("wrong Init")
                }
                2 => {
                    bad.ending = Some(dive_trace::Ending::Lasso { back_to: 0 });
                    assert_eq!(
                        dive_trace::validate_doc(fresh.model(), &bad, &[], None)
                            .0
                            .validation,
                        dive_trace::Validation::Valid
                    );
                    bad.states.push(
                        serde_json::from_value(serde_json::json!({"x":1}))
                            .expect("valid successor"),
                    );
                    bad.labels.push(None);
                    bad.length = Some(bad.states.len());
                }
                _ => {
                    bad.ending = Some(dive_trace::Ending::Lasso {
                        back_to: usize::MAX,
                    })
                }
            }
            let outcome = dive_trace::validate_doc(fresh.model(), &bad, &[], None)
                .0
                .validation;
            assert_ne!(outcome, dive_trace::Validation::Valid);
            if mutation == 2 {
                assert!(format!("{outcome:?}").contains("Next"));
            }
        }
        assert!(!run.model_proof());
    }
}
