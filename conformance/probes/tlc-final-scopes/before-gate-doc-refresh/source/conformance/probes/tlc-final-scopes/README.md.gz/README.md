# Scoped explicit-final temporal controls (#134)

All18 fixtures are retained in selection order. The actual clean pin runs with
workers1,seed0,fp0 and final scheduling, without dumpTrace. Java projection helpers
observe exact normalization, groups, particles, component/anchor/word fields and
three distinct attribution vectors. Sixteen projections complete/two fail.
Fourteen genuine temporal models have primary0/13 verdicts; two state properties
have primary0/12 safety verdicts. Forced fairness-only final projections on those
two are diagnostic and earn no temporal outcome credit. Exported temporal-formal
INSTANCE failures2213/255 remain explicit uncredited refusals.

Current native capture retains72 rows at1/3/4/8:28validated temporal violations,
28temporal holds,4validated safety violations,4safety holds,8named refusals.
The Rust controls compare every exposed normalized and actual group field,
particle/edge, source bin, original configured claim and derived role. The
reference per-expanded-action original vector is unclaimed until a native field
exists. 3,136 independent periodic word/closing controls cover both profiles;
malformed witnesses and derived/foreign/empty claims cannot validate. Purity,
opaque and infinite-action controls plus unchanged tiny formula/work bounds
remain explicit. This is bounded final fidelity, not ordinary periodic/family
certification or a fresh whole140 corpus result.

Original sixteen selection/captures, pre-repair64native outcomes and three
failed source/log snapshots are immutable history. Current source matrices
retarget only current authority; old producer captures/gates retain their exact
archived bytes. The user guide is docs/tlc-final-scopes.md and the runnable Rust
program is user-example.rs. The checker is scripts/check-tlc-final-scopes.py.

Reproduce the Java helpers with capture.py/capture-clean.py/capture-final.py and
--java,--javac(where used),--jar plus a recorded --reason, using the pinned
bundle in an isolated cache. Capture-native.py takes --binary and a new --out.
The independent source/word/API tests are tlc_final_scopes in dive-api and
in dive-liveness. Original mismatch evidence is never promoted to agreement.
