import json,hashlib,subprocess
from pathlib import Path
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldscope='encoded current and next frontier queues only; legacy value-frontier heap, candidates, seen sets, traces and graphs are not measured or bounded';newscope='encoded current and next frontier queues only; legacy value-frontier heap, candidates, seen sets, traces, graphs and native archive work are not measured or bounded'
rows=[];explanations=[]
for kind,old,fresh,count in [('material','conformance/probes/material-capture/native-current','/tmp/dive-material-process-current-material',64),('general','conformance/probes/material-capture/native-general-current','/tmp/dive-material-process-current-material-general',8),('origins','conformance/probes/tlc-final-property-origins/native-current','/tmp/dive-material-process-current-origins',72)]:
 old=Path(old);fresh=Path(fresh);a=json.loads((old/'capture.json').read_text());b=json.loads((fresh/'capture.json').read_text());assert len(b['rows'])==count and b['source_and_binary_unchanged'];lookup={(r.get('model',r.get('name')),r['requested_workers']):r for r in a['rows']};assert len(lookup)==count
 for n,h in b['source_sha256'].items():assert sha(root/n)==h
 for r in b['rows']:
  key=(r['model'],r['requested_workers']);o=lookup[key];assert r['exit']==o['exit'] and not r['timeout'];label=f'{key[0]}-{key[1]}'
  for stream in ['stdout','stderr']:assert sha(fresh/label/stream)==r[stream+'_sha256']
  x=json.loads((old/label/'stdout').read_text());y=json.loads((fresh/label/'stdout').read_text())
  for omitted in ['elapsed_ms','file','config']:x.pop(omitted,None);y.pop(omitted,None)
  if (x.get('frontier_storage') or {}).get('scope')!=(y.get('frontier_storage') or {}).get('scope'):
   assert x['frontier_storage']['scope']==oldscope and y['frontier_storage']['scope']==newscope;explanations.append({'kind':kind,'model':key[0],'workers':key[1],'field':'frontier_storage.scope','before':oldscope,'after':newscope});x['frontier_storage']['scope']=newscope
  assert x==y,(kind,key,'unexpected semantic document difference');rows.append({'kind':kind,'model':key[0],'workers':key[1],'exit':r['exit'],'verdict':y['verdict'],'semantic_document_equal':True,'stdout_sha256':r['stdout_sha256']})
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='68783d541c97e2ef481344a50d81db1869870128'
d={'source_commit':source,'fresh_binary_producer':json.loads(Path('/Users/jeff/code/dive-material-process-artifacts/producer.json').read_text()),'complete_native_rows':len(rows),'ignored_comparison_fields':['elapsed_ms','file','config'],'exact_explanatory_text_changes':explanations,'rows':rows,'family_certified':False,'scope':'Fresh complete selected native outcomes and all semantic fields equal. An explicit shipped storage-scope explanation update is checked for exact old/new text; no statistics, verdict, diagnostic code, trace, option or identity-vector differences are excused. Bounded final-only evidence, not ordinary scheduling or full parity.'}
Path('/tmp/dive-material-process-current-native-verification.json').write_text(json.dumps(d,indent=2)+'\n')
Path('/tmp/dive-material-process-native-comparison-initial.json').write_text(json.dumps({'initial_strict_comparison_passed':False,'first_difference':'TfEnabledFails-1/frontier_storage.scope','scope_before':oldscope,'scope_after':newscope,'subsequent_helper_error':'Nullable frontier_storage was initially assumed to be an object; helper corrected without modifying native observations or comparison obligations.','outcome':'Preserve initial failed comparison; narrowly check known explanatory update, no semantic fields dropped.'},indent=2)+'\n')
print('PASS',len(rows),'complete native rows;',len(explanations),'exact known storage explanations')
