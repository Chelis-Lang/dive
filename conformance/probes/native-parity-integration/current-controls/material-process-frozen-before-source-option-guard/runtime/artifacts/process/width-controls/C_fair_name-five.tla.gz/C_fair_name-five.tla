---- MODULE C_fair_name_five ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A {variables g=0,abcde=9; process(P = 1){L:g:=1; E:skip;}} *)
====
