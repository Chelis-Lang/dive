---- MODULE Multiline ----
EXTENDS Integers
(* --algorithm A
variables x = 0, y = 0;
begin
  Start: x := 1;
         y := x +
              2;
  Finish: skip;
end algorithm; *)
====
