---- MODULE P_fair_empty_else ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A variables x=0,y=0; begin L:if x=0 then x:=1+
  2; else end if; E:skip; end algorithm; *)
====
