---- MODULE C_fair_case_true_lines ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A {variables x=0,y=0; { L:x:=CASE TRUE -> 1
  [] OTHER -> 0; E:skip; } } *)
====
