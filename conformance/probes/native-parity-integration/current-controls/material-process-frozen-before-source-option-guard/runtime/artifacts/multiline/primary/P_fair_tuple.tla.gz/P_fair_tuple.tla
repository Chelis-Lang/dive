---- MODULE P_fair_tuple ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A variables x=0,y=0; begin L:x:=<<1,
  2>>; E:skip; end algorithm; *)
====
