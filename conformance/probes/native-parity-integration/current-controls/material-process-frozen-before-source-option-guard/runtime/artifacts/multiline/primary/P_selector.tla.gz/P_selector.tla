---- MODULE P_selector ----
EXTENDS Integers, TLC, Sequences
(* --algorithm A variables x=<<0,0>>,y=0; begin L:x[1]:=1 +
  2; E:skip; end algorithm; *)
====
