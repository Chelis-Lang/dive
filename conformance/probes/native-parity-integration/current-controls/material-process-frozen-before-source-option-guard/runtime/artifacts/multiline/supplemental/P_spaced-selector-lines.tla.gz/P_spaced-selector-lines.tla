---- MODULE P_spaced_selector_lines ----
EXTENDS Integers, TLC, Sequences
(* --algorithm A variables x = <<0,0>>,y=0; begin L:x[1 +
 0]:=2; E:skip; end algorithm; *)
====
