import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
WORK=Path('/Users/jeff/code/dive-native-operator-integration-work')
BINS=Path('/Users/jeff/code/dive-native-source-options-combined-artifacts')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_text())
producer=read('producer.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==producer['source_commit']
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=WORK,text=True).strip()==producer['source_tree']
source_failures=[name for name,wanted in producer['source_sha256'].items() if digest(WORK/name)!=wanted]
assert not source_failures,source_failures
actual_binaries={name:digest(BINS/name)for name in producer['binary_sha256']}
assert actual_binaries==producer['binary_sha256'],actual_binaries
reports={name:read(name+'/report.json')for name in ['raw','public','guides','checksum-controls','report-controls','models']}
assert reports['raw']['selected']==reports['public']['selected']==752
assert len(reports['raw']['rows'])==len(reports['public']['rows'])==752
assert not reports['raw']['summary'].get('disagree') and not reports['public']['summary'].get('disagree')
assert reports['raw']['summary']=={'exact-raw-ast':480,'primary-invalid-raw-serialization':16,'rejection-accounted':16,'named-refusal':208,'named-selection-refusal':16,'generation-only-full-refused':16}
assert reports['public']['summary']=={'admitted-exact-cst-sany-validator':480,'invalid-primary-uncredited':16,'rejection-accounted':32,'named-public-refusal':224}
assert reports['guides']['selected']==13 and reports['checksum-controls']['selected']==6
assert reports['report-controls']['selected']==15 and reports['report-controls']['requested_context_audits']==496
assert all(r['outcome']=='rejected'for r in reports['report-controls']['rows'])
assert reports['models']['selected']==24 and reports['models']['worker_store_controls']==288
assert reports['models']['valid_witness_controls']==12 and reports['models']['rejected_witness_mutants']==48
readback={'schema_version':1,'source_commit':producer['source_commit'],'source_tree':producer['source_tree'],'producer_sha256':digest(OUT/'producer.json'),'verified_sources':len(producer['source_sha256']),'binary_sha256':actual_binaries,'source_unchanged':True,'family_certified':False}
(OUT/'final-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
evidence={str(p.relative_to(OUT)):digest(p)for p in sorted(OUT.rglob('*'))if p.is_file()and p.name not in ['execution.json','evidence-manifest.json']}
(OUT/'evidence-manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
receipt={'schema_version':1,'runtime_source_commit':producer['source_commit'],'runtime_source_tree':producer['source_tree'],'source_input_count':len(producer['source_sha256']),'source_unchanged':True,'binary_sha256':actual_binaries,'reports':{name:{'sha256':digest(OUT/name/'report.json'),'selected':r['selected'],'summary':r.get('summary'),'script_sha256':r.get('script_sha256')}for name,r in reports.items()},'worker_store_controls':288,'strict_valid_witness_controls':12,'rejected_witness_mutants':48,'requested_context_audits':496,'preserved_evidence_files':len(evidence),'evidence_manifest_sha256':digest(OUT/'evidence-manifest.json'),'finalizer_sha256':digest(Path(__file__)),'all_consumers_closed':True,'family_certified':False,'full_feature_parity_certified':False,'checksum_establishes_source_identity':False,'fair_header_crc_only_limitation_retained':True,'scope':'Fresh complete bounded source-option campaign on immutable combined source397; parent full gate and later guide lint repair have separate producers.'}
(OUT/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k!='reports'},indent=2))
