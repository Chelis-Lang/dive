fn main() {
use dive_api::{TranslationRequest, translate_source};
use dive_pluscal::{FairnessOption, TranslationOptions};
let source = "---- MODULE R ----\nEXTENDS Integers,TLC,Sequences\n\\* PlusCal options (-wf)\n(* --algorithm A variable g=0; process P=1 begin L:g:=1; E:skip; end process; end algorithm; *)\n====\n";
let request = TranslationRequest {
    limits: TranslationOptions { fairness: FairnessOption::Strong, ..Default::default() },
    ..Default::default()
};
let report = translate_source("R.tla", source, &request);
assert!(report.accepted());
assert_eq!(report.to_json()["translation_options"]["fairness"], "Weak");
assert_eq!(report.to_json()["model_proved"], false);
println!("source-options-guide: accepted, effective=Weak, model_proved=false");
}
