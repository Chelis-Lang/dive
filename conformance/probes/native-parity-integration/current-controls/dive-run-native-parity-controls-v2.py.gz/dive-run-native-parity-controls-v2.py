import pathlib,subprocess,json,hashlib,sys,shutil
root=pathlib.Path('/Users/jeff/code/dive-phase-l-graph-shipping-work')
target=pathlib.Path('/Users/jeff/code/dive-phase-l-graph-work/target/release')
java=pathlib.Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=pathlib.Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
kind=sys.argv[1];assert kind in ('fairness','multiple')
base=root/f'crates/dive-pluscal/{kind}-acceptance'
out=pathlib.Path('/tmp/dive-native-parity-current-v2-'+kind)
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'binary_sha256':sha(target/'dive'),'example_sha256':sha(target/'examples/translate'),'script_sha256':sha(pathlib.Path(__file__)),'oracle_sha256':sha(jar),'scope':'fresh complete retained '+kind+' selection and generated finite controls on combined source; no family certification','source_sha256':{str(p.relative_to(root)):sha(p) for p in (root/'crates/dive-pluscal/src').rglob('*.rs')}}
(out/'execution.json').write_text(json.dumps(meta,indent=2)+'\n')
summary={};artifacts=0;models=0;total=0
subs=['','positive','interactions','sequential','sequential-positive','combined'] if kind=='fairness' else ['','extra','bounds']
for sub in subs:
 family=base/sub;scripts=family if (family/'compare.py').exists() else base
 if kind=='fairness' and scripts==base:scripts=pathlib.Path('/tmp/dive-fairness-combined-adapter')
 dest=out/(sub or 'main');dest.mkdir()
 cmd=['python3','-I',str(scripts/'compare.py'),'--manifest',str(family/'fixtures/manifest.json'),'--inputs',str(family/'cases'),'--native',str(target/'examples/translate'),'--output',str(dest/'comparison.json')]
 with (dest/'comparison.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 result=json.loads((dest/'comparison.json').read_text());total+=result['selected'];print(sub or 'main',result['summary'],flush=True)
 if result['summary'].get('token-artifact-match'):
  cmd=['python3','-I',str(scripts/'validate.py'),'--java',str(java),'--jar',str(jar),'--native',str(target/'dive'),'--example',str(target/'examples/translate'),'--report',str(dest/'comparison.json'),'--inputs',str(family/'cases'),'--fixtures',str(family/'fixtures'),'--output',str(dest/'validation')]
  with (dest/'validation.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  val=json.loads((dest/'validation/report.json').read_text());artifacts+=val['selected_artifacts'];models+=sum(val['model_summary'].values());print(sub or 'main',val['artifact_summary'],val['model_summary'],flush=True)
 for key,value in result['summary'].items():summary[key]=summary.get(key,0)+value
assert total==(404 if kind=='fairness' else 264)
assert artifacts==summary.get('token-artifact-match',0)
assert artifacts>=(246 if kind=='fairness' else 206)
assert models==(16 if kind=='fairness' else 60),(total,artifacts,models)
assert not summary.get('disagree')
if kind=='multiple':
 controls=out/'document-corruption';controls.mkdir()
 for name in ['test-comparison.py','compare.py']:shutil.copy2(base/name,controls/name)
 for name in ['cases','fixtures']:shutil.copytree(base/name,controls/name)
 with (controls/'controls.log').open('w') as log:subprocess.run(['python3','-I',str(controls/'test-comparison.py'),'--native',str(target/'examples/translate')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 report=json.loads((controls/'mutation-controls.json').read_text());assert report['control_count']==28
 meta['corrupted_documents_rejected']=28
meta.update(selected=total,artifact_controls=artifacts,finite_models=models,summary=summary)
(out/'execution.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta,flush=True)
