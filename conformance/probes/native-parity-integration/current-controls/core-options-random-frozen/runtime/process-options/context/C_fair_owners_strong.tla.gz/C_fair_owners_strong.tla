---- MODULE C_fair_owners_strong ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A {variables g=0; fair+ process(P=1){L:-g:=1; M:+g:=2; E:skip;} fair process(Q=2){N:+g:=2; R:-g:=1; F:skip;}} *)
====
