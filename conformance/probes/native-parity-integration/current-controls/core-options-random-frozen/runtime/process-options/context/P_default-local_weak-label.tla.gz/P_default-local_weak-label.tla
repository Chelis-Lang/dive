---- MODULE P_default_local_weak_label ----
EXTENDS Integers, TLC, Sequences
(* --algorithm A variables g=0; process P = 1 variable defaultInitValue; begin L:g:=1; E:skip; end process; end algorithm; *)
====
