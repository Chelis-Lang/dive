---- MODULE C_fair_root_collision_strong ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A {variables g=0; process(P=1){Auto1:g:=1; g:=2;}} *)
====
