---- MODULE P_fair_weak_next_label ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A variables g=0; fair process P \in {1,2} begin L:g:=1; E:skip; end process; end algorithm; *)
====
