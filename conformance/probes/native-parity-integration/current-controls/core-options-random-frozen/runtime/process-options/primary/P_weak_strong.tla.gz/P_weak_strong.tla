---- MODULE P_weak_strong ----
EXTENDS Integers, TLC, Sequences
(* --algorithm A variables g=0; fair process P \in {1,2} begin L:g:=1; E:skip; end process; end algorithm; *)
====
