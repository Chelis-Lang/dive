---- MODULE P_fair_unlabelled_invalid_root ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A variables g=0; process P = 1 begin g:=1; g:=2; end process; end algorithm; *)
====
