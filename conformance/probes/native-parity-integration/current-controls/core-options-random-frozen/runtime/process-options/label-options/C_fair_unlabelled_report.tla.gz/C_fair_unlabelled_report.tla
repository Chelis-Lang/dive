---- MODULE C_fair_unlabelled_report ----
EXTENDS Integers, TLC, Sequences
(* --fair algorithm A {variables g=0; process(P=1){g:=1; g:=2;}} *)
====
