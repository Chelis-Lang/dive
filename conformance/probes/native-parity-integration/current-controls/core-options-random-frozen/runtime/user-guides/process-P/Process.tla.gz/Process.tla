---- MODULE Process ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A
variable g = 0;
process Worker \in {1, 2}
variable z = 0;
begin
  Start: z := z + 1;
  Finish: g := z;
end process;
end algorithm; *)
====
