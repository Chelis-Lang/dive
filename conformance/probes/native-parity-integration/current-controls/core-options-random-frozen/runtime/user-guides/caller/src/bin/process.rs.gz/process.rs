fn main() -> Result<(), Box<dyn std::error::Error>> {
use dive_api::{RewriteRequest, rewrite_source};
let source = std::fs::read_to_string("Process.tla")?;
let report = rewrite_source("Process.tla", &source, &RewriteRequest::default());
assert!(report.accepted());
assert_eq!(report.to_json()["model_proved"], false);
println!("{}", report.to_json());
Ok::<(), Box<dyn std::error::Error>>(())
}
