fn main() -> Result<(), Box<dyn std::error::Error>> {
use dive_api::{RewriteRequest, TranslationFairness, rewrite_source};
let source = std::fs::read_to_string("ProcessOptions.tla")?;
let mut request = RewriteRequest::default();
request.translation.limits.insert_missing_labels = true;
request.translation.limits.label_root = "Auto".into();
request.translation.limits.fairness = TranslationFairness::Weak;
let report = rewrite_source("ProcessOptions.tla", &source, &request);
assert!(report.accepted());
assert_eq!(report.to_json()["model_proved"], false);
Ok::<(), Box<dyn std::error::Error>>(())
}
