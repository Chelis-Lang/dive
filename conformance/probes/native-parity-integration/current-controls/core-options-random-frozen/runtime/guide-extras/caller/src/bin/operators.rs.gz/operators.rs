fn main() -> Result<(), Box<dyn std::error::Error>> {
use std::{path::Path, sync::Arc};
let file = Path::new("conformance/probes/temporal-operators/models/OpCaptureFails/OpCaptureFails.tla");
let analysis = dive_sema::analyze_file(file, &Default::default())?;
let ir = Arc::new(dive_ir::lower(&analysis)?);
let cfg = dive_config::parse("INIT Init\nNEXT Next\nPROPERTY Live\n")
    .into_config().ok_or("invalid config")?;
let options = dive_check::CheckOptions { workers: 4, ..dive_check::CheckOptions::tlc(0, 0) };
let report = dive_api::tlc_temporal::check_final(&ir, &cfg, &options, Default::default())?;
if let dive_api::tlc_temporal::Outcome::Violation(v) = report.outcome() {
    assert_eq!(v.document().properties, vec!["Live"]);
    assert_eq!(v.validation().validation, dive_trace::Validation::Valid);
}
Ok::<(), Box<dyn std::error::Error>>(())
}
