use dive_api::{TranslationRequest,RewriteRequest,ChecksumPolicy,translate_source,rewrite_source};
fn main() -> Result<(), Box<dyn std::error::Error>> {
 let root=std::path::PathBuf::from(std::env::args().nth(1).ok_or("missing root")?);
 let mut count=0;
 for name in ["weak","strong","labels","root","masked"] {
  let file=if name=="masked" { root.join("conformance/probes/pluscal-source-option-masking/before.tla") } else { root.join("crates/dive-pluscal/source-option-acceptance/validator-context").join(format!("SourceOptions_{name}.tla")) };
  let source=std::fs::read_to_string(&file)?;
  for compat in [false,true] {
   let request=TranslationRequest { compat_tlc:compat,..Default::default() };
   let t=translate_source("source-options.tla",&source,&request);let d=t.to_json();
   assert!(!t.accepted());assert_eq!(t.exit_code(),3);assert_eq!(d["result"],"unsupported");assert_eq!(d["model_proved"],false);assert!(d.get("artifact").is_none());count+=1;
   for policy in [ChecksumPolicy::Full,ChecksumPolicy::TranslationOnly] {
    let mut request=RewriteRequest::default();request.translation.compat_tlc=compat;request.editing.checksums=policy;
    let t=rewrite_source("source-options.tla",&source,&request);let d=t.to_json();assert!(!t.accepted());assert_eq!(t.exit_code(),3);assert_eq!(d["result"],"unsupported");assert_eq!(d["model_proved"],false);assert!(d.get("artifact").is_none()&&d.get("replacement").is_none());count+=1;
   }
  }
  assert_eq!(std::fs::read_to_string(file)?,source);
 }
 assert_eq!(count,30);println!("{count} typed source-context refusals");Ok(())
}
