from pathlib import Path
import subprocess,json,hashlib,time,os
r=Path.cwd();b=r/'conformance/probes/native-temporal-operators/gate-current';b.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p.relative_to(r)):sha(p)for p in (r/'crates').rglob('*')if p.is_file()and p.suffix in ['.rs','.toml']}
inputs.update({str(p.relative_to(r)):sha(p)for p in (r/'xtask').rglob('*')if p.is_file()and p.suffix in ['.rs','.toml']})
inputs.update({p:sha(r/p)for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
(b/'before.json').write_text(json.dumps(dict(parent=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=inputs),indent=2)+'\n')
s=Path('AGENTS.md').read_text();start=s.index('cargo fmt --all --check');end=s.index('```',start);commands=[l.split('#')[0].strip()for l in s[start:end].splitlines()if l.strip()]
commands=[l.replace('cargo nextest run --workspace --locked','cargo nextest run --workspace --locked --test-threads 2')for l in commands]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/Users/jeff/code/dive-native-operator-target',DIVE_CACHE_DIR='/Users/jeff/code/dive-native-operator-cache')
steps=[]
with(b/'workspace.log').open('w')as log:
 for command in commands:
  log.write('\nCOMMAND: '+command+'\n');log.flush();start=time.monotonic();result=subprocess.run(command,shell=True,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  steps.append(dict(command=command,exit=result.returncode,wall_seconds=time.monotonic()-start));(b/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
  if result.returncode:print('FAILED',command);break
unchanged=all(sha(r/p)==d for p,d in inputs.items());(b/'after.json').write_text(json.dumps(dict(source_and_binaries_unchanged=unchanged,source_sha256=inputs,all_steps_passed=len(steps)==len(commands)and all(s['exit']==0 for s in steps),expected_steps=len(commands),log_sha256=sha(b/'workspace.log')),indent=2)+'\n')
assert unchanged
raise SystemExit(0 if len(steps)==len(commands)and all(s['exit']==0 for s in steps)else 1)
