//! Actual pinned conditional source conversion, including early errors.
#![allow(clippy::expect_used, clippy::panic, reason = "test assertions")]

use dive_liveness::formula::Limits;
use dive_liveness::tlc_plan::lower_model;
use std::{path::Path, sync::Arc};

#[test]
fn state_if_constant_branch_must_fail_before_exploration() {
 let name="StateThenError";
 let root=Path::new(env!("CARGO_MANIFEST_DIR")).join("../../conformance/probes/state-if-planning/models").join(name);
 let source=std::fs::read_to_string(root.join(format!("{name}.tla"))).expect("source");
 let analysis=dive_sema::analyze_source(&format!("{name}.tla"),&source,&dive_sema::Options::default());
 assert!(analysis.accepted());
 let ir=Arc::new(dive_ir::lower(&analysis).expect("IR"));
 let cfg=dive_config::parse(&std::fs::read_to_string(root.join(format!("{name}.cfg"))).expect("cfg")).into_config().expect("parsed");
 let model=dive_model::bind(ir,&cfg,&dive_model::BindOptions::tlc()).expect("model");
 assert!(lower_model(&model,Limits::default()).is_err(), "pinned TLC raises2179 during planning, before any state fingerprint");
}
