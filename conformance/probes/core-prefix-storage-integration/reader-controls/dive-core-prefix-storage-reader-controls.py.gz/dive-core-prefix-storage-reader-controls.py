from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path('/Users/jeff/code/dive-native-operator-integration-work');base=root/'conformance/probes/core-prefix-storage-integration/epochs/2bff2728cc065209ef9743e419dee56ed8ca4ccb';idx=base/'index.json';original=idx.read_bytes();supp=base/'embedded-input-supplement/index.json';supporiginal=supp.read_bytes();doc=json.loads(original);archive=base/next(iter(doc['archives']));blob=archive.read_bytes();embedded=base/'embedded-input-supplement'/next(iter(json.loads(supporiginal)['files_sha256']));embedblob=embedded.read_bytes();out=Path('/tmp/dive-core-prefix-storage-reader-controls');out.mkdir(exist_ok=False);rows=[]
def run(label):
 r=subprocess.run(['python3','-I','scripts/check-core-prefix-storage-integration.py'],cwd=root,capture_output=True);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);rows.append({'control':label,'exit':r.returncode});assert r.returncode!=0,label
try:
 archive.unlink();run('missing-receiving-archive');archive.write_bytes(blob)
 new=json.loads(original);new['all_receiving_consumers_closed']=False;idx.write_text(json.dumps(new,indent=2)+'\n');run('unclosed-epoch');idx.write_bytes(original)
 new=json.loads(original);new['family_certified']=True;idx.write_text(json.dumps(new,indent=2)+'\n');run('false-family-promotion');idx.write_bytes(original)
 embedded.unlink();run('missing-embedded-input');embedded.write_bytes(embedblob)
 new=json.loads(supporiginal);new['references'].pop();supp.write_text(json.dumps(new,indent=2)+'\n');run('omitted-include-authority');supp.write_bytes(supporiginal)
finally:
 archive.write_bytes(blob);idx.write_bytes(original);supp.write_bytes(supporiginal);embedded.write_bytes(embedblob)
r=subprocess.run(['python3','-I','scripts/check-core-prefix-storage-integration.py'],cwd=root,capture_output=True);assert r.returncode==0;receipt={'producer':doc['producer'],'controls':rows,'restored':True,'restored_exit':0,'new_runtime_credit':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
destination=base.parent.parent/'reader-controls';destination.mkdir(exist_ok=False);files={}
for p in [*out.iterdir(),Path(__file__),Path('/tmp/dive-embedded-input-supplement.py')]:
 q=destination/(p.name+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),mtime=0));files[q.name]=hashlib.sha256(q.read_bytes()).hexdigest()
(destination/'index.json').write_text(json.dumps({'producer':doc['producer'],'files_sha256':files,'new_runtime_credit':False},indent=2)+'\n')
