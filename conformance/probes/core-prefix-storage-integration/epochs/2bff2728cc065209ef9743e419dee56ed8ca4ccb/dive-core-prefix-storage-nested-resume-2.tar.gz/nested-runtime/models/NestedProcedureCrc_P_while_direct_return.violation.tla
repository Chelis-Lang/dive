---- MODULE NestedProcedureCrc_P_while_direct_return ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A variable x=0; procedure Put(a=0) begin P:while a=0 do return; end while; R:return; end procedure; begin L:call Put(2); E:skip; end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "c0cfb2e9" /\ chksum(tla) = "12bdcf66")
VARIABLES pc, x, stack, a

vars == << pc, x, stack, a >>

Init == /\ x = 0
        /\ a = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ IF a = 0
           THEN /\ pc' = Head(stack).pc
                /\ a' = Head(stack).a
                /\ stack' = Tail(stack)
           ELSE /\ pc' = "R"
                /\ UNCHANGED << stack, a >>
     /\ x' = x

R == /\ pc = "R"
     /\ pc' = Head(stack).pc
     /\ a' = Head(stack).a
     /\ stack' = Tail(stack)
     /\ x' = x

Put == P \/ R

L == /\ pc = "L"
     /\ /\ a' = 2
        /\ stack' = << [ procedure |-> "Put", pc |-> "E", a |-> a ] >> \o stack
     /\ pc' = "P"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, a >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 

Good == pc # "Done"
====
