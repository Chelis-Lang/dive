---- MODULE ProcedureCrc_C_zero_slots ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A {
variable x=0;
procedure Put()

{
P:x:=2; R:return;
};
{
L:call Put(); E:skip;
}
} *)
\* BEGIN TRANSLATION (chksum(pcal) = "5563ddf3" /\ chksum(tla) = "9d1d7998")
VARIABLES pc, x, stack

vars == << pc, x, stack >>

Init == /\ x = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ x' = 2
     /\ pc' = "R"
     /\ stack' = stack

R == /\ pc = "R"
     /\ pc' = Head(stack).pc
     /\ stack' = Tail(stack)
     /\ x' = x

Put == P \/ R

L == /\ pc = "L"
     /\ stack' = << [ procedure |-> "Put", pc |-> "E" ] >> \o stack
     /\ pc' = "P"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
