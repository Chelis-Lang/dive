---- MODULE NestedProcedureCrc_P_while_direct_call ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A variable x=0; procedure Put(a=0) begin P:x:=a; R:return; end procedure; begin L:while x=0 do call Put(2); B:skip; end while; E:skip; end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "1057f68f" /\ chksum(tla) = "a443e0dd")
VARIABLES pc, x, stack, a

vars == << pc, x, stack, a >>

Init == /\ x = 0
        /\ a = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ x' = a
     /\ pc' = "R"
     /\ UNCHANGED << stack, a >>

R == /\ pc = "R"
     /\ pc' = Head(stack).pc
     /\ a' = Head(stack).a
     /\ stack' = Tail(stack)
     /\ x' = x

Put == P \/ R

L == /\ pc = "L"
     /\ IF x = 0
           THEN /\ /\ a' = 2
                   /\ stack' = << [ procedure |-> "Put", pc |-> "B", a |-> a ] >> \o stack
                /\ pc' = "P"
           ELSE /\ pc' = "E"
                /\ UNCHANGED << stack, a >>
     /\ x' = x

B == /\ pc = "B"
     /\ TRUE
     /\ pc' = "L"
     /\ UNCHANGED << x, stack, a >>

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, a >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ B \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
