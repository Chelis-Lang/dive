---- MODULE NestedProcedureCrc_C_with_if_call ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A { variable x=0; procedure Put(a=0) { P:x:=a; R:return; }; { L:with (q=2) { if (x=0) { call Put(q); goto E; } else { skip; }; }; E:skip; } } *)
\* BEGIN TRANSLATION (chksum(pcal) = "434b066c" /\ chksum(tla) = "8a94ade")
VARIABLES pc, x, stack, a

vars == << pc, x, stack, a >>

Init == /\ x = 0
        /\ a = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ x' = a
     /\ pc' = "R"
     /\ UNCHANGED << stack, a >>

R == /\ pc = "R"
     /\ pc' = Head(stack).pc
     /\ a' = Head(stack).a
     /\ stack' = Tail(stack)
     /\ x' = x

Put == P \/ R

L == /\ pc = "L"
     /\ LET q == 2 IN
           IF x = 0
              THEN /\ /\ a' = q
                      /\ stack' = << [ procedure |-> "Put", pc |-> "E", a |-> a ] >> \o stack
                   /\ pc' = "P"
              ELSE /\ TRUE
                   /\ pc' = "E"
                   /\ UNCHANGED << stack, a >>
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, a >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
