---- MODULE ProcedureCrc_P_if_call ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A
variable x=0;
procedure Put(a=0)

begin
P:x:=a; R:return;
end procedure;
begin
L:if x=0 then call Put(2); goto E; else call Put(3); goto E; end if; E:skip;
end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "45aac90e" /\ chksum(tla) = "7550896d")
VARIABLES pc, x, stack, a

vars == << pc, x, stack, a >>

Init == /\ x = 0
        /\ a = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ x' = a
     /\ pc' = "R"
     /\ UNCHANGED << stack, a >>

R == /\ pc = "R"
     /\ pc' = Head(stack).pc
     /\ a' = Head(stack).a
     /\ stack' = Tail(stack)
     /\ x' = x

Put == P \/ R

L == /\ pc = "L"
     /\ IF x = 0
           THEN /\ /\ a' = 2
                   /\ stack' = << [ procedure |-> "Put", pc |-> "E", a |-> a ] >> \o stack
                /\ pc' = "P"
           ELSE /\ /\ a' = 3
                   /\ stack' = << [ procedure |-> "Put", pc |-> "E", a |-> a ] >> \o stack
                /\ pc' = "P"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, a >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
