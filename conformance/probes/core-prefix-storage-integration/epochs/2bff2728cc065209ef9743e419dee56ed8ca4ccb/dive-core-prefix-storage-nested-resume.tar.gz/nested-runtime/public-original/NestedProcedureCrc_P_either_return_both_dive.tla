---- MODULE NestedProcedureCrc_P_either_return_both ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A variable x=0; procedure Put(a=0) begin P:either return; or return; end either; end procedure; begin L:call Put(2); E:skip; end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "5a9d366d" /\ chksum(tla) = "cf4006f")
VARIABLES pc, x, stack, a

vars == << pc, x, stack, a >>

Init == /\ x = 0
        /\ a = 0
        /\ stack = << >>
        /\ pc = "L"

P == /\ pc = "P"
     /\ \/ /\ pc' = Head(stack).pc
           /\ a' = Head(stack).a
           /\ stack' = Tail(stack)
        \/ /\ pc' = Head(stack).pc
           /\ a' = Head(stack).a
           /\ stack' = Tail(stack)
     /\ x' = x

Put == P

L == /\ pc = "L"
     /\ /\ a' = 2
        /\ stack' = << [ procedure |-> "Put", pc |-> "E", a |-> a ] >> \o stack
     /\ pc' = "P"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, a >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
