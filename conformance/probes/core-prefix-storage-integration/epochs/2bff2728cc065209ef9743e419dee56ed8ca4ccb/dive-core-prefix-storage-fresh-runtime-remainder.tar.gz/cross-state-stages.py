from pathlib import Path
import json,gzip,re,base64,subprocess,tempfile,hashlib
b=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder');a=b/'cross-state-controls';out=b/'cross-state-artifact-controls';out.mkdir();rows=[];java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java');jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar');cst=b/'bins/cst'
def run(argv,work,tag):
 q=subprocess.run(list(map(str,argv)),cwd=work,capture_output=True,timeout=30)
 for s in ['stdout','stderr']:(out/(tag+'.'+s+'.gz')).write_bytes(gzip.compress(getattr(q,s),mtime=0))
 return q
for path in sorted(a.glob('*.input.tla')):
 name=path.name.removesuffix('.input.tla');doc=json.loads(gzip.decompress((a/(name+'.native-generation.stdout.gz')).read_bytes()));checksum=doc['replacement']['algorithm_checksum']
 with tempfile.TemporaryDirectory(prefix='dive-cross-state-stages-')as tmp:
  work=Path(tmp);file=work/(name+'.tla');file.write_bytes(path.read_bytes());q=run([java,'-Xmx256m','-cp',str(b/'adapter')+':'+str(jar),'pcal.DefinitionProbe',file.name],work,name+'.stages');stages={}
  for line in q.stdout.decode().splitlines():
   fields=line.split('\t')
   if fields[0]=='STAGE'and fields[1]=='translated':stages={'ast':base64.b64decode(fields[3]).decode(),'crc':fields[2]}
  assert q.returncode==0 and checksum['serialized_ast']==stages['ast']and checksum['checksum']==stages['crc'];trees=[]
  for label in ['primary','native']:
   file.write_bytes((a/(name+'.'+label+'.tla')).read_bytes());q=run([java,'-Xmx256m','-cp',jar,'tla2sany.SANY','-error-codes',file.name],work,name+'.'+label+'.sany');assert q.returncode==0
   q=run([cst,file],work,name+'.'+label+'.cst');tree=json.loads(q.stdout);assert q.returncode==0 and tree['accepted'];trees.append(tree['tree'])
   q=run([java,'-Xmx256m','-cp',str(b/'adapter')+':'+str(jar),'pcal.OptionValidatorProbe',file.name],work,name+'.'+label+'.validator');assert q.returncode==0 and b'NO_DIVERGENCE'in q.stdout
  assert trees[0]==trees[1];rows.append({'id':name,'outcome':'exact-ast-crc-whole-cst-sany-validator','model_proved':False})
(out/'report.json').write_text(json.dumps({'schema_version':1,'selected':len(rows),'rows':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'cst_sha256':hashlib.sha256(cst.read_bytes()).hexdigest(),'family_certified':False},indent=2)+'\n');print('Closed6supplementary cross-state AST/CRC/CST/SANY/Validator artifacts')
