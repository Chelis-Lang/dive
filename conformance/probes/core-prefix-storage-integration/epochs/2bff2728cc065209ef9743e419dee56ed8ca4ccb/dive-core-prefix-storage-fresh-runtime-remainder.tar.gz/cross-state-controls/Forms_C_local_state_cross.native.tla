---- MODULE Forms_C_local_state_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 LOCAL F==x
 }
{ L:x:=1; y:=F; E:y:=F; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "5f8e994c" /\ chksum(tla) = "e3580ff2")
VARIABLES pc, x, y

(* define statement *)
LOCAL F==x

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ x' = 1
     /\ y' = F
     /\ pc' = "E"

E == /\ pc = "E"
     /\ y' = F
     /\ pc' = "Done"
     /\ x' = x

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
