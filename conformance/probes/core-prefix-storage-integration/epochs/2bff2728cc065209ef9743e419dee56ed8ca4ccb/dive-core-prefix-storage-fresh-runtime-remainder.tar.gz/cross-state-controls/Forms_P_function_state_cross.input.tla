---- MODULE Forms_P_function_state_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 F[a \in {1,2}] == x+a
 end define;
begin L:x:=1; y:=F[1]; E:y:=F[1];
end algorithm;
*)
====
