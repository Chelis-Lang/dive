---- MODULE Forms_P_function_state_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 F[a \in {1,2}] == x+a
 end define;
begin L:x:=1; y:=F[1]; E:y:=F[1];
end algorithm;
*)
\* BEGIN TRANSLATION (chksum(pcal) = "a37bb02" /\ chksum(tla) = "4e9dbba5")
VARIABLES pc, x, y

(* define statement *)
F[a \in {1,2}] == x+a


vars == << pc, x, y >>

Init == (* Global variables *)
        /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ x' = 1
     /\ y' = F[1]
     /\ pc' = "E"

E == /\ pc = "E"
     /\ y' = F[1]
     /\ pc' = "Done"
     /\ x' = x

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")

\* END TRANSLATION 
====
