---- MODULE Forms_C_function_state_domain_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 F[a \in 0..x] == a+1
 }
{ L:x:=2; E:y:=F[2]; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "f9d5f810" /\ chksum(tla) = "96bf97ab")
VARIABLES pc, x, y

(* define statement *)
F[a \in 0..x] == a+1

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ x' = 2
     /\ pc' = "E"
     /\ y' = y

E == /\ pc = "E"
     /\ y' = F [ 2 ]
     /\ pc' = "Done"
     /\ x' = x

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
