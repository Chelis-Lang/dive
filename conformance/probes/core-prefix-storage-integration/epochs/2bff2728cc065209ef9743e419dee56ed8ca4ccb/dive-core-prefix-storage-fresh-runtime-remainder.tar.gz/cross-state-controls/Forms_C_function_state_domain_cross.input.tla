---- MODULE Forms_C_function_state_domain_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 F[a \in 0..x] == a+1
 }
{ L:x:=2; E:y:=F[2]; }
}
*)
====
