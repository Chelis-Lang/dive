---- MODULE Forms_C_function_state_cross ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 F[a \in {1,2}] == x+a
 }
{ L:x:=1; y:=F[1]; E:y:=F[1]; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "a37bb02" /\ chksum(tla) = "225d7503")
VARIABLES pc, x, y

(* define statement *)
F[a \in {1,2}] == x+a

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ x' = 1
     /\ y' = F [ 1 ]
     /\ pc' = "E"

E == /\ pc = "E"
     /\ y' = F [ 1 ]
     /\ pc' = "Done"
     /\ x' = x

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
