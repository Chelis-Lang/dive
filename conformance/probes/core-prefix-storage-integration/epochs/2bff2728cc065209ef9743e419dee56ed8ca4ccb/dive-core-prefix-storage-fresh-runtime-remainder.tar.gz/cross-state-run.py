from pathlib import Path
import json,gzip,re,subprocess,tempfile,hashlib
base=Path('crates/dive-pluscal/define-forms-acceptance/cases');a=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder');out=a/'cross-state-controls';out.mkdir();rows=[];binary=a/'bins/dive';java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java');jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
def run(argv,work,tag):
 q=subprocess.run(list(map(str,argv)),cwd=work,capture_output=True,timeout=45)
 for s in ['stdout','stderr']:(out/(tag+'.'+s+'.gz')).write_bytes(gzip.compress(getattr(q,s),mtime=0))
 return q
for syntax in ['C','P']:
 for shape,ending,expected in [('local_state','y:=F;',1),('function_state','y:=F[1];',2),('function_state_domain','y:=F[2];',3)]:
  original=f'Forms_{syntax}_{shape}';name=original+'_cross';source=(base/(original+'.tla')).read_text().replace('MODULE '+original,'MODULE '+name).replace('E:skip;', 'E:'+ending)
  if shape=='function_state_domain':source=source.replace('L:y:=F[0];','L:x:=2;')
  (out/(name+'.input.tla')).write_text(source)
  with tempfile.TemporaryDirectory(prefix='dive-define-cross-state-')as tmp:
   work=Path(tmp);file=work/(name+'.tla');file.write_text(source);q=run([java,'-Xmx256m','-cp',jar,'pcal.trans','-nocfg',file.name],work,name+'.primary-generation');assert q.returncode==0 and b'Unrecoverable error'not in q.stdout;primary=file.read_text();(out/(name+'.primary.tla')).write_text(primary)
   file.write_text(source);q=run([binary,'translate',file.name,'--rewrite','--compat=tlc','--output','json'],work,name+'.native-generation');doc=json.loads(q.stdout);assert q.returncode==0 and doc['accepted'] and doc['model_proved']is False;native=doc['replacement']['module_source'];(out/(name+'.native.tla')).write_text(native)
   suffix=f'\nCrossScope == pc = "Done" => y = {expected}\n';cfg=work/(name+'.cfg');cfg.write_text('INIT Init\nNEXT Next\nINVARIANT CrossScope\n');file.write_text(primary.replace('====',suffix+'===='));q=run([java,'-Xmx256m','-cp',jar,'tlc2.TLC','-tool','-workers','1','-fp','0','-seed','0','-cleanup','-config',cfg.name,file.name],work,name+'.primary-check');assert q.returncode==0,(name,q.stdout,q.stderr);matches=re.findall(rb'([0-9,]+) states generated, ([0-9,]+) distinct states found, ([0-9,]+) states left on queue\.',q.stdout);assert len(matches)==1;counts=dict(zip(['generated','distinct','left_on_queue'],[int(v.replace(b',',b''))for v in matches[0]]));file.write_text(native.replace('====',suffix+'===='))
   for profile in ['dive','tlc']:
    for width in [1,4,8]:
     for store in ['fp','exact']:
      tag=f'{name}.{profile}.{width}.{store}';q=run([binary,'check',file.name,'--config',cfg.name,'--seed','0','--fp','0','--workers',width,'--store',store,'--output','json',*(['--compat=tlc']if profile=='tlc'else[])],work,tag);d=json.loads(q.stdout);assert q.returncode==0 and d['verdict']=='success'and all(d['statistics'][k]==v for k,v in counts.items()),(tag,d);rows.append({'id':tag,'end_y':expected,'outcome':'cross-state-scope-invariant-and-counts-match'})
(out/'report.json').write_text(json.dumps({'schema_version':1,'models':6,'selected':len(rows),'rows':rows,'native_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'family_certified':False},indent=2)+'\n');print('Closed72cross-state helper/domain settings')
