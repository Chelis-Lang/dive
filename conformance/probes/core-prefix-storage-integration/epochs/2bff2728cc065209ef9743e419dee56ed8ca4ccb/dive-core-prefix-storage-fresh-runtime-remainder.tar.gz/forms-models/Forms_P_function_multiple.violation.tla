---- MODULE Forms_P_function_multiple ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 F[a \in {1,2}, b \in {2,3}] == a+b
 end define;
begin L:y:=F[1,2]; E:skip;
end algorithm;
*)
\* BEGIN TRANSLATION (chksum(pcal) = "8ba735b8" /\ chksum(tla) = "27a25179")
VARIABLES pc, x, y

(* define statement *)
F[a \in {1,2}, b \in {2,3}] == a+b

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = F [ 1 , 2 ]
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 

Good == pc # "Done"
====
