---- MODULE Forms_C_function_state_domain ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 F[a \in 0..x] == a+1
 }
{ L:y:=F[0]; E:skip; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "dfb915f1" /\ chksum(tla) = "7e5f9add")
VARIABLES pc, x, y

(* define statement *)
F[a \in 0..x] == a+1

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = F [ 0 ]
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
