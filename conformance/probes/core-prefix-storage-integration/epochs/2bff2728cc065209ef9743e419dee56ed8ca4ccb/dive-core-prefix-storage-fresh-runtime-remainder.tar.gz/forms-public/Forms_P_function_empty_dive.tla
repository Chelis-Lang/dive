---- MODULE Forms_P_function_empty ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 F[a \in {}]==a
 end define;
begin L:y:=Cardinality(DOMAIN F); E:skip;
end algorithm;
*)
\* BEGIN TRANSLATION (chksum(pcal) = "e697476d" /\ chksum(tla) = "37618cd0")
VARIABLES pc, x, y

(* define statement *)
F[a \in {}]==a

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = Cardinality ( DOMAIN F )
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
