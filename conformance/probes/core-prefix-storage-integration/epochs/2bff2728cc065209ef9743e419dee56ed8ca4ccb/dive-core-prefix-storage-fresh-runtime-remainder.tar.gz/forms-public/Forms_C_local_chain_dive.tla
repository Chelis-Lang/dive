---- MODULE Forms_C_local_chain ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 LOCAL G(a)==a+1 LOCAL F(a)==G(a)
 }
{ L:y:=F(x); E:skip; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "7839a02d" /\ chksum(tla) = "f431aff0")
VARIABLES pc, x, y

(* define statement *)
LOCAL G(a)==a+1 LOCAL F(a)==G(a)

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = F ( x )
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
