---- MODULE Forms_C_local_calls_function ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A {
 variables x=0,y=0;
 define {
 F[a \in {1,2}]==a+1 LOCAL G(a)==F[a]
 }
{ L:y:=G(1); E:skip; }
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "901e4dd9" /\ chksum(tla) = "32be0069")
VARIABLES pc, x, y

(* define statement *)
F[a \in {1,2}]==a+1 LOCAL G(a)==F[a]

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = G ( 1 )
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
