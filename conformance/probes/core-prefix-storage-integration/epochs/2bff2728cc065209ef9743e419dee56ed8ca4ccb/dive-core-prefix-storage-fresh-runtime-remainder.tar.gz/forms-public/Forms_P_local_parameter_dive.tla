---- MODULE Forms_P_local_parameter ----
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--algorithm A
 variables x=0,y=0;
 define
 LOCAL F(a)==a+1
 end define;
begin L:y:=F(x); E:skip;
end algorithm;
*)
\* BEGIN TRANSLATION (chksum(pcal) = "873db946" /\ chksum(tla) = "3e49fbc2")
VARIABLES pc, x, y

(* define statement *)
LOCAL F(a)==a+1

vars == << pc, x, y >>

Init == /\ x = 0
        /\ y = 0
        /\ pc = "L"

L == /\ pc = "L"
     /\ y' = F ( x )
     /\ pc' = "E"
     /\ x' = x

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, y >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
