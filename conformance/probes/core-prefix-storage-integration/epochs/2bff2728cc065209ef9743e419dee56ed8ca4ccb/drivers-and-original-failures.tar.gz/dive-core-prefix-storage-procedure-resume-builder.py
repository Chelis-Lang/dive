from pathlib import Path
p=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder.py');s=p.read_text();header=s[:s.index("prior=Path(")];header=header.replace('/tmp/dive-core-prefix-storage-fresh-runtime-remainder','/tmp/dive-core-prefix-storage-procedure-resume')
setup='''prior=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder')
prior_steps=json.loads((prior/'steps.json').read_text())['steps']
assert prior_steps[-1]['name']=='procedure-raw' and prior_steps[-1]['exit']==1
for row in prior_steps:
 for stream in ['stdout','stderr']:
  assert hashlib.sha256((prior/(row['name']+'.'+stream)).read_bytes()).hexdigest()==row[stream+'_sha256']
assert all(row['exit']==0 for row in prior_steps[:-1])
files={str(p.relative_to(prior)):hashlib.sha256(p.read_bytes()).hexdigest()for p in prior.rglob('*')if p.is_file()}
(out/'previous-failure.json').write_text(json.dumps({'previous_epoch':str(prior),'source_commit':frozen['source_commit'],'files':files,'qualification':'Original132 wrong-example failures retained; only correct original raw example protocol/binary mapping, no test/source/golden change'},indent=2)+'\\n')
bins=out/'bins';shutil.copytree(prior/'bins',bins)
shutil.copy2(bins/'checksum',bins/'define-checksum')
(bins/'checksum').unlink();shutil.copy2(bins/'context',bins/'checksum')
producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in bins.iterdir()},'qualification':'Same frozen2b source and originally fresh immutable outputs; raw procedure protocol uses pluscal_source_context, define_checksum retained separately'}
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\\n')
(out/'binary-mapping-correction.json').write_text(json.dumps({'prior_wrong_example':'define_checksum','actual_raw_protocol_example':'pluscal_source_context','required_arguments':['SOURCE','raw','FAIRNESS'],'all_selection_assertions_unchanged':True},indent=2)+'\\n')
proc=root/'crates/dive-pluscal/procedure-checksum-acceptance'
proc_adapter=out/'procedure-adapter';proc_library=out/'procedure-reference-library'
shutil.copytree(prior/'procedure-adapter',proc_adapter);shutil.copytree(prior/'procedure-reference-library',proc_library)
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
assert hashlib.sha256(jar.read_bytes()).hexdigest()=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
unchanged()
'''
tail=s[s.index("run('procedure-raw'"):]
Path('/tmp/dive-core-prefix-storage-procedure-resume.py').write_text(header+setup+tail)
