from pathlib import Path
import subprocess,json,hashlib,os,time,re,shutil
root=Path('/Users/jeff/code/dive-native-operator-integration-work')
frozen=json.loads(Path('/tmp/dive-core-prefix-storage-frozen-source/source.json').read_text())
gate=json.loads(Path('/tmp/dive-core-prefix-storage-gate-steps.json').read_text())
assert len(gate)==8 and all(s['exit']==0 for s in gate),'full frozen gate not closed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
out=Path('/tmp/dive-core-prefix-storage-procedure-resume');out.mkdir(exist_ok=False)
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache'}
steps=[]
def unchanged():
 for rel,h in frozen['source_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel
 for rel,h in frozen['integrity_output_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel

def run(name,command):
 unchanged();start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()};steps.append(row);(out/'steps.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps},indent=2)+'\n');print(name,'exit',r.returncode,flush=True);unchanged()
 if r.returncode:raise SystemExit(r.returncode)


prior=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder')
prior_steps=json.loads((prior/'steps.json').read_text())['steps']
assert prior_steps[-1]['name']=='procedure-raw' and prior_steps[-1]['exit']==1
for row in prior_steps:
 for stream in ['stdout','stderr']:
  assert hashlib.sha256((prior/(row['name']+'.'+stream)).read_bytes()).hexdigest()==row[stream+'_sha256']
assert all(row['exit']==0 for row in prior_steps[:-1])
files={str(p.relative_to(prior)):hashlib.sha256(p.read_bytes()).hexdigest()for p in prior.rglob('*')if p.is_file()}
(out/'previous-failure.json').write_text(json.dumps({'previous_epoch':str(prior),'source_commit':frozen['source_commit'],'files':files,'qualification':'Original132 wrong-example failures retained; only correct original raw example protocol/binary mapping, no test/source/golden change'},indent=2)+'\n')
bins=out/'bins';shutil.copytree(prior/'bins',bins)
shutil.copy2(bins/'checksum',bins/'define-checksum')
(bins/'checksum').unlink();shutil.copy2(bins/'context',bins/'checksum')
producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in bins.iterdir()},'qualification':'Same frozen2b source and originally fresh immutable outputs; raw procedure protocol uses pluscal_source_context, define_checksum retained separately'}
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
(out/'binary-mapping-correction.json').write_text(json.dumps({'prior_wrong_example':'define_checksum','actual_raw_protocol_example':'pluscal_source_context','required_arguments':['SOURCE','raw','FAIRNESS'],'all_selection_assertions_unchanged':True},indent=2)+'\n')
proc=root/'crates/dive-pluscal/procedure-checksum-acceptance'
proc_adapter=out/'procedure-adapter';proc_library=out/'procedure-reference-library'
shutil.copytree(prior/'procedure-adapter',proc_adapter);shutil.copytree(prior/'procedure-reference-library',proc_library)
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
assert hashlib.sha256(jar.read_bytes()).hexdigest()=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
unchanged()
run('procedure-raw',['python3','-I',str(proc/'compare.py'),'--base',str(proc),'--binary',str(bins/'checksum'),'--out',str(out/'procedure-raw')])
assert json.loads((out/'procedure-raw/report.json').read_text())['summary']=={'exact-raw-ast':90,'named-refusal':24,'rejection-accounted':16,'primary-invalid-raw-uncredited':2}
run('procedure-public',['python3','-I',str(proc/'public-controls.py'),'--base',str(proc),'--binary',str(bins/'dive'),'--cst',str(bins/'cst'),'--java',str(java),'--jar',str(jar),'--adapter',str(proc_adapter),'--library',str(proc_library),'--out',str(out/'procedure-public')])
assert json.loads((out/'procedure-public/report.json').read_text())['summary']=={'admitted-exact-cst-sany-validator':180,'rejection-accounted':36,'named-public-refusal':36,'invalid-primary-uncredited':12}
procedure_epoch=out/'procedure-models';procedure_epoch.mkdir()
run('procedure-models',['python3','-I',str(proc/'models.py'),'--base',str(proc),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(procedure_epoch/'models')])
pmodels=json.loads((out/'procedure-models/models/report.json').read_text());assert pmodels['selected']==32 and pmodels['worker_store_controls']==384
run('procedure-replay',['python3','-I',str(proc/'replay.py'),'--models',str(procedure_epoch/'models'),'--binary',str(bins/'dive'),'--out',str(out/'procedure-replay')])
preplay=json.loads((out/'procedure-replay/report.json').read_text());assert preplay['selected']==160 and preplay['summary']=={'dive.valid':16,'dive.invalid':64,'tlc.unsupported':48,'tlc.invalid':32}
run('procedure-guides',['python3','-I',str(proc/'guides.py'),'--base',str(proc),'--binaries',str(bins),'--worktree',str(root),'--target',env['CARGO_TARGET_DIR'],'--out',str(out/'procedure-guides')])
assert json.loads((out/'procedure-guides/report.json').read_text())['selected']==20

# New bounded nested-transfer continuation: preserve all original stage IDs.
# Original component observations remain archived under their own producer.
for source_name,alias in [('pluscal_nested_procedure_checksum','nested-guide')]:
 src=Path(env['CARGO_TARGET_DIR'])/'release/examples'/source_name; dst=bins/alias
 shutil.copy2(src,dst); assert src.read_bytes()==dst.read_bytes(); dst.chmod(0o555)
 producer['binaries'][alias]=hashlib.sha256(dst.read_bytes()).hexdigest()
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
nested_original=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/native-final')
nested_epoch=out/'nested-runtime';nested_epoch.mkdir()
campaign=json.loads((nested_original/'campaign.json').read_text())
assert campaign['passed'] and len(campaign['completed'])==13
replacements={
 '/Users/jeff/code/dive-pluscal-definition-forms-work':str(root),
 str(nested_original):str(nested_epoch),
 '/Users/jeff/code/dive-pluscal-definition-forms-cache':env['DIVE_CACHE_DIR'],
 '/Users/jeff/code/dive-pluscal-macro-checksum-target':env['CARGO_TARGET_DIR'],
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/adapter':str(proc_adapter),
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/reference-library':str(proc_library),
}
# Actual fresh binaries, copied under the declared native campaign layout.
shutil.copytree(bins,nested_epoch/'bins')
for i,stage in enumerate(campaign['completed']):
 if i>=11:continue # same exact full CM1/VTS selection already runs above
 command=[]
 for arg in stage['command']:
  for old,new in replacements.items():arg=arg.replace(old,new)
  command.append(arg)
 run('nested-campaign-'+str(i),command)
for location,count in [('raw-original',180),('public-original',360),('raw-while-tail',4),('public-while-tail',8),('raw-while-lines',8),('public-while-lines',16)]:
 report=json.loads((nested_epoch/location/'report.json').read_text())
 assert report['selected']==count
assert json.loads((nested_epoch/'models/report.json').read_text())['worker_store_controls']==768
assert json.loads((nested_epoch/'replay/report.json').read_text())['summary']=={'dive.valid':32,'dive.invalid':128,'tlc.unsupported':96,'tlc.invalid':64}
# Request/prefix diagnostics retain physical transaction facts and named faults.
run('committed-prefix-focused',['cargo','test','--locked','-p','dive-check','--test','observer_barrier','--','--test-threads=2'])
# Library store controls are independent of engine routing.
run('fallible-store-focused',['cargo','test','--locked','-p','dive-store','--lib','seen::','--','--test-threads=2'])
run('cargo-guide-disk-seen',['cargo','run','--locked','-p','dive-store','--example','disk_seen'])

# The complete original tuple-only582 consumers get this combined source's
# newly built outputs, not the archived component's publication binaries.
run('tuple-only-replay-combined',['python3','-I','/tmp/dive-core-prefix-storage-tuple-runtime.py'])
# Supplemental finite While selection uses its separately archived exact driver.
while_driver=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/while-models-bounded.py')
while_copy=out/'while-models-bounded.py';while_copy.write_bytes(while_driver.read_bytes())
assert while_copy.read_bytes()==while_driver.read_bytes()
run('nested-while-models',['python3','-I',str(while_copy),'--base',str(root/'crates/dive-pluscal/nested-procedure-checksum-acceptance'),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(nested_epoch/'while-models-bounded')])
wmodels=json.loads((nested_epoch/'while-models-bounded/report.json').read_text())
assert wmodels['selected']==12 and wmodels['worker_store_controls']==96
assert sum(row['outcome']=='named-generation-refusal' for row in wmodels['rows'])==4

unchanged();(out/'closure.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps,'all_consumers_closed':True,'family_certified':False},indent=2)+'\n');print('Fresh Cargo guides and immutable-binary gates closed',flush=True)
