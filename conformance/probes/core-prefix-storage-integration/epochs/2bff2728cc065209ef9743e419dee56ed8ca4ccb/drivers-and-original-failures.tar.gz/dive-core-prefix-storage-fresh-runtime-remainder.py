from pathlib import Path
import subprocess,json,hashlib,os,time,re,shutil
root=Path('/Users/jeff/code/dive-native-operator-integration-work')
frozen=json.loads(Path('/tmp/dive-core-prefix-storage-frozen-source/source.json').read_text())
gate=json.loads(Path('/tmp/dive-core-prefix-storage-gate-steps.json').read_text())
assert len(gate)==8 and all(s['exit']==0 for s in gate),'full frozen gate not closed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
out=Path('/tmp/dive-core-prefix-storage-fresh-runtime-remainder');out.mkdir(exist_ok=False)
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache'}
steps=[]
def unchanged():
 for rel,h in frozen['source_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel
 for rel,h in frozen['integrity_output_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel

def run(name,command):
 unchanged();start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()};steps.append(row);(out/'steps.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps},indent=2)+'\n');print(name,'exit',r.returncode,flush=True);unchanged()
 if r.returncode:raise SystemExit(r.returncode)


prior=Path('/tmp/dive-core-prefix-storage-fresh-runtime')
prior_index=json.loads(Path('/tmp/dive-core-prefix-storage-first-runtime-failure.json').read_text())
assert prior_index['source_commit']==frozen['source_commit']
for rel,digest in prior_index['files'].items():
 assert hashlib.sha256((prior/rel).read_bytes()).hexdigest()==digest,rel
prior_steps=json.loads((prior/'steps.json').read_text())
assert len(prior_steps['steps'])==20 and all(s['exit']==0 for s in prior_steps['steps'])
for s in prior_steps['steps']:
 for stream in ['stdout','stderr']:
  assert hashlib.sha256((prior/(s['name']+'.'+stream)).read_bytes()).hexdigest()==s[stream+'_sha256']
snapshot_paths=list((prior/'snapshot-runtime').glob('*.json'))
expected={f'original-{i:03}' for i in range(26)}|{f'precedence-{i:03}' for i in range(12)}
expected|={f'{kind}-w{width}' for kind in ['prefix-guarded','prefix-within-budget','prefix-validator-refused','replay'] for width in [1,3,4,8]}
assert {p.stem for p in snapshot_paths}==expected
for path in snapshot_paths:
 row=json.loads(path.read_text());assert not row['model_proof'] and not row['ordinary_schedule_certified']
 if path.stem.startswith(('replay-','prefix-guarded-','prefix-within-budget-')):
  assert row['memory']==row['json']=='Valid'
  assert row['fresh_validator_profile']==row['producer_profile']=='tlc'
  assert row['wrong_init'].startswith('Invalid(') and row['wrong_closing_next'].startswith('Invalid(') and 'Next' in row['wrong_closing_next']
  assert row['wrong_property'].startswith('Invalid(') and row['malformed_ending'].startswith('Invalid(')
 if path.stem.startswith('prefix-validator-refused-'):
  assert row['memory']==row['json'] and row['memory'].startswith('Unsupported(') and 'quantifier domain materialization work' in row['memory']
(out/'resumption.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'previous_failed_epoch':str(prior),'previous_payloads':prior_index['files'],'corrected_census':{'snapshot_original':38,'added_prefix':12,'replay':4},'qualification':'resume after already closed actual Cargo stages; correcting external count only; no production source or test change'},indent=2)+'\n')
print('Verified 20 closed original stages and all 54 snapshot captures; resuming release',flush=True)
unchanged()
run('release',['cargo','build','--release','--locked','-p','dive-cli','-p','dive-conformance'])
bins=out/'bins';bins.mkdir()
for name in ['dive','dive-conformance']:
 src=Path(env['CARGO_TARGET_DIR'])/'release'/name;dst=bins/name;shutil.copy2(src,dst);assert src.read_bytes()==dst.read_bytes();dst.chmod(0o555)
# Explicit CLI build above is distinct from --examples; copy actual fresh outputs.
run('release-pluscal-examples',['cargo','build','--release','--locked','-p','dive-pluscal','--example','define_checksum'])
run('release-api-examples',['cargo','build','--release','--locked','-p','dive-api','--example','pluscal_source_context','--example','pluscal_source_cst','--example','pluscal_definitions','--example','pluscal_definition_forms','--example','pluscal_procedure_checksum','--example','pluscal_nested_procedure_checksum'])
for source_name,alias in [('define_checksum','checksum'),('pluscal_source_context','context'),('pluscal_source_cst','cst'),('pluscal_definitions','define-guide'),('pluscal_definition_forms','forms-guide')]:
 src=Path(env['CARGO_TARGET_DIR'])/'release/examples'/source_name;dst=bins/alias;shutil.copy2(src,dst);assert src.read_bytes()==dst.read_bytes();dst.chmod(0o555)
# Re-run the exact public macro guide fences against fresh combined binaries.
macro = root/'crates/dive-pluscal/macro-checksum-acceptance/guide'
primary = json.loads((macro/'primary/manifest.json').read_text())
primary_rows = {r['id']:r for r in primary['rows']}
fences = re.findall(r'```tla\n(.*?)\n```', (root/'docs/pluscal-macro-checksums.md').read_text(), re.S)
assert len(fences)==2
for index, case in enumerate(['Guide_P','Guide_C']):
 tracked_source = macro/'cases'/(case+'.tla')
 assert tracked_source.read_text().rstrip()==fences[index].rstrip()
 guide_dir=out/'guide-inputs';guide_dir.mkdir(exist_ok=True)
 module=re.search(r'---- MODULE (\w+) ----',tracked_source.read_text()).group(1)
 source=guide_dir/(module+'.tla');source.write_bytes(tracked_source.read_bytes())
 assert source.read_bytes()==tracked_source.read_bytes()
 input_hash = hashlib.sha256(source.read_bytes()).hexdigest()
 for profile in ['dive','tlc']:
  name='macro-cli-'+case+'-'+profile
  command=[str(bins/'dive'),'translate',str(source),'--rewrite','--checksums','full','--output','json']
  if profile=='tlc':command.append('--compat=tlc')
  run(name,command)
  report=json.loads((out/(name+'.stdout')).read_text())
  assert report['result']=='replacement' and report['accepted'] and report['exit_code']==0,report
  assert report['algorithm_checksum_verified'] and report['body_checksum_verified'],report
  assert not report['model_proved'] and not report['exhaustive'],report
  assert report['profile']==profile,report
  assert report['replacement']['module_source'],report
 run('macro-api-'+case,['cargo','run','--locked','-p','dive-api','--example','pluscal_source_context','--',str(source),'rewrite','declared','tlc'])
 api=json.loads((out/('macro-api-'+case+'.stdout')).read_text())
 assert api['result']=='replacement' and api['accepted'] and api['algorithm_checksum_verified'] and api['body_checksum_verified'],api
 assert not api['model_proved'] and not api['exhaustive'],api
 run('macro-raw-'+case,['cargo','run','--locked','-p','dive-pluscal','--example','macro_checksum','--',str(source)])
 raw=json.loads((out/('macro-raw-'+case+'.stdout')).read_text())
 assert not raw['artifact_admitted'] and not raw['model_proved'] and not raw['family_certified'],raw
 assert raw['checksum']['Ok']['serialized_ast']==(macro/'primary'/(case+'.translated.ast')).read_text(),raw
 assert raw['checksum']['Ok']['checksum']==primary_rows[case]['stages']['translated']['crc'],raw
 assert hashlib.sha256(source.read_bytes()).hexdigest()==input_hash

producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binaries':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in bins.iterdir()},'qualification':'Fresh combined binaries; gate/current source separate from archived original observations; no family certification'};(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
# The new procedure API example is a fresh output, not an old binary alias.
src=Path(env['CARGO_TARGET_DIR'])/'release/examples/pluscal_procedure_checksum'
shutil.copy2(src,bins/'procedure-guide');assert src.read_bytes()==(bins/'procedure-guide').read_bytes();(bins/'procedure-guide').chmod(0o555)
producer['binaries']['procedure-guide']=hashlib.sha256((bins/'procedure-guide').read_bytes()).hexdigest()
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
# Fresh original producer-request diagnostic selection; ordinal source callbacks
# retain their old contract, and do not certify request-owned prefix service.
env['DIVE_PERIODIC_SNAPSHOT_CAPTURE']=str(out/'request-snapshot-runtime')
env['DIVE_PROGRESS_QUEUE_NATIVE_CAPTURE']=str(out/'request-runtime')
run('request-outcomes',['cargo','test','--locked','-p','dive-liveness','--test','periodic_snapshot','--','--test-threads=2'])
env.pop('DIVE_PERIODIC_SNAPSHOT_CAPTURE');env.pop('DIVE_PROGRESS_QUEUE_NATIVE_CAPTURE')
for test,label in [('configured_candidate_precedes_false_hook_and_replays_on_fresh_binding','old-timer'),('real_request_pause_retains_uncommitted_facts_and_existing_candidate_replay','new-request')]:
 env['DIVE_PERIODIC_SNAPSHOT_CAPTURE']=str(out/('request-replay-'+label))
 run('request-replay-'+label,['cargo','test','--locked','-p','dive-liveness','--test','periodic_snapshot',test,'--','--exact','--test-threads=2'])
 env.pop('DIVE_PERIODIC_SNAPSHOT_CAPTURE')
# New native storage-format runtime retains its original full 192-triple selection.
# Only path/environment identities are adapted; the receiving producer is separate.
storage_bins=out/'storage-binaries';storage_bins.mkdir()
for name in ['dive','dive-conformance']:shutil.copy2(bins/name,storage_bins/name)
storage_producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binaries_sha256':{n:hashlib.sha256((storage_bins/n).read_bytes()).hexdigest() for n in ['dive','dive-conformance']},'qualification':'Fresh receiving source; original ead runtime/source receipts unchanged'}
(storage_bins/'producer.json').write_text(json.dumps(storage_producer,indent=2)+'\n')
original=Path('/Users/jeff/code/dive-storage-tuple-function-artifacts/runtime-driver.py')
text=original.read_text().replace('/Users/jeff/code/dive-trace-representation-work',str(root)).replace('/Users/jeff/code/dive-trace-representation-target',env['CARGO_TARGET_DIR']).replace('/Users/jeff/code/dive-trace-representation-cache',env['DIVE_CACHE_DIR']).replace('/Users/jeff/code/dive-storage-tuple-function-artifacts',str(out))
text=text.replace("OUT=ART/'current-runtime';BIN=ART/'current-binaries/dive'", "OUT=ART/'storage-runtime';BIN=ART/'storage-binaries/dive'")
target=out/'storage-runtime-driver.py';target.write_text(text)
(out/'storage-runtime-driver-input.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':'Paths/environment identities only; explicit fresh receiving producer; case selection/assertions unchanged'},indent=2)+'\n')
run('storage-runtime',['python3','-I',str(target)])
storage=json.loads((out/'storage-runtime/receipt.json').read_text());assert storage['runtime_producer']==storage_producer
assert len(storage['rows'])==192 and len(storage['validation'])==768 and len(storage['old_archives'])==12
assert sum(r['result']=='valid' for r in storage['validation'])==192 and sum(r['result']=='invalid' for r in storage['validation'])==576

# Separate current source/binary authority for the path-adapted original v2 driver.
v2_bins=out/'trace-binaries';v2_bins.mkdir()
for name in ['dive','dive-conformance']:
 shutil.copy2(bins/name,v2_bins/name);assert (v2_bins/name).read_bytes()==(bins/name).read_bytes()
v2_producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binaries_sha256':{n:hashlib.sha256((v2_bins/n).read_bytes()).hexdigest() for n in ['dive','dive-conformance']},'qualification':'Fresh receiving source; does not replace original e6 producer'}
(v2_bins/'producer.json').write_text(json.dumps(v2_producer,indent=2)+'\n')
original=root/'conformance/probes/trace-representation-v2/current/runtime/driver.py'
text=original.read_text().replace('/Users/jeff/code/dive-trace-representation-work',str(root)).replace('/Users/jeff/code/dive-trace-representation-artifacts/current-runtime',str(out/'trace-runtime')).replace('/Users/jeff/code/dive-trace-representation-artifacts/current-binaries/dive',str(v2_bins/'dive'))
target=out/'trace-runtime-driver.py';target.write_text(text)
(out/'trace-runtime-driver-input.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':'Paths only; explicit fresh receiving producer'},indent=2)+'\n')
run('trace-v2-runtime',['python3','-I',str(target)])
trace_receipt=json.loads((out/'trace-runtime/receipt.json').read_text());assert len(trace_receipt['rows'])==72 and len(trace_receipt['validation'])==288
assert sum(r['kind']=='original' and r['result']=='valid' for r in trace_receipt['validation'])==72
assert sum(r['kind']!='original' and r['result']=='invalid' for r in trace_receipt['validation'])==216
run('trace-v2-unsupported',['python3','-I','/tmp/dive-core-snapshot-trace-unsupported.py',str(out)])
# Original pinned Java adapter and module-library bytes are frozen as inputs,
# never called a newly compiled adapter or root native output.
base=root/'crates/dive-pluscal/define-acceptance'
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
assert hashlib.sha256(jar.read_bytes()).hexdigest()=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
adapter=out/'java-adapter';library=out/'reference-library'
shutil.copytree('/Users/jeff/code/dive-pluscal-definitions-artifacts/adapter',adapter)
shutil.copytree('/Users/jeff/code/dive-pluscal-definitions-artifacts/reference-library',library)
reference_hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in [adapter,library] for p in folder.rglob('*') if p.is_file()}
reference_hashes['java']=hashlib.sha256(java.read_bytes()).hexdigest();reference_hashes['jar']=hashlib.sha256(jar.read_bytes()).hexdigest()
(out/'reference-inputs.json').write_text(json.dumps({'hashes':reference_hashes,'qualification':'Copied original adapter class and module-library input bytes; not claimed freshly compiled native outputs'},indent=2)+'\n')
run('define-raw',['python3','-I',str(base/'compare.py'),'--base',str(base),'--binary',str(bins/'checksum'),'--out',str(out/'define-raw')])
raw=json.loads((out/'define-raw/report.json').read_text());assert raw['selected']==136 and raw['summary']=={'exact-raw-ast':84,'primary-invalid-raw-uncredited':18,'named-refusal':32,'rejection-accounted':2}
run('define-public',['python3','-I',str(base/'public-controls.py'),'--base',str(base),'--binary',str(bins/'dive'),'--cst',str(bins/'cst'),'--java',str(java),'--jar',str(jar),'--adapter',str(adapter),'--library',str(library),'--out',str(out/'define-public')])
public=json.loads((out/'define-public/report.json').read_text());assert public['selected']==272 and public['summary']=={'admitted-exact-cst-sany-validator':168,'invalid-primary-uncredited':88,'named-public-refusal':12,'rejection-accounted':4}
run('define-models',['python3','-I',str(base/'models.py'),'--base',str(base),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(out/'define-models')])
models=json.loads((out/'define-models/report.json').read_text())
assert len(models['rows'])==24 and models['worker_store_controls']==288 and models['valid_witness_controls']==12 and models['rejected_mutants']==48
import gzip
for row in models['rows']:
 assert len(row['settings'])==12 and { (s['profile'],s['workers'],s['store']) for s in row['settings']}=={(p,w,s) for p in ['dive','tlc'] for w in [1,4,8] for s in ['fp','exact']}
 for setting in row['settings']:
  capture=setting['capture'];stream=gzip.decompress((out/'define-models'/capture['stdout']['path']).read_bytes())
  assert hashlib.sha256(stream).hexdigest()==capture['stdout']['sha256']
  actual=json.loads(stream);assert actual['verdict']==('invariant-violation' if row['id'].endswith('.violation') else 'success')
  assert all(actual['statistics'][k]==v for k,v in row['primary_counts'].items())
 for control in row['independent_validation']:
  capture=control['capture'];stream=gzip.decompress((out/'define-models'/capture['stdout']['path']).read_bytes())
  assert hashlib.sha256(stream).hexdigest()==capture['stdout']['sha256']
  actual=json.loads(stream);assert actual['result']==('valid' if control['control']=='original' else 'invalid')
run('define-guides',['python3','-I',str(base/'guides.py'),'--base',str(base/'guide'),'--binaries',str(bins),'--out',str(out/'define-guides')])
assert json.loads((out/'define-guides/report.json').read_text())['selected']==10
run('define-checksum-controls',['python3','-I',str(base/'checksum-controls.py'),'--base',str(base/'guide'),'--binaries',str(bins),'--java',str(java),'--jar',str(jar),'--adapter',str(adapter),'--out',str(out/'define-checksum-controls')])
crc=json.loads((out/'define-checksum-controls/report.json').read_text());assert crc['selected']==12 and sum(r['outcome']=='valid-unchanged' for r in crc['rows'])==2 and sum(r['outcome']=='corruption-refused' for r in crc['rows'])==10
for rel,h in reference_hashes.items():
 if rel not in ['java','jar']:assert hashlib.sha256((out/rel).read_bytes()).hexdigest()==h
forms=root/'crates/dive-pluscal/define-forms-acceptance'
# Actual checked-in API guide, including module filenames and reference admission.
for syntax in ['C','P']:
 source=forms/'guide/cases'/('Forms_'+syntax+'_local_calls_function.tla')
 run('cargo-guide-pluscal-forms-'+syntax,['cargo','run','--locked','-p','dive-api','--example','pluscal_definition_forms','--',str(source),*(['tlc'] if syntax=='P' else [])])
 report=json.loads((out/('cargo-guide-pluscal-forms-'+syntax+'.stdout')).read_text())
 assert report['accepted'] and report['result']=='replacement' and not report['model_proved'] and not report['exhaustive']
forms_adapter=out/'adapter';forms_library=out/'forms-reference-library'
shutil.copytree('/Users/jeff/code/dive-pluscal-definition-forms-artifacts/adapter',forms_adapter)
shutil.copytree('/Users/jeff/code/dive-pluscal-definition-forms-artifacts/reference-library',forms_library)
(out/'forms-reference-inputs.json').write_text(json.dumps({'hashes':{str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in [forms_adapter,forms_library] for p in folder.rglob('*') if p.is_file()},'qualification':'Original development adapter/library input bytes, independently hashed; not rebuilt native outputs'},indent=2)+'\n')
run('forms-raw',['python3','-I',str(forms/'compare.py'),'--base',str(forms),'--binary',str(bins/'checksum'),'--out',str(out/'forms-raw')])
assert json.loads((out/'forms-raw/report.json').read_text())['summary']=={'exact-raw-ast':152,'primary-invalid-raw-uncredited':28,'named-refusal':52,'rejection-accounted':2}
run('forms-public',['python3','-I',str(forms/'public-controls.py'),'--base',str(forms),'--binary',str(bins/'dive'),'--cst',str(bins/'cst'),'--java',str(java),'--jar',str(jar),'--adapter',str(forms_adapter),'--library',str(forms_library),'--out',str(out/'forms-public')])
assert json.loads((out/'forms-public/report.json').read_text())['summary']=={'admitted-exact-cst-sany-validator':304,'invalid-primary-uncredited':124,'named-public-refusal':36,'rejection-accounted':4}
run('forms-models',['python3','-I',str(forms/'models.py'),'--base',str(forms),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(out/'forms-models')])
forms_models=json.loads((out/'forms-models/report.json').read_text())
assert forms_models['selected']==16 and forms_models['worker_store_controls']==192 and forms_models['valid_witness_controls']==8 and forms_models['rejected_mutants']==32
for row in forms_models['rows']:
 assert len(row['settings'])==12 and {(x['profile'],x['workers'],x['store']) for x in row['settings']}=={(p,w,s) for p in ['dive','tlc'] for w in [1,4,8] for s in ['fp','exact']}
 for setting in row['settings']:
  raw=gzip.decompress((out/'forms-models'/setting['capture']['stdout']['path']).read_bytes());assert hashlib.sha256(raw).hexdigest()==setting['capture']['stdout']['sha256']
  actual=json.loads(raw);assert actual['verdict']==('invariant-violation' if row['id'].endswith('.violation') else 'success') and all(actual['statistics'][k]==v for k,v in row['primary_counts'].items())
 for control in row['independent_validation']:
  actual=json.loads(gzip.decompress((out/'forms-models'/control['capture']['stdout']['path']).read_bytes()));assert actual['result']==('valid' if control['control']=='original' else 'invalid')
forms_bins=out/'forms-bins';forms_bins.mkdir()
for alias,name in [('dive','dive'),('cst','cst'),('checksum','checksum'),('define-guide','forms-guide')]:
 target=forms_bins/alias;shutil.copy2(bins/name,target);assert target.read_bytes()==(bins/name).read_bytes();target.chmod(0o555)
(out/'forms-binary-inputs.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'aliases':{alias:{'source_binary':name,'sha256':hashlib.sha256((forms_bins/alias).read_bytes()).hexdigest()} for alias,name in [('dive','dive'),('cst','cst'),('checksum','checksum'),('define-guide','forms-guide')]}},indent=2)+'\n')
run('forms-guides',['python3','-I',str(forms/'guides.py'),'--base',str(forms/'guide'),'--binaries',str(forms_bins),'--out',str(out/'corrected-guides')])
assert json.loads((out/'corrected-guides/report.json').read_text())['selected']==10
run('forms-checksum-controls',['python3','-I',str(forms/'checksum-controls.py'),'--base',str(forms/'guide'),'--binaries',str(forms_bins),'--java',str(java),'--jar',str(jar),'--adapter',str(forms_adapter),'--out',str(out/'forms-crc')])
assert json.loads((out/'forms-crc/report.json').read_text())['selected']==12
for original in ['namespace-run.py','cross-state-run.py','cross-state-stages.py','forgery-run-corrected.py']:
 archived=Path('/Users/jeff/code/dive-pluscal-definition-forms-artifacts')/original
 text=archived.read_text().replace('/Users/jeff/code/dive-pluscal-definition-forms-artifacts',str(out)).replace('/Users/jeff/code/dive-pluscal-definition-forms-cache','/Users/jeff/code/dive-shipping-cache').replace("'runtime-corrected/dive'","'bins/dive'").replace("'runtime-corrected/cst'","'bins/cst'").replace("'reference-library'","'forms-reference-library'")
 target=out/original;target.write_text(text)
 (out/(original+'.input.json')).write_text(json.dumps({'original_path':str(archived),'original_sha256':hashlib.sha256(archived.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':'Paths only; fresh root binaries/output, original reference inputs independently hashed'},indent=2)+'\n')
 run('forms-'+original.removesuffix('.py'),['python3','-I',str(target)])
for folder,count in [('namespace-corrected',24),('cross-state-controls',72),('cross-state-artifact-controls',6),('public-forgeries-corrected',28)]:assert json.loads((out/folder/'report.json').read_text())['selected']==count
run('forms-prestate',['python3','-I','/tmp/dive-core-definition-forms-prestate.py',str(out)])
assert json.loads((out/'prestate-controls/report.json').read_text())['selected']==96
view_producer={'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'binary_sha256':producer['binaries']['dive'],'qualification':'Fresh root combined runtime; original component producer remains separately retained; no family certification'}
(out/'view-producer.json').write_text(json.dumps(view_producer,indent=2)+'\n')
run('view-random-full-campaign',['python3','-I','conformance/probes/view-random-stream/capture_native.py',str(out/'view-runtime'),str(bins/'dive'),str(out/'view-producer.json')])
view_receipt=json.loads((out/'view-runtime/receipt.json').read_text());assert len(view_receipt['rows'])==3360 and len(view_receipt['validation'])==960
for corpus,listfile in [('examples','conformance/gates/cm1.txt'),('validation-smoke','conformance/gates/validation-smoke.txt')]:
 selection=[line.split('#',1)[0].strip() for line in (root/listfile).read_text().splitlines()];selection=[s for s in selection if s];assert selection
 command=[str(bins/'dive-conformance'),'run','--impl','dive','--impl-profile','tlc','--corpus',corpus,'--tier','all','--no-sany','--no-summary','--report-dir',str(out/('report-'+corpus)),'--dive-bin',str(bins/'dive'),'--workers','1,4,8']
 for model in selection:command.extend(['--filter',model])
 run('gate-'+corpus,command)
 rows=re.findall(r'^\[(\d+)/(\d+)\] (\S+) ',(out/('gate-'+corpus+'.stderr')).read_text(),re.M);assert len(rows)==len(selection),(corpus,len(rows),len(selection));assert all(outcome=='agree' for _,_,outcome in rows),rows
 reports=list((out/('report-'+corpus)).glob('*.json'));assert len(reports)==1,reports
 report=json.loads(reports[0].read_text());assert len(report['models'])==len(selection)
 assert report['summary']['models_selected']==len(selection) and report['summary']['models']['agree']==len(selection)
 for model in report['models']:
  assert model['outcome']=='agree',model
  assert {r['workers'] for r in model['runs']}=={1,4,8},model
  assert all(r['outcome']=='agree' and not r['diffs'] for r in model['runs']),model
 print(corpus,len(rows),'full agreements at requested workers1/4/8',flush=True)
# Fresh sequential-procedure header and public generation admission are separate
# from model verdicts and strict saved-stack word refusals.
proc=root/'crates/dive-pluscal/procedure-checksum-acceptance'
proc_adapter=out/'procedure-adapter';proc_library=out/'procedure-reference-library'
shutil.copytree('/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/adapter',proc_adapter)
shutil.copytree('/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/reference-library',proc_library)
(out/'procedure-reference-inputs.json').write_text(json.dumps({'hashes':{str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for f in [proc_adapter,proc_library] for p in f.rglob('*') if p.is_file()},'qualification':'Original immutable adapter/library input bytes, no newly compiled Java claim'},indent=2)+'\n')
run('procedure-raw',['python3','-I',str(proc/'compare.py'),'--base',str(proc),'--binary',str(bins/'checksum'),'--out',str(out/'procedure-raw')])
assert json.loads((out/'procedure-raw/report.json').read_text())['summary']=={'exact-raw-ast':90,'named-refusal':24,'rejection-accounted':16,'primary-invalid-raw-uncredited':2}
run('procedure-public',['python3','-I',str(proc/'public-controls.py'),'--base',str(proc),'--binary',str(bins/'dive'),'--cst',str(bins/'cst'),'--java',str(java),'--jar',str(jar),'--adapter',str(proc_adapter),'--library',str(proc_library),'--out',str(out/'procedure-public')])
assert json.loads((out/'procedure-public/report.json').read_text())['summary']=={'admitted-exact-cst-sany-validator':180,'rejection-accounted':36,'named-public-refusal':36,'invalid-primary-uncredited':12}
procedure_epoch=out/'procedure-models';procedure_epoch.mkdir()
run('procedure-models',['python3','-I',str(proc/'models.py'),'--base',str(proc),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(procedure_epoch/'models')])
pmodels=json.loads((out/'procedure-models/models/report.json').read_text());assert pmodels['selected']==32 and pmodels['worker_store_controls']==384
run('procedure-replay',['python3','-I',str(proc/'replay.py'),'--models',str(procedure_epoch/'models'),'--binary',str(bins/'dive'),'--out',str(out/'procedure-replay')])
preplay=json.loads((out/'procedure-replay/report.json').read_text());assert preplay['selected']==160 and preplay['summary']=={'dive.valid':16,'dive.invalid':64,'tlc.unsupported':48,'tlc.invalid':32}
run('procedure-guides',['python3','-I',str(proc/'guides.py'),'--base',str(proc),'--binaries',str(bins),'--worktree',str(root),'--target',env['CARGO_TARGET_DIR'],'--out',str(out/'procedure-guides')])
assert json.loads((out/'procedure-guides/report.json').read_text())['selected']==20

# New bounded nested-transfer continuation: preserve all original stage IDs.
# Original component observations remain archived under their own producer.
for source_name,alias in [('pluscal_nested_procedure_checksum','nested-guide')]:
 src=Path(env['CARGO_TARGET_DIR'])/'release/examples'/source_name; dst=bins/alias
 shutil.copy2(src,dst); assert src.read_bytes()==dst.read_bytes(); dst.chmod(0o555)
 producer['binaries'][alias]=hashlib.sha256(dst.read_bytes()).hexdigest()
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
nested_original=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/native-final')
nested_epoch=out/'nested-runtime';nested_epoch.mkdir()
campaign=json.loads((nested_original/'campaign.json').read_text())
assert campaign['passed'] and len(campaign['completed'])==13
replacements={
 '/Users/jeff/code/dive-pluscal-definition-forms-work':str(root),
 str(nested_original):str(nested_epoch),
 '/Users/jeff/code/dive-pluscal-definition-forms-cache':env['DIVE_CACHE_DIR'],
 '/Users/jeff/code/dive-pluscal-macro-checksum-target':env['CARGO_TARGET_DIR'],
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/adapter':str(proc_adapter),
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/reference-library':str(proc_library),
}
# Actual fresh binaries, copied under the declared native campaign layout.
shutil.copytree(bins,nested_epoch/'bins')
for i,stage in enumerate(campaign['completed']):
 if i>=11:continue # same exact full CM1/VTS selection already runs above
 command=[]
 for arg in stage['command']:
  for old,new in replacements.items():arg=arg.replace(old,new)
  command.append(arg)
 run('nested-campaign-'+str(i),command)
for location,count in [('raw-original',180),('public-original',360),('raw-while-tail',4),('public-while-tail',8),('raw-while-lines',8),('public-while-lines',16)]:
 report=json.loads((nested_epoch/location/'report.json').read_text())
 assert report['selected']==count
assert json.loads((nested_epoch/'models/report.json').read_text())['worker_store_controls']==768
assert json.loads((nested_epoch/'replay/report.json').read_text())['summary']=={'dive.valid':32,'dive.invalid':128,'tlc.unsupported':96,'tlc.invalid':64}
# Request/prefix diagnostics retain physical transaction facts and named faults.
run('committed-prefix-focused',['cargo','test','--locked','-p','dive-check','--test','observer_barrier','--','--test-threads=2'])
# Library store controls are independent of engine routing.
run('fallible-store-focused',['cargo','test','--locked','-p','dive-store','--lib','seen::','--','--test-threads=2'])
run('cargo-guide-disk-seen',['cargo','run','--locked','-p','dive-store','--example','disk_seen'])

# The complete original tuple-only582 consumers get this combined source's
# newly built outputs, not the archived component's publication binaries.
run('tuple-only-replay-combined',['python3','-I','/tmp/dive-core-prefix-storage-tuple-runtime.py'])
# Supplemental finite While selection uses its separately archived exact driver.
while_driver=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/while-models-bounded.py')
while_copy=out/'while-models-bounded.py';while_copy.write_bytes(while_driver.read_bytes())
assert while_copy.read_bytes()==while_driver.read_bytes()
run('nested-while-models',['python3','-I',str(while_copy),'--base',str(root/'crates/dive-pluscal/nested-procedure-checksum-acceptance'),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(nested_epoch/'while-models-bounded')])
wmodels=json.loads((nested_epoch/'while-models-bounded/report.json').read_text())
assert wmodels['selected']==12 and wmodels['worker_store_controls']==96
assert sum(row['outcome']=='named-generation-refusal' for row in wmodels['rows'])==4

unchanged();(out/'closure.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps,'all_consumers_closed':True,'family_certified':False},indent=2)+'\n');print('Fresh Cargo guides and immutable-binary gates closed',flush=True)
