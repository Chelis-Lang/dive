from pathlib import Path
p=Path('/tmp/dive-core-prefix-storage-procedure-resume.py');s=p.read_text();header=s[:s.index("prior=Path(")].replace('/tmp/dive-core-prefix-storage-procedure-resume','/tmp/dive-core-prefix-storage-nested-resume')
setup='''prior=Path('/tmp/dive-core-prefix-storage-procedure-resume')
prior_steps=json.loads((prior/'steps.json').read_text())['steps']
assert len(prior_steps)==7 and all(row['exit']==0 for row in prior_steps)
assert [r['name']for r in prior_steps][-2:]==['nested-campaign-0','nested-campaign-1']
files={str(p.relative_to(prior)):hashlib.sha256(p.read_bytes()).hexdigest()for p in prior.rglob('*')if p.is_file()}
(out/'interrupted-original-index.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'files':files,'qualification':'Original sevenclosed actualstages retained; ENOSPC before eighth command launches; resume remaining consumers only'},indent=2)+'\\n')
for name in ['bins','procedure-adapter','procedure-reference-library','nested-runtime']:
 shutil.copytree(prior/name,out/name)
bins=out/'bins';producer=json.loads((prior/'producer.json').read_text());(out/'producer.json').write_bytes((prior/'producer.json').read_bytes())
proc=root/'crates/dive-pluscal/procedure-checksum-acceptance';proc_adapter=out/'procedure-adapter';proc_library=out/'procedure-reference-library'
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
unchanged()
'''
tail=s[s.index("# New bounded nested-transfer continuation:"):]
tail=tail.replace("nested_epoch=out/'nested-runtime';nested_epoch.mkdir()", "nested_epoch=out/'nested-runtime';assert nested_epoch.is_dir()")
tail=tail.replace("shutil.copytree(bins,nested_epoch/'bins')", "assert (nested_epoch/'bins').is_dir()")
tail=tail.replace("if i>=11:continue", "if i<2 or i>=11:continue")
Path('/tmp/dive-core-prefix-storage-nested-resume.py').write_text(header+setup+tail)
