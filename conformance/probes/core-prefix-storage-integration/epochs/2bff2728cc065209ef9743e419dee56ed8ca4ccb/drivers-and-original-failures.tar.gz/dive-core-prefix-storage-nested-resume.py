from pathlib import Path
import subprocess,json,hashlib,os,time,re,shutil
root=Path('/Users/jeff/code/dive-native-operator-integration-work')
frozen=json.loads(Path('/tmp/dive-core-prefix-storage-frozen-source/source.json').read_text())
gate=json.loads(Path('/tmp/dive-core-prefix-storage-gate-steps.json').read_text())
assert len(gate)==8 and all(s['exit']==0 for s in gate),'full frozen gate not closed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
out=Path('/tmp/dive-core-prefix-storage-nested-resume');out.mkdir(exist_ok=False)
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache'}
steps=[]
def unchanged():
 for rel,h in frozen['source_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel
 for rel,h in frozen['integrity_output_sha256'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel

def run(name,command):
 unchanged();start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()};steps.append(row);(out/'steps.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps},indent=2)+'\n');print(name,'exit',r.returncode,flush=True);unchanged()
 if r.returncode:raise SystemExit(r.returncode)


prior=Path('/tmp/dive-core-prefix-storage-procedure-resume')
prior_steps=json.loads((prior/'steps.json').read_text())['steps']
assert len(prior_steps)==7 and all(row['exit']==0 for row in prior_steps)
assert [r['name']for r in prior_steps][-2:]==['nested-campaign-0','nested-campaign-1']
files={str(p.relative_to(prior)):hashlib.sha256(p.read_bytes()).hexdigest()for p in prior.rglob('*')if p.is_file()}
(out/'interrupted-original-index.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'files':files,'qualification':'Original sevenclosed actualstages retained; ENOSPC before eighth command launches; resume remaining consumers only'},indent=2)+'\n')
for name in ['bins','procedure-adapter','procedure-reference-library','nested-runtime']:
 shutil.copytree(prior/name,out/name)
bins=out/'bins';producer=json.loads((prior/'producer.json').read_text());(out/'producer.json').write_bytes((prior/'producer.json').read_bytes())
proc=root/'crates/dive-pluscal/procedure-checksum-acceptance';proc_adapter=out/'procedure-adapter';proc_library=out/'procedure-reference-library'
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar')
unchanged()
# New bounded nested-transfer continuation: preserve all original stage IDs.
# Original component observations remain archived under their own producer.
for source_name,alias in [('pluscal_nested_procedure_checksum','nested-guide')]:
 src=Path(env['CARGO_TARGET_DIR'])/'release/examples'/source_name; dst=bins/alias
 shutil.copy2(src,dst); assert src.read_bytes()==dst.read_bytes(); dst.chmod(0o555)
 producer['binaries'][alias]=hashlib.sha256(dst.read_bytes()).hexdigest()
(out/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
nested_original=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/native-final')
nested_epoch=out/'nested-runtime';assert nested_epoch.is_dir()
campaign=json.loads((nested_original/'campaign.json').read_text())
assert campaign['passed'] and len(campaign['completed'])==13
replacements={
 '/Users/jeff/code/dive-pluscal-definition-forms-work':str(root),
 str(nested_original):str(nested_epoch),
 '/Users/jeff/code/dive-pluscal-definition-forms-cache':env['DIVE_CACHE_DIR'],
 '/Users/jeff/code/dive-pluscal-macro-checksum-target':env['CARGO_TARGET_DIR'],
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/adapter':str(proc_adapter),
 '/Users/jeff/code/dive-pluscal-procedure-checksum-artifacts/reference-library':str(proc_library),
}
# Actual fresh binaries, copied under the declared native campaign layout.
assert (nested_epoch/'bins').is_dir()
for i,stage in enumerate(campaign['completed']):
 if i<2 or i>=11:continue # same exact full CM1/VTS selection already runs above
 command=[]
 for arg in stage['command']:
  for old,new in replacements.items():arg=arg.replace(old,new)
  command.append(arg)
 run('nested-campaign-'+str(i),command)
for location,count in [('raw-original',180),('public-original',360),('raw-while-tail',4),('public-while-tail',8),('raw-while-lines',8),('public-while-lines',16)]:
 report=json.loads((nested_epoch/location/'report.json').read_text())
 assert report['selected']==count
assert json.loads((nested_epoch/'models/report.json').read_text())['worker_store_controls']==768
assert json.loads((nested_epoch/'replay/report.json').read_text())['summary']=={'dive.valid':32,'dive.invalid':128,'tlc.unsupported':96,'tlc.invalid':64}
# Request/prefix diagnostics retain physical transaction facts and named faults.
run('committed-prefix-focused',['cargo','test','--locked','-p','dive-check','--test','observer_barrier','--','--test-threads=2'])
# Library store controls are independent of engine routing.
run('fallible-store-focused',['cargo','test','--locked','-p','dive-store','--lib','seen::','--','--test-threads=2'])
run('cargo-guide-disk-seen',['cargo','run','--locked','-p','dive-store','--example','disk_seen'])

# The complete original tuple-only582 consumers get this combined source's
# newly built outputs, not the archived component's publication binaries.
run('tuple-only-replay-combined',['python3','-I','/tmp/dive-core-prefix-storage-tuple-runtime.py'])
# Supplemental finite While selection uses its separately archived exact driver.
while_driver=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/while-models-bounded.py')
while_copy=out/'while-models-bounded.py';while_copy.write_bytes(while_driver.read_bytes())
assert while_copy.read_bytes()==while_driver.read_bytes()
run('nested-while-models',['python3','-I',str(while_copy),'--base',str(root/'crates/dive-pluscal/nested-procedure-checksum-acceptance'),'--native',str(bins/'dive'),'--java',str(java),'--jar',str(jar),'--out',str(nested_epoch/'while-models-bounded')])
wmodels=json.loads((nested_epoch/'while-models-bounded/report.json').read_text())
assert wmodels['selected']==12 and wmodels['worker_store_controls']==96
assert sum(row['outcome']=='named-generation-refusal' for row in wmodels['rows'])==4

unchanged();(out/'closure.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps,'all_consumers_closed':True,'family_certified':False},indent=2)+'\n');print('Fresh Cargo guides and immutable-binary gates closed',flush=True)
