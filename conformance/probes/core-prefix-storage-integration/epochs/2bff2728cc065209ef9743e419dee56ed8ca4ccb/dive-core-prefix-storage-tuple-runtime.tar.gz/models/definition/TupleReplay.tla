---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Pair == <<0,1>>
Init == x=0
Next == x'=IF Len(Tail(Pair))=1 THEN 1 ELSE 2
Inv == x=0
====
