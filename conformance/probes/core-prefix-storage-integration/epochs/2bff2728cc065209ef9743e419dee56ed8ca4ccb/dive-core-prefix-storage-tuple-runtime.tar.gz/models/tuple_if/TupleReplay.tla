---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x=0
Next == x'=IF Len(Tail(IF x=0 THEN <<0,1>> ELSE <<2,3>>))=1 THEN 1 ELSE 2
Inv == x=0
====
