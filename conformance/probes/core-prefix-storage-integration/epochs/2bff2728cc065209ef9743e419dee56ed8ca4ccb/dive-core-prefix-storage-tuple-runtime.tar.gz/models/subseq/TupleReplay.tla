---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x=0
Next == x'=IF Len(SubSeq(<<0,1>>,2,2))=1 THEN 1 ELSE 2
Inv == x=0
====
