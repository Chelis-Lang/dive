---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Alias(v) == v
Init == x=0
Next == x'=IF Len(Alias(<<0,1>>))=1 THEN 1 ELSE 2
Inv == x=0
====
