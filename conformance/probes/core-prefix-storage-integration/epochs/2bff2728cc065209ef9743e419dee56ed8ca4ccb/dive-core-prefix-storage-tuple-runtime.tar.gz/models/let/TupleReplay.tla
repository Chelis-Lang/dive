---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x=0
Next == x'=IF Len(LET Pair == <<0,1>> IN Tail(Pair))=1 THEN 1 ELSE 2
Inv == x=0
====
