---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x=0
Next == x'=IF Len(<<0>> \o <<1>>)=1 THEN 1 ELSE 2
Inv == x=0
====
