---- MODULE TupleReplay ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Drop(v) == Tail(v)
Init == x=0
Next == x'=IF Len(Drop(<<0,1>>))=1 THEN 1 ELSE 2
Inv == x=0
====
