"""Retain omitted CI guard as a separate command on the same frozen source."""
from pathlib import Path
import hashlib,json,os,subprocess,time,shlex
root=Path('/Users/jeff/code/dive-native-operator-integration-work');epoch=Path('/tmp/dive-core-composed-qualified-epoch')
source=json.loads((epoch/'source-index.json').read_text());producer=source['producer'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def unchanged():
 assert subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=root,text=True).strip()==producer
 assert not subprocess.check_output(['git','--no-optional-locks','status','--porcelain'],cwd=root)
 for name,row in source['inputs'].items():assert sha(root/name)==row['sha256'],name
commands=json.loads(Path('/tmp/dive-core-composed-ci-command-supplement.json').read_text());assert commands==[['python3','-I','scripts/check-inductive-tuple-replay.py']]
unchanged();rows=[]
for i,command in enumerate(commands):
 start=time.monotonic();log=epoch/('ci-supplement-'+str(i)+'.log')
 with log.open('wb')as output:r=subprocess.run(command,cwd=root,env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache'},stdout=output,stderr=subprocess.STDOUT)
 rows.append({'name':'ci-supplement-'+str(i),'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(log)});unchanged()
 (epoch/'ci-supplement-receipt.json').write_text(json.dumps({'producer':producer,'source_index_sha256':sha(epoch/'source-index.json'),'scope':'The original declared61 offline commands omitted the inherited fixed-tuple guard. It is executed separately on unchanged frozen05b bytes; original71-row receipt is retained unchanged. Full CI Python guard coverage requires both receipts.','rows':rows},indent=2)+'\n')
 assert r.returncode==0
print('Closed inherited CI guard on unchanged producer',producer)
