from pathlib import Path
import subprocess,json,hashlib,gzip,os,time,shutil,re
root=Path('/Users/jeff/code/dive-native-operator-integration-work')
epoch=Path('/tmp/dive-core-composed-qualified-epoch')
source=json.loads((epoch/'source-index.json').read_text());producer=source['producer']
gate=json.loads((epoch/'gate-receipt.json').read_text());assert len(gate['rows'])==71 and all(r['exit']==0 for r in gate['rows'])
supplement=json.loads((epoch/'ci-supplement-receipt.json').read_text());assert supplement['producer']==producer and len(supplement['rows'])==1 and all(r['exit']==0 for r in supplement['rows'])
out=Path('/tmp/dive-core-composed-runtime');out.mkdir(exist_ok=False)
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-native-operator-integration-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-shipping-cache'}
target=Path(env['CARGO_TARGET_DIR']);bins=out/'bins';bins.mkdir();steps=[];binary_inputs={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def unchanged():
 assert subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=root,text=True).strip()==producer
 assert not subprocess.check_output(['git','--no-optional-locks','status','--porcelain'],cwd=root)
 for name,row in source['inputs'].items():assert sha(root/name)==row['sha256'],name
 for path,digest in binary_inputs.items():assert sha(path)==digest,str(path)

def run(name,cmd,extra=None):
 unchanged();start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(list(map(str,cmd)),cwd=root,env={**env,**(extra or {})},stdout=stdout,stderr=stderr)
 row={'name':name,'command':list(map(str,cmd)),'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr'))};steps.append(row);(out/'steps.json').write_text(json.dumps({'producer':producer,'family_certified':False,'rows':steps},indent=2)+'\n');print(name,r.returncode,flush=True);unchanged();assert r.returncode==0,name
 return out/(name+'.stdout')

def copy_binary(path,name):
 dest=bins/name;shutil.copy2(path,dest);assert sha(path)==sha(dest);dest.chmod(0o555);binary_inputs[dest]=sha(dest)

for package in ['dive-cli','dive-conformance','dive-trace']:
 text=run('features-'+package,['cargo','tree','--locked','-p',package,'--edges','normal,build,features']).read_text();assert 'test-rendezvous' not in text
build=run('default-release',['cargo','build','--release','--locked','-p','dive-cli','-p','dive-conformance','--message-format=json'])
artifacts={}
for line in build.read_text().splitlines():
 try:doc=json.loads(line)
 except json.JSONDecodeError:continue
 if doc.get('reason')=='compiler-artifact':
  lib=next((f for f in doc['filenames'] if f.endswith('.rlib')),None)
  if lib:artifacts[doc['target']['name']]=lib
for name in ['dive','dive-conformance']:copy_binary(target/'release'/name,name)
(out/'default-dependency-inputs.json').write_text(json.dumps({n:{'path':p,'sha256':sha(Path(p))} for n,p in artifacts.items()},indent=2)+'\n')

def rust_runner(name,original,transform=lambda s:s):
 text=transform(original.read_text());path=out/(name+'.rs');path.write_text(text)
 cmd=['rustc','--edition=2024',path,'-L','dependency='+str(target/'release/deps'),'-o',bins/name]
 for n in ['dive_api','dive_check','dive_liveness','dive_sema','dive_ir','dive_config','dive_trace','serde_json']:
  if n+'::' in text or 'use '+n in text:cmd+=['--extern',n+'='+artifacts[n]]
 run('compile-'+name,cmd);(out/(name+'-inputs.json')).write_text(json.dumps({'original_path':str(original.relative_to(root)),'original_sha256':sha(original),'adapted_sha256':sha(path),'producer':producer,'adaptation':'Explicit current source/output/fixture paths only; original selection and assertions retained. Default library artifacts above.'},indent=2)+'\n')
 executable=bins/name;executable.chmod(0o555);binary_inputs[executable]=sha(executable)
 return executable

candidate=rust_runner('candidate-runtime',root/'conformance/probes/producer-owned-candidate/gate-current/runtime-current/runtime-source.rs')
run('candidate-default-runtime',[candidate,out/'candidate-rows'])
rows=[json.loads(p.read_text()) for p in (out/'candidate-rows').glob('*.json')];assert len(rows)==27 and all(r['model_proof'] is False and r['ordinary_schedule_certified'] is False for r in rows)
assert sum('mutants' in r for r in rows)==12 and sum(len(r.get('mutants',[])) for r in rows)==48
control=root/'conformance/probes/fallible-invariant-replay/current/api-controls/src/main.rs'
def controls_source(s):
 return s.replace('/Users/jeff/code/dive-trace-representation-work',str(root)).replace('/Users/jeff/code/dive-storage-tuple-function-artifacts/seen-engine-current/api-controls/models',str(root/'conformance/probes/fallible-seen-engine/current/api-controls/models'))
independent=rust_runner('disk-independent-controls',control,controls_source)
p=run('disk-independent-witnesses',[independent]);d=json.loads(p.read_text());assert len(d['rows'])==144 and all(r['positive']=='valid' for r in d['rows']) and sum(len(r['mutants']) for r in d['rows'])==864 and all(m['validation']=='invalid' for r in d['rows'] for m in r['mutants'])

# Path-adapted original campaigns retain their immutable originals and all assertions.
def adapted_campaign(name,original,replacements):
 text=original.read_text()
 for old,new in replacements:assert old in text,old;text=text.replace(old,new)
 p=out/(name+'.py');p.write_text(text);(out/(name+'-input.json')).write_text(json.dumps({'original':str(original.relative_to(root)),'original_sha256':sha(original),'adapted_sha256':sha(p),'changes':'Producer/path identities only; original selection and assertions retained. Original producer remains separately archived.'},indent=2)+'\n')
 run(name,['python3','-I',p])

original=root/'conformance/probes/fallible-invariant-replay/current/runtime-original-selection.py'
adapted_campaign('disk-original-runtime',original,[('/Users/jeff/code/dive-trace-representation-work',str(root)),('/Users/jeff/code/dive-storage-tuple-function-artifacts/seen-engine-development',str(root/'conformance/probes/fallible-seen-engine/current')),('/Users/jeff/code/dive-storage-tuple-function-artifacts/seen-replay-current/runtime',str(out/'disk-original-rows')),("binroot=out.parent/'current-binaries'","binroot=out.parent/'bins'"),('881b75992d0ef5dc11539018da526e5e55066027',producer)])
d=json.loads((out/'disk-original-rows/receipt.json').read_text());assert len(d['rows'])==1024 and d['producer']==producer
original=root/'conformance/probes/fallible-invariant-replay/current/replay-runtime.py'
adapted_campaign('disk-positioned-replay',original,[('/Users/jeff/code/dive-trace-representation-work',str(root)),('/Users/jeff/code/dive-storage-tuple-function-artifacts/seen-replay-current/replay-runtime',str(out/'disk-replay-rows')),("cli=out.parent/'current-binaries/dive'","cli=out.parent/'bins/dive'"),('881b75992d0ef5dc11539018da526e5e55066027',producer)])
d=json.loads((out/'disk-replay-rows/receipt.json').read_text());assert len(d['rows'])==1040 and d['pure_disk_selected']==432 and d['print_refusal_selected']==504

for name,pkg,test,extra in [('request-service','dive-liveness','periodic_service',{'DIVE_REQUEST_SERVICE_CAPTURE':str(out/'request-service-rows')}),('candidate-request-authority','dive-api','periodic_candidate',{}),('fixed-projection','dive-trace','runtime_names',{}),('disk-fault-controls','dive-check','disk_seen',{})]:
 run(name,['cargo','test','--locked','-p',pkg,'--test',test,'--','--test-threads=2'],extra)
assert len(list((out/'request-service-rows').glob('*.json')))==52

examples=['request_owned_service','periodic_candidate','disk_seen_safety','disk_seen_replay','pluscal_source_context','pluscal_source_cst','pluscal_p_elsif_checksum','pluscal_multiple_procedure_checksum','tuple_only_replay','inductive_tuple_replay']
command=['cargo','build','--release','--locked','-p','dive-api']
for name in examples:command+=['--example',name]
run('release-guides',command)
for name in examples:copy_binary(target/'release/examples'/name,name)
for name in ['request_owned_service','periodic_candidate','disk_seen_safety','disk_seen_replay','tuple_only_replay','inductive_tuple_replay']:run('guide-'+name,[bins/name])
# Every raw AST, public validator, finite model and replay selected by each component.
cache=Path(env['DIVE_CACHE_DIR']);java=next(cache.glob('jre/*/*/Contents/Home/bin/java'));jar=cache/'sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar'
assert sha(jar)=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
reference=Path('/Users/jeff/code/dive-pluscal-definition-forms-artifacts');adapter=out/'reference-adapter';library=out/'reference-library';shutil.copytree(reference/'adapter',adapter);shutil.copytree(reference/'reference-library',library)
(out/'reference-inputs.json').write_text(json.dumps({'scope':'Copied primary adapter/library inputs, never represented as fresh native outputs','sha256':{str(p.relative_to(out)):sha(p) for parent in [adapter,library] for p in parent.rglob('*') if p.is_file()}},indent=2)+'\n')
for family,guide in [('p-elsif-checksum-acceptance','pluscal_p_elsif_checksum'),('multiple-procedure-checksum-acceptance','pluscal_multiple_procedure_checksum')]:
 base=root/'crates/dive-pluscal'/family;prefix=family.removesuffix('-checksum-acceptance')
 run(prefix+'-raw',['python3','-I',base/'compare.py','--base',base,'--binary',bins/'pluscal_source_context','--out',out/(prefix+'-raw')])
 run(prefix+'-public',['python3','-I',base/'public-controls.py','--base',base,'--binary',bins/'dive','--cst',bins/'pluscal_source_cst','--java',java,'--jar',jar,'--adapter',adapter,'--library',library,'--out',out/(prefix+'-public')])
 run(prefix+'-models',['python3','-I',base/'models.py','--base',base,'--native',bins/'dive','--java',java,'--jar',jar,'--out',out/(prefix+'-models')])
 run(prefix+'-replay',['python3','-I',base/'replay.py','--models',out/(prefix+'-models'),'--binary',bins/'dive','--out',out/(prefix+'-replay')])
 # CLI/Rust/Cargo user guide routes; aliases are explicit fresh compiled examples.
 familyruntime=out/(prefix+'-runtime');familyruntime.mkdir();guidebins=familyruntime/'bins';guidebins.mkdir()
 for src,alias in [('dive','dive'),('pluscal_source_cst','cst'),(guide,'elsif-guide' if prefix=='p-elsif' else 'multiple-guide')]:shutil.copy2(bins/src,guidebins/alias)
 run(prefix+'-guides',['python3','-I',base/'guides.py','--base',base,'--binaries',guidebins,'--out',familyruntime/'guides-final','--worktree',root,'--target',target])


 run(prefix+'-checksum-controls',['python3','-I',base/'checksum-controls.py','--base',base,'--binaries',guidebins,'--out',out/(prefix+'-checksum-controls'),'--java',java,'--jar',jar,'--adapter',adapter])
 run(prefix+'-forgery-controls',['python3','-I',base/'forgery-controls.py','--base',base,'--runtime',familyruntime,'--out',out/(prefix+'-forgery-controls'),'--java',java,'--jar',jar,'--adapter',adapter,'--library',library])
 if prefix=='multiple-procedure':
  for child in ['local-declaration-controls','ownership-negatives']:
   childbase=base/child
   run(prefix+'-'+child+'-raw',['python3','-I',base/'compare.py','--base',childbase,'--binary',bins/'pluscal_source_context','--out',out/(prefix+'-'+child+'-raw')])
   run(prefix+'-'+child+'-public',['python3','-I',base/'public-controls.py','--base',childbase,'--binary',bins/'dive','--cst',bins/'pluscal_source_cst','--java',java,'--jar',jar,'--adapter',adapter,'--library',library,'--out',out/(prefix+'-'+child+'-public')])

for corpus,listname in [('examples','cm1'),('validation-smoke','validation-smoke')]:
 selected=[s.split('#')[0].strip() for s in (root/'conformance/gates'/f'{listname}.txt').read_text().splitlines()];selected=[s for s in selected if s];assert len(selected)==(21 if corpus=='examples' else 16)
 cmd=[bins/'dive-conformance','run','--impl','dive','--impl-profile','tlc','--dive-bin',bins/'dive','--corpus',corpus,'--tier','all','--no-sany','--no-summary','--report-dir',out/(corpus+'-reports'),'--workers','1,4,8']
 for name in selected:cmd+=['--filter',name]
 run(corpus+'-gate',cmd)
 reportpaths=list((out/(corpus+'-reports')).glob('*.json'));assert len(reportpaths)==1;d=json.loads(reportpaths[0].read_text());assert d['summary']['models_selected']==d['summary']['models']['agree']==len(selected)
 for row in d['models']:assert row['outcome']=='agree' and all(r['outcome']=='agree' and not r['diffs'] for r in row['runs']) and {r['workers'] for r in row['runs']}=={1,4,8}
unchanged()
(out/'closure.json').write_text(json.dumps({'producer':producer,'source_index_sha256':sha(epoch/'source-index.json'),'all_consumers_closed':True,'family_certified':False,'binaries':{p.name:sha(p) for p in bins.iterdir()},'steps':steps},indent=2)+'\n');print('Combined fresh runtime closed',flush=True)
