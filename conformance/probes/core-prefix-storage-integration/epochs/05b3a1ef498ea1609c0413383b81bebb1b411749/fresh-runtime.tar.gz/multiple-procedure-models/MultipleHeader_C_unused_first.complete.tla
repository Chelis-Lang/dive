---- MODULE MultipleHeader_C_unused_first ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A { variable x=0; procedure Put(z=0,a=0) { P1:x:=a+z; P2:return; };procedure Get(q=0,b=0) { G1:x:=b+q; G2:return; }; { L:call Get(3,4); E:skip; } } *)
\* BEGIN TRANSLATION (chksum(pcal) = "61aae376" /\ chksum(tla) = "ebfb21a4")
VARIABLES pc, x, stack, z, a, q, b

vars == << pc, x, stack, z, a, q, b >>

Init == /\ x = 0
        /\ z = 0
        /\ a = 0
        /\ q = 0
        /\ b = 0
        /\ stack = << >>
        /\ pc = "L"

P1 == /\ pc = "P1"
      /\ x' = a + z
      /\ pc' = "P2"
      /\ UNCHANGED << stack, z, a, q, b >>

P2 == /\ pc = "P2"
      /\ pc' = Head(stack).pc
      /\ z' = Head(stack).z
      /\ a' = Head(stack).a
      /\ stack' = Tail(stack)
      /\ UNCHANGED << x, q, b >>

Put == P1 \/ P2

G1 == /\ pc = "G1"
      /\ x' = b + q
      /\ pc' = "G2"
      /\ UNCHANGED << stack, z, a, q, b >>

G2 == /\ pc = "G2"
      /\ pc' = Head(stack).pc
      /\ q' = Head(stack).q
      /\ b' = Head(stack).b
      /\ stack' = Tail(stack)
      /\ UNCHANGED << x, z, a >>

Get == G1 \/ G2

L == /\ pc = "L"
     /\ /\ b' = 4
        /\ q' = 3
        /\ stack' = << [ procedure |-> "Get", pc |-> "E", q |-> q, b |-> b ] >> \o stack
     /\ pc' = "G1"
     /\ UNCHANGED << x, z, a >>

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, z, a, q, b >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ Get \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 
====
