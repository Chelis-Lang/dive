---- MODULE MultipleHeader_P_no_calls ----
EXTENDS Integers, Sequences, TLC
(* --algorithm A variable x=0; procedure Put(z=0,a=0)  begin P1:x:=a+z; P2:return; end procedure;procedure Get(q=0,b=0)  begin G1:x:=b+q; G2:return; end procedure; begin L:skip; E:skip; end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "76e9135a" /\ chksum(tla) = "dee6d983")
VARIABLES pc, x, stack, z, a, q, b

vars == << pc, x, stack, z, a, q, b >>

Init == /\ x = 0
        /\ z = 0
        /\ a = 0
        /\ q = 0
        /\ b = 0
        /\ stack = << >>
        /\ pc = "L"

P1 == /\ pc = "P1"
      /\ x' = a + z
      /\ pc' = "P2"
      /\ UNCHANGED << stack, z, a, q, b >>

P2 == /\ pc = "P2"
      /\ pc' = Head(stack).pc
      /\ z' = Head(stack).z
      /\ a' = Head(stack).a
      /\ stack' = Tail(stack)
      /\ UNCHANGED << x, q, b >>

Put == P1 \/ P2

G1 == /\ pc = "G1"
      /\ x' = b + q
      /\ pc' = "G2"
      /\ UNCHANGED << stack, z, a, q, b >>

G2 == /\ pc = "G2"
      /\ pc' = Head(stack).pc
      /\ q' = Head(stack).q
      /\ b' = Head(stack).b
      /\ stack' = Tail(stack)
      /\ UNCHANGED << x, z, a >>

Get == G1 \/ G2

L == /\ pc = "L"
     /\ TRUE
     /\ pc' = "E"
     /\ UNCHANGED << x, stack, z, a, q, b >>

E == /\ pc = "E"
     /\ TRUE
     /\ pc' = "Done"
     /\ UNCHANGED << x, stack, z, a, q, b >>

Terminating == pc = "Done" /\ UNCHANGED vars

Next == Put \/ Get \/ L \/ E \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")
\* END TRANSLATION 

Good == pc # "Done"
====
