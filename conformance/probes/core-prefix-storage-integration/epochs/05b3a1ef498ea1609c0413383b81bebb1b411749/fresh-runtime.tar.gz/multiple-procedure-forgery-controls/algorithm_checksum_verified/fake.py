#!/usr/bin/env python3
import json,sys
from pathlib import Path
key=Path(sys.argv[2]).stem+"."+("tlc"if"--compat=tlc"in sys.argv else"dive");d=json.loads(Path(__file__).with_name("forged.json").read_text())[key];print(json.dumps(d));raise SystemExit(d["exit_code"])
