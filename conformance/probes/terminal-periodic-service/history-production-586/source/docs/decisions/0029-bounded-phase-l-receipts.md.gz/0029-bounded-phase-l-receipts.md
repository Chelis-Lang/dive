# 0029: Bounded concrete phase-L receipts

- **Status:** accepted
- **Date:** 2026-10-10

## Context

An edge's stored destination or generator order cannot reproduce TLC's liveness
predicate checks. Worker collects concrete incoming successors in `SetOfStates`,
including already seen states, appends stutter and checks bins in slot order.
Graph/tableau insertion can evaluate additional predicates between OOS groups.

## Decision

Add `dive_liveness::phase_l::Session` as a separate inline diagnostic stage.
Fresh bound planning privately retains pure scoped predicates and original
configured identities, separately from derived roles. The caller supplies
accepted concrete successors with increasing generator ordinals; the stage
never reconstructs Next or substitutes stored representatives. Admission,
constraint and safety-stop provenance is not certified by this interface.

Derive fingerprints internally in TLC variable order, with the requested pinned
polynomial. Require TLC value/comparison/exploration mode; refuse VIEW/symmetry
and lazy/infinite/opaque state values before invoking their callbacks. Enumerated
material sets/functions are preflighted recursively. Follow low-32-bit masked
buckets, linear probes, incoming-to-existing equality, first representatives,
grow-before-duplicate and old-slot reinsertion. Continue probing incomparable
material states, without swallowing other Rust errors. Forced keys exist only
in a separately named scalar structural diagnostic; they cannot enter a model
receipt or earn fingerprint evidence.

Maintain one logical multiplier history in source commit order: capacity starts
at `16 * multiplier` and the multiplier increments once after a successful
source if capacity grew. Failed growth retains the prior concrete prefix while
recording actual speculative work. Completed source counts do not advance on
failure. This first stage executes inline and reports actual workers one;
wider diagnostic requests are named refusals with zero executed workers.

For null-tableau OOS groups, evaluate all action bins in slot/bin order, then
source-state bins. `LNAction` bracket checks evaluate subscript values before
body; equal subscripts short-circuit nonstuttering/stuttering actions as TLC
does. The ordinary evaluator's `StepAngle` body-first contract is not changed.
Tableau initial particle consistency is a separate ordered diagnostic. Source
receipts containing a tableau retain collection then refuse bin execution:
dynamic consistency/revisitation is not yet implemented and can decide an error
before another OOS. Every receipt declares `graph_insertion=false`.

Bounds cover admission count, slot capacity, material visits, retained result
cells, collection/predicate-expression work, and recursion depth 256. Formula,
graph and successor defaults are not raised. These are entry/work bounds, not
aggregate byte accounting. Failure carries original errors, actual workers and
prefix counters plus the unfinished collection/bin receipt when available.

State-kind IF syntax reachable from a retained predicate is conservatively
refused. Pinned `astToLive` can evaluate constant branches while native planning
still retains the whole IF atom (#147). Preserve that prior disagreement; the
refusal gains no planning credit. Shared body-first `PredicateAtom` and independent
periodic semantics have separate correction work (#149).

## Consequences

The full selections retain 55 forced-key structural controls, 35 actual synthetic
`LiveCheck` callback controls, 51 bound-model rows and 20 clean TLC runs. Compiler
failures, initial adapter mistakes, invalid/corrected action/import controls and
before-fix native observations remain byte-exact historical evidence. Native
model fields are counted independently of refusals and graph-pending rows.

Independent trace validation rejects forged Next/closing edges and property
claims even when diagnostic receipts can be constructed. Neither receipt nor
successful bin projection is a model proof. Strict integrated liveness remains
refused; F-020/F-021/F-022 stay partial/audit-required and F-023 missing. #140
remains open. The next increment must attach concrete ordered receipts to graph/
product insertion and actual pool commits before SCC/lasso/scheduling work.

## Concrete graph increment

`phase_graph` connects a completed pure safety capture to actual persisted native
nodes for one null-tableau OOS. Capture now has a separate actual-pool entry with
bounded original concrete rows; the legacy inline capture is preserved. Source
commits retain one logical SetOfStates capacity history independent of requested
pool width. The graph projection retains original configured properties and
separate derived role names; it does not substitute one field for another.

Capture completes before temporal predicates run. Its statistics represent
observed capture work and are not an integrated TLC temporal stopping prefix.
Graph, bin and PEM-input bounds are checked before allocation/predicate execution;
per-level speculative per-source quotas are named conservative structural bounds.
Entry/work limits do not claim aggregate byte accounting. A graph result always
has `model_proof=false`; receipt and commit insertion flags remain distinct.

The complete fifteen-model pinned selection, synthetic collision control and
fifteen clean TLC outcomes are retained in `conformance/probes/tlc-phase-l-graph/`.
Multiple-OOS/tableau revisit ordering and strict SCC/lasso/schedule integration
must follow this increment. #140 remains open and F-020/F-021/F-022 partial,
F-023 missing. No default or integrated-liveness refusal is changed.

## Addendum: stored capture admission, 2026-10-11

The concrete pool capture proof admits callback-free stored string/model atoms,
functions (including tuples/records), and Enum/Raw sets after shared ownership,
role/scope and namespace admission. Expression and recursive material visits
share the original50,000-per-predicate/128-depth proof; keys/ranges both charge.
Configured OPEN dependence resolves through actual bound constants and scoped
contexts without changing static effect flags. Opaque/unknown/unbound leaves,
operator captures, cached/computed providers and effects remain refused before
workers. This does not alter phase-L graph/product bounds or scheduled semantics.
Clean paired final controls and independent witness mutations remain separate
from historical broad-corpus evidence; see `docs/material-capture.md`.

Supplied stored Enum/Raw sets, records and general functions must carry the
admitted evaluator's ordering profile. Correct interner ownership alone cannot
repair a cached canonical sequence used by TLC-mode CHOOSE. Tuple domains are
ascending integer indices and exempt only at their outer representation. The
pre-guard positive matrix and interrupted gate remain development evidence;
opposite-profile public controls now refuse before workers or counters.

## Addendum: pure user operator formals, 2026-10-11

The captured-operator refusal is narrowed only for admitted known nonrecursive
user targets with ordinary value formals. A callback-free analysis scope binds
those formals to non-forcible AnalysisBound slots and preserves original lexical
parents and dynamic substitutions. Planner, independent Word and capture/finite
proofs inspect supplied targets even when unused; execution always uses actual
arguments through scope_apply_param. Native effects/runtime names are inspected
authoritatively rather than accepted from erased summary annotations.

The original resource ceilings and material ordering/context rules remain. A
configured operator's erased origin is not guessed: every ConstBinding::Def
target also refuses when passed explicitly. Native/builtin, higher-order target,
recursive, overridden and unknown callbacks still refuse. Clean accepted exported
operator-formal INSTANCE cases and previous temporal-expression2213 cases remain
distinct. Diagnostic null-liveness helper failures retain no field/error credit.
See `docs/temporal-operators.md` and the source-bound paired controls; no new
ordinary scheduling, family, corpus or aggregate-memory claim is made.

## Native actual addendum (2026-10-11)

The retained native actual slice admits only authoritative Len/Head/Cardinality
with pure constant/state arguments. Planner and independent Word prove the
original scopes separately; runtime stored-input admission refuses deferred
callbacks and invalid namespaces/order under fixed50k/128 structural bounds.
No ordinary schedule, default, graph-memory guarantee or family certification
is implied. See `docs/native-temporal-operators.md`.

## Addendum 2026-10-11: callback-free stored successor values

Accept authoritative Set.stored_elements (Enum/Raw, even normalized) and stored
Fcn entries, retaining cumulative 8m/depth 256 Session accounting. Validate model
context, string/model namespace and non-tuple storage order before fingerprint or
comparison. Cached Deferred providers remain refused; no extra 50k global state
walk is added. Context/native 50k/128 stays separate. See the stored-state user
guide and complete paired before/after evidence; no ordinary schedule or family
certification follows from this bounded representation change.

## Addendum 2026-10-11: fixed-arity native Append forwarding

Admit only authoritative `Append` in addition to the prior three unary native
actuals, preserving the existing argument list and exact Java arity (two). Both
operands retain independent scoped purity, owner/order/representation and finite
bounds before evaluation. Tail/SubSeq keep their runtime-name flags and pre-bind
refusals until callback-free tuple authority is proved before all affected
evaluation. No default, schedule, integer, namespace or resource ceiling changes.
