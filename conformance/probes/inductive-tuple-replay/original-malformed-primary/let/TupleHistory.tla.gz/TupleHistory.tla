---- MODULE TupleHistory ----
EXTENDS Naturals, Sequences, TLC
VARIABLES x,s
Drop(v) == LET Pair == v IN Tail(Pair)
Init == x=0 /\ s=<<0,1>>
Next == x'=1 /\ s'=Drop(s)
Inv == x=0
====
