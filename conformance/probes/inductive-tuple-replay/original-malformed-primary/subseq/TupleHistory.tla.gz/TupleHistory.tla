---- MODULE TupleHistory ----
EXTENDS Naturals, Sequences, TLC
VARIABLES x,s

Init == x=0 /\ s=<<0,1>>
Next == x'=1 /\ s'=SubSeq(s,2,2)
Inv == x=0
====
