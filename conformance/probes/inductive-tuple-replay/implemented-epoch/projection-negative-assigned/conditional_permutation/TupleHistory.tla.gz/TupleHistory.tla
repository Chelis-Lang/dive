---- MODULE TupleHistory ----
EXTENDS Naturals, Sequences, TLC
VARIABLES x,s,t
vars == IF x=1 THEN <<s,t>> ELSE <<t,s>>
Init == x=0 /\ s = <<0,1>> /\ t="text"
Next == (x=0 /\ x'=1 /\ s'=Tail(s) /\ t'=t) \/ (x=1 /\ x'=2 /\ s'=t /\ t'=s /\ UNCHANGED vars)
Inv == x<2
====
