from pathlib import Path
import subprocess,json,hashlib,gzip,os,time
root=Path.cwd();out=Path('/tmp/dive-inductive-tuple-corrected-frozen-source');out.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
base=json.loads(Path('/tmp/dive-core-definition-forms-frozen-source/source.json').read_text())
paths=set(base['source_sha256'])
paths.update(str(p.relative_to(root)) for top in ['crates','xtask','scripts','docs'] for p in (root/top).rglob('*') if p.is_file() and p.suffix in ('.rs','.toml','.py','.sh','.md'))
for probe in ['stored-successor-material','native-sequence-operators','configured-random-stream','tlc-partial-scc','runtime-ratio','ordinary-periodic-work','view-concrete-normalization','periodic-backend']:
 p=root/'conformance/probes'/probe;paths.update(str(f.relative_to(root)) for f in p.rglob('*') if f.is_file() and f.suffix in ('.tla','.cfg','.py','.java','.md'))
for probe in ['tlc-partial-scc','runtime-ratio','ordinary-periodic-work','view-concrete-normalization','periodic-backend']:
 paths.update(str(f.relative_to(root)) for f in (root/'conformance/probes'/probe).rglob('*') if f.is_file())
paths.update(str(f.relative_to(root)) for f in (root/'crates/dive-pluscal/macro-checksum-acceptance').rglob('*') if f.is_file())
for probe in ['native-periodic-lifecycle','view-random-stream','periodic-hook','periodic-snapshot','trace-representation-v2','tuple-only-replay','inductive-tuple-replay']:
 paths.update(str(f.relative_to(root)) for f in (root/'conformance/probes'/probe).rglob('*') if f.is_file())
paths.update(str(f.relative_to(root)) for f in (root/'crates/dive-pluscal/define-acceptance').rglob('*') if f.is_file())
paths.update(str(f.relative_to(root)) for f in (root/'crates/dive-pluscal/define-forms-acceptance').rglob('*') if f.is_file())
current=json.loads((root/'conformance/probes/native-parity-integration/current-source.json').read_text());generated=set(current['generated_manifest_paths']);paths-=generated
tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines());assert paths<=tracked,sorted(paths-tracked)
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);hashes={}
for rel in sorted(paths):
 data=(root/rel).read_bytes();proc.stdin.write((rev+':'+rel+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().split();assert head[1]==b'blob';saved=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n';assert saved==data,rel
 target=out/'source'/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));hashes[rel]=sha(data)
proc.stdin.close();assert proc.wait()==0
integrity={}
for rel in sorted(generated):
 p=root/rel;data=p.read_bytes();integrity[rel]=sha(data);target=out/'integrity'/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0))
for name,doc in [('native_temporal_operator','docs/native-temporal-operators.md'),('stored_successor_material','docs/stored-successor-material.md'),('native_sequence_operator','docs/native-sequence-operators.md'),('partial_temporal_checks','docs/partial-temporal-checks.md'),('periodic_controller','docs/ordinary-periodic-controller.md'),('periodic_lifecycle','docs/native-periodic-lifecycle.md')]:
 code=(root/'crates/dive-api/examples'/f'{name}.rs').read_text().split('\n',1)[1].rstrip();assert '```rust\n'+code+'\n```' in (root/doc).read_text(),name
assert '(../crates/dive-api/examples/periodic_backend.rs)' in (root/'docs/periodic-backend.md').read_text()
source={'source_commit':rev,'source_tree':tree,'source_sha256':hashes,'integrity_output_sha256':integrity,'scope':'Current combined stored successor, native Append, ordinary random-stream authority, partial SCC/periodic backend diagnostics, concrete VIEW normalization, bounded VIEW-backed RandomElement and native periodic lifecycle with bounded macro checksum/algorithm marker repair, supplied pure hook diagnostics, configuration-owned snapshot diagnostics, bounded representation-v2 transport and bounded global, LOCAL and function DEFINE translation. Portable original DEFINE records and committed test readback remain separate from their original runtime source gap. Archived producer observations remain separate; no family/ordinary scheduling certification.','family_certified':False,'new_scope':'Sealed bounded Init/all-branches Next tuple-history proof for whole-word replay; arbitrary-state APIs and unknown runtime-name histories remain refused.'}
(out/'source.json').write_text(json.dumps(source,indent=2)+'\n');print('Frozen '+str(len(hashes))+' Git-paired input files at '+rev,flush=True)

checks=[r['command'] for r in json.loads(Path('/tmp/dive-core-snapshot-trace-offline-v2-checks.json').read_text())['steps']]+[['python3','-I','scripts/check-tuple-only-replay.py'],['python3','-I','scripts/check-inductive-tuple-replay.py']]
preflight=[]
for i,command in enumerate(checks):
 path=Path('/tmp/dive-inductive-tuple-corrected-offline-'+str(i)+'.log');start=time.monotonic()
 with path.open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 preflight.append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log':str(path),'sha256':sha(path.read_bytes())});Path('/tmp/dive-inductive-tuple-corrected-offline.json').write_text(json.dumps({'steps':preflight},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print(str(len(preflight))+' offline guards passed',flush=True)
commands=[['cargo','fmt','--all','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','nextest','run','--workspace','--locked','--profile','ci','--test-threads','2'],['cargo','test','--workspace','--doc','--locked'],['cargo','doc','--workspace','--no-deps','--locked'],['cargo','xtask','check-layering'],['cargo','build','-p','dive-trace','--locked'],['cargo','deny','--locked','check']]
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-tuple-only-replay-cache'}
steps=[]
with Path('/tmp/dive-inductive-tuple-corrected-gate-driver.log').open('w') as log:
 for i,command in enumerate(commands):
  for rel,h in hashes.items():assert sha((root/rel).read_bytes())==h,rel
  for rel,h in integrity.items():assert sha((root/rel).read_bytes())==h,rel
  step_env={**env,'RUSTDOCFLAGS':'-D warnings'} if i==4 else env
  path=Path(f'/tmp/dive-inductive-tuple-corrected-gate-{i}.log');start=time.monotonic();log.write('RUN '+' '.join(command)+'\n');log.flush()
  with path.open('w') as output:r=subprocess.run(command,env=step_env,stdout=output,stderr=subprocess.STDOUT)
  row={'command':command,'exit':r.returncode,'log':str(path),'log_sha256':sha(path.read_bytes()),'seconds':time.monotonic()-start};steps.append(row);Path('/tmp/dive-inductive-tuple-corrected-gate-steps.json').write_text(json.dumps(steps,indent=2)+'\n');log.write(f'RESULT {r.returncode} {path}\n');log.flush();print('Stage '+str(i)+' exit '+str(r.returncode),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
for rel,h in hashes.items():assert sha((root/rel).read_bytes())==h,rel
print('All8 current gate stages closed with unchanged source',flush=True)
