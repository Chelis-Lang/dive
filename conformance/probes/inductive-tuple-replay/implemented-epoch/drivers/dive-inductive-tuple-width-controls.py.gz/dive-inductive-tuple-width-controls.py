from pathlib import Path
import argparse,ast,copy,hashlib,json,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--producer',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();producer=json.loads(a.producer.read_bytes());assert sha(a.binary.read_bytes())==producer['binary_sha256']['dive']
module=ast.parse(Path('/tmp/dive-inductive-tuple-fresh-runtime.py').read_text());cases=ast.literal_eval(next(n.value for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases'for t in n.targets)));assert len(cases)==12
rows=[]
def run(label,args,folder):
 start=time.monotonic();result=subprocess.run([str(x)for x in args],cwd=folder,capture_output=True,timeout=60)
 for suffix,body in [('stdout',result.stdout),('stderr',result.stderr)]: (folder/(label+'.'+suffix)).write_bytes(body)
 rows.append({'label':label,'command':[str(x)for x in args],'exit':result.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)})
 (a.out/'steps.json').write_text(json.dumps({'producer':producer,'selected_cases':12,'rows':rows},indent=2)+'\n');return result,json.loads(result.stdout)
checks=0;replays=[]
for name,defs,init,next_,config in cases:
 folder=a.out/name;folder.mkdir();source=folder/'TupleHistory.tla';cfg=folder/'TupleHistory.cfg'
 source.write_text(f'---- MODULE TupleHistory ----\nEXTENDS Naturals, Sequences, TLC\nVARIABLES x,s\n{defs}\nInit == x=0 /\\ s = {init}\nNext == {next_}\nInv == x=0\n====\n');cfg.write_text('INIT Init\nNEXT Next\nINVARIANT Inv\n'+config)
 for profile in ['tlc','dive']:
  for width in [1,4,8]:
   for store in ['fp','exact']:
    for chaos in [0,13]:
     label=f'{name}-{profile}-{width}-{store}-{chaos}'
     command=[a.binary,'check',source,'--seed','0','--fp','0','--workers',str(width),'--store',store,'--chaos',str(chaos),'--trace-format','representation-v2','--output','json']+(['--compat=tlc']if profile=='tlc'else [])
     checked,doc=run(label+'-check',command,folder);checks+=1
     if name=='unconstrained_next':
      assert checked.returncode==(75 if profile=='tlc'else 13),(label,checked.returncode,doc)
      assert doc['verdict']=='incomplete-state' and doc['counterexample']['trace'] is None and doc['tlc']['code']==2109,(label,doc)
      continue
     assert checked.returncode==(12 if profile=='tlc'else 10),(label,checked.returncode,doc)
     assert doc['verdict']=='invariant-violation' and doc['property']=='Inv',label
     assert all(doc['statistics'][k]==2for k in ['generated','distinct','depth']),label
     assert doc['counterexample']['trace']['states'][1]['values']['x']==1,label
     for kind in ['original','mutant']:
      word=copy.deepcopy(doc)
      if kind=='mutant':word['counterexample']['trace']['states'][1]['values']['x']=99
      trace=folder/(label+'-'+kind+'.json');trace.write_text(json.dumps(word)+'\n')
      command=[a.binary,'validate-trace',source,'--trace',trace,'--seed','0','--fp','0','--output','json']+(['--compat=tlc']if profile=='tlc'else [])
      replay,out=run(label+'-'+kind,command,folder)
      expected=('unsupported'if profile=='tlc'and name in ['off_path_string','off_path_constructor','string_init']else ('valid'if kind=='original'else 'invalid'))
      assert out['result']==expected and replay.returncode=={'valid':0,'invalid':1,'unsupported':3}[expected],(label,kind,out)
      replays.append({'model':name,'profile':profile,'workers':width,'store':store,'chaos':chaos,'kind':kind,'result':out['result']})
 print(name,'width controls closed',flush=True)
assert checks==288 and len(replays)==528 and len(rows)==816
(a.out/'replays.json').write_text(json.dumps({'rows':replays,'family_certified':False},indent=2)+'\n')
(a.out/'closure.json').write_text(json.dumps({'producer':producer,'all_consumers_closed':True,'model_checks':checks,'replay_checks':len(replays),'selected_cases':12,'family_certified':False},indent=2)+'\n')
