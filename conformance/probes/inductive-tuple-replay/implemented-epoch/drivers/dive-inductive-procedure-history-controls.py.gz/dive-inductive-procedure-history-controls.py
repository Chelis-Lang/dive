from pathlib import Path
import argparse,copy,gzip,hashlib,json,shutil,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--producer',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False)
source=Path('/Users/jeff/code/dive-pluscal-nested-procedure-checksum-artifacts/native-final/models');old=json.loads((source/'report.json').read_bytes());selected=[r for r in old['rows']if r['id'].endswith('.violation')];assert len(selected)==32
producer=json.loads(a.producer.read_bytes());sha=lambda data:hashlib.sha256(data).hexdigest();assert sha(a.binary.read_bytes())==producer['binary_sha256']['dive'];steps=[];outcomes=[]
def run(label,command,folder):
 start=time.monotonic();result=subprocess.run([str(x)for x in command],cwd=folder,capture_output=True,timeout=60)
 for suffix,body in [('stdout',result.stdout),('stderr',result.stderr)]: (folder/(label+'.'+suffix)).write_bytes(body)
 steps.append({'label':label,'command':[str(x)for x in command],'exit':result.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)});(a.out/'steps.json').write_text(json.dumps({'producer':producer,'rows':steps},indent=2)+'\n');return result,json.loads(result.stdout)
for row in selected:
 name=row['id'];folder=a.out/name;folder.mkdir();tla=folder/(name+'.tla');cfg=folder/(name+'.cfg')
 for dest in [tla,cfg]:shutil.copy2(source/dest.name,dest)
 primary_stream=gzip.decompress((source/row['primary']['stdout']['path']).read_bytes());assert sha(primary_stream)==row['primary']['stdout']['sha256'];(folder/'original-primary.stdout').write_bytes(primary_stream)
 for profile in ['tlc','dive']:
  command=[a.binary,'check',tla,'--config',cfg,'--seed','0','--fp','0','--workers','1','--store','exact','--trace-format','representation-v2','--output','json']+(['--compat=tlc']if profile=='tlc'else [])
  checked,doc=run(profile+'-check',command,folder);assert checked.returncode==(12 if profile=='tlc'else 10) and doc['verdict']=='invariant-violation' and doc['property']=='Good',(name,profile,doc)
  assert all(doc['statistics'][k]==v for k,v in row['primary_counts'].items()),(name,profile,doc['statistics'])
  for kind in ['original','mutant']:
   word=copy.deepcopy(doc)
   if kind=='mutant':word['counterexample']['trace']['states'][-1]['values']['x']=999
   trace=folder/(profile+'-'+kind+'.json');trace.write_text(json.dumps(word)+'\n')
   command=[a.binary,'validate-trace',tla,'--config',cfg,'--trace',trace,'--seed','0','--fp','0','--output','json']+(['--compat=tlc']if profile=='tlc'else [])
   replay,answer=run(profile+'-'+kind,command,folder)
   if profile=='dive':assert answer['result']==('valid'if kind=='original'else 'invalid'),(name,kind,answer)
   elif kind=='original':assert answer['result']in ['valid','unsupported'],(name,answer)
   else:assert answer['result']in ['invalid','unsupported'],(name,answer)
   assert replay.returncode=={'valid':0,'invalid':1,'unsupported':3}[answer['result']]
   outcomes.append({'model':name,'profile':profile,'control':kind,'result':answer['result'],'unsupported':answer.get('unsupported')})
 print(name,'actual receiving check/replay closed',flush=True)
assert len(steps)==192 and len(outcomes)==128
(a.out/'report.json').write_text(json.dumps({'producer':producer,'selected':32,'checks':64,'replay_controls':128,'rows':outcomes,'family_certified':False,'qualification':'Fresh receiving binaries check original previously pinned generated TLA byte sources. No new source generation, raw checksum, arbitrary procedure-stack or whole-family certification.'},indent=2)+'\n')
(a.out/'closure.json').write_text(json.dumps({'producer':producer,'all_consumers_closed':True,'steps':192,'family_certified':False},indent=2)+'\n')
