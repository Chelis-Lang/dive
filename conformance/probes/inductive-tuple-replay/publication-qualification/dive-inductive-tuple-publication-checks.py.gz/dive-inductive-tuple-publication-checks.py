from pathlib import Path
import json,hashlib,subprocess,os,time
root=Path.cwd();frozen=json.loads(Path('/tmp/dive-inductive-tuple-corrected-frozen-source/source.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[r for r,h in frozen['source_sha256'].items() if sha((root/r).read_bytes())!=h]
assert all(not r.endswith(('.rs','.toml')) and r!='Cargo.lock' for r in changed),changed
commands=[s['command'] for s in json.loads(Path('/tmp/dive-inductive-tuple-corrected-offline.json').read_text())['steps']]+[['cargo','fmt','--all','--check']]
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0'}
steps=[]
for i,cmd in enumerate(commands):
 p=Path(f'/tmp/dive-inductive-tuple-publication-check-{i}.log');start=time.monotonic()
 with p.open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 steps.append({'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'sha256':sha(p.read_bytes()),'log':str(p)})
 Path('/tmp/dive-inductive-tuple-publication-checks.json').write_text(json.dumps({'runtime_source':frozen['source_commit'],'publication_changed_frozen_source_paths':changed,'production_source_unchanged':True,'steps':steps},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print('All43 publication integrity checks and fmt passed; compilation inputs unchanged')
