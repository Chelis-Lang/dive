from pathlib import Path
import json,gzip,hashlib,runpy,contextlib,io
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');base=root/'conformance/probes/inductive-tuple-replay/implemented-epoch'
original=Path.read_bytes
rows=[]
for case,label,wrong in [('alias','tlc-original','invalid'),('string_init','tlc-original','valid')]:
 overrides={};index=json.loads(original(base/'index.json'))
 def put(rel,data):
  blob=gzip.compress(data,mtime=0);overrides[base/(rel+'.gz')]=blob;index['files_sha256'][rel+'.gz']=hashlib.sha256(blob).hexdigest()
 def get(rel):return gzip.decompress(original(base/(rel+'.gz')))
 rel=f'runtime/{case}/{label}.stdout';doc=json.loads(get(rel));doc['result']=wrong;data=(json.dumps(doc)+'\n').encode();put(rel,data)
 records=json.loads(get('runtime/rows.json'))
 selected=next(r for r in records['rows'] if r['case']==case and r['label']==label)
 selected['stdout_sha256']=hashlib.sha256(data).hexdigest();selected['exit']=0 if wrong=='valid' else 1
 put('runtime/rows.json',(json.dumps(records)+'\n').encode())
 overrides[base/'index.json']=(json.dumps(index)+'\n').encode()
 def read(path):return overrides[path] if path in overrides else original(path)
 log=io.StringIO();failure=None
 Path.read_bytes=read
 try:
  with contextlib.redirect_stdout(log):runpy.run_path(str(root/'scripts/check-inductive-tuple-replay.py'))
 except AssertionError as exc:failure=str(exc)
 finally:Path.read_bytes=original
 assert failure is not None,(case,'promoted inconsistent result accepted')
 rows.append({'case':case,'label':label,'mutation':wrong,'archive_and_stream_hashes_refreshed':True,'rejected':True,'stdout':log.getvalue()})
Path('/tmp/dive-inductive-tuple-publication-mutations.json').write_text(json.dumps({'scope':'virtual altered result+record+index; original archive/source untouched','rows':rows},indent=2)+'\n')
print('Both false-result promotions rejected with refreshed transport hashes')
