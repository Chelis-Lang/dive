from pathlib import Path
import json,subprocess,hashlib,time,copy
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');out=Path('/tmp/dive-inductive-tuple-fresh-runtime');out.mkdir(exist_ok=False)
binary=Path('/tmp/dive-inductive-tuple-fresh-binaries/dive');producer=json.loads(Path('/tmp/dive-inductive-tuple-fresh-binaries/producer.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(binary)==producer['binary_sha256']['dive']
cache=Path('/Users/jeff/code/dive-shipping-cache');java=cache/'jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java';jar=cache/'sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar';assert sha(jar)=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
cases=[
 ('tail','','<<0,1>>',"x'=1 /\\ s'=Tail(s)",''),
 ('wrapper','Drop(v) == Tail(v)','<<0,1>>',"x'=1 /\\ s'=Drop(s)",''),
 ('alias','CONSTANT Drop(_)','<<0,1>>',"x'=1 /\\ s'=Drop(s)",'CONSTANT Drop <- Tail\n'),
 ('conditional','','<<0,1>>',"x'=1 /\\ s'=IF x=0 THEN Tail(s) ELSE <<2>>",''),
 ('concat','','<<0,1>>',"x'=1 /\\ s'=Tail(<<9>> \\o s)",''),
 ('subseq','','<<0,1>>',"x'=1 /\\ s'=SubSeq(s,2,2)",''),
 ('unchanged_branch','','<<0,1>>',"(x=0 /\\ x'=1 /\\ s'=Tail(s)) \\/ (x#0 /\\ x'=x /\\ UNCHANGED s)",''),
 ('let','Drop(v) == LET Pair == v IN Tail(Pair)','<<0,1>>',"x'=1 /\\ s'=Drop(s)",''),
 ('off_path_string','','<<0,1>>',"x'=1 /\\ s'=IF x=0 THEN Tail(s) ELSE \"b\"",''),
 ('off_path_constructor','','<<0,1>>',"x'=1 /\\ s'=IF x=0 THEN Tail(s) ELSE <<ToString(x)>>",''),
 ('string_init','','\"ab\"',"x'=1 /\\ s'=Tail(s)",''),
 ('unconstrained_next','','<<0,1>>',"x'=1",''),
]
rows=[]
def run(case,label,cmd,folder):
 start=time.monotonic();r=subprocess.run([str(x) for x in cmd],cwd=folder,capture_output=True,timeout=30)
 for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]: (folder/(label+'.'+suffix)).write_bytes(data)
 row={'case':case,'label':label,'command':[str(x) for x in cmd],'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};rows.append(row);(out/'rows.json').write_text(json.dumps({'native_producer':producer,'rows':rows},indent=2)+'\n');return r
for name,defs,init,next_,config in cases:
 folder=out/name;folder.mkdir();source=folder/'TupleHistory.tla';cfg=folder/'TupleHistory.cfg';source.write_text(f'---- MODULE TupleHistory ----\nEXTENDS Naturals, Sequences, TLC\nVARIABLES x,s\n{defs}\nInit == x=0 /\\ s = {init}\nNext == {next_}\nInv == x=0\n====\n');cfg.write_text('INIT Init\nNEXT Next\nINVARIANT Inv\n'+config)
 primary=run(name,'primary',[java,'-Xmx256m','-cp',jar,'tlc2.TLC','-tool','-workers','1','-seed','0','-fp','0','-cleanup','-metadir',folder/'meta',source],folder)
 checked=run(name,'native-check',[binary,'check',source,'--compat=tlc','--seed','0','--fp','0','--trace-format','representation-v2','--output','json'],folder);doc=json.loads(checked.stdout)
 if doc.get('counterexample') and doc['counterexample'].get('trace'):
  word=copy.deepcopy(doc)
  for kind in ['original','mutant']:
   altered=copy.deepcopy(word)
   if kind=='mutant':altered['counterexample']['trace']['states'][1]['values']['x']=99
   trace=folder/(kind+'.json');trace.write_text(json.dumps(altered)+'\n')
   for profile in ['tlc','dive']:
    result=run(name,profile+'-'+kind,[binary,'validate-trace',source,'--trace',trace,'--seed','0','--fp','0','--output','json',*(['--compat=tlc'] if profile=='tlc' else [])],folder)
    doc_result=json.loads(result.stdout)
    expected=('unsupported' if profile=='tlc' and name in ['off_path_string','off_path_constructor','string_init'] else ('valid' if kind=='original' else 'invalid'))
    assert doc_result['result']==expected,(name,profile,kind,doc_result)
    assert result.returncode=={'valid':0,'invalid':1,'unsupported':3}[expected]
 print(name,'primary',primary.returncode,'native',checked.returncode,flush=True)
assert len(cases)==12
(out/'closure.json').write_text(json.dumps({'all_consumers_closed':True,'implementation_changed':False,'producer':producer,'selected_cases':len(cases),'consumer_count':len(rows),'oracle_sha256':sha(jar),'family_certified':False},indent=2)+'\n');print('Primary and new tuple-history implementation observations CLOSED',flush=True)
