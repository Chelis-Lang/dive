"""Fresh native API replacement, whole CST, SANY and configured Validator controls."""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,re,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--cst',type=Path,required=True);p.add_argument('--java',required=True);p.add_argument('--jar',required=True);p.add_argument('--adapter',required=True);p.add_argument('--comparison',default='stage-separated');p.add_argument('--out',default='public');a=p.parse_args();base=Path(__file__).resolve().parent;out=base/a.out;out.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def execute(argv):return subprocess.run(list(map(str,argv)),capture_output=True,timeout=30)
def java(args):return execute([a.java,'-cp',a.adapter+':'+a.jar,*args])
def save(ident,stem,q):
 for stream in ['stdout','stderr']:(out/(ident+'.'+stem+'.'+stream+'.gz')).write_bytes(gzip.compress(getattr(q,stream),mtime=0))
 return {'exit_code':q.returncode,'stdout_sha256':sha(q.stdout),'stderr_sha256':sha(q.stderr)}
def validation(path,flags):
 q=java(['pcal.OptionValidatorProbe',*flags,path]);match=re.search(rb'VALIDATION\t([^\r\n]*)',q.stdout);assert q.returncode==0 and match,q.stdout
 return q,match[1].decode()
assert sha(Path(a.jar).read_bytes())=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
comparison=json.loads((base/a.comparison/'report.json').read_text());rows=[]
selected=comparison['rows']
for row in selected:
 ident=row['id'];profile=ident.rsplit('_',1)[1];sourceid=ident.rsplit('_',1)[0];folder=base/row['folder'];manifest=json.loads((folder/'manifest.json').read_text());primary=next(r for r in manifest['rows']if r['id']==sourceid);source=folder/(sourceid+'.tla');fairness='strong'if primary['flags']==['-sf']else'declared'
 with tempfile.TemporaryDirectory(prefix='dive-source-options-native-admission-')as nativework:
  inputpath=Path(nativework)/(sourceid.replace('-','_')+'.tla');inputpath.write_bytes(source.read_bytes())
  q=execute([a.binary,inputpath,'rewrite',fairness,profile])
 meta=save(ident,'native',q)
 try:
  assert q.returncode==0;doc=json.loads(q.stdout);assert doc['model_proved']is False and doc['exhaustive']is False and doc['exit_code']in [0,1,3]
  if row['outcome']in ['named-refusal','rejection-accounted','named-selection-refusal'] or primary['name']in ['translation-block','cr-only']:
   assert not doc['accepted']and doc['result']in ['unsupported','rejected']and'replacement'not in doc
   outcome='named-public-refusal'if doc['result']=='unsupported'else'rejection-accounted';rows.append({'id':ident,'outcome':outcome,'native':meta});continue
  if row['outcome']=='primary-invalid-raw-serialization':
   assert not doc['accepted']and doc['result']=='rejected'and'replacement'not in doc
   primarysany=java(['tla2sany.SANY','-error-codes',folder/(sourceid+'.translated.tla')]);save(ident,'invalid-primary-sany',primarysany);assert primarysany.returncode!=0
   rows.append({'id':ident,'outcome':'invalid-primary-uncredited','native':meta});continue
  if primary['name']in ['translation-block','cr-only']:
   assert not doc['accepted']and doc['result']=='unsupported'and'replacement'not in doc;outcome='named-public-refusal';rows.append({'id':ident,'outcome':outcome,'native':meta});continue
  assert doc['accepted']and doc['result']=='replacement'and doc['exit_code']==0 and doc['algorithm_checksum_verified']is True and doc['body_checksum_verified']is True
  plan=doc['replacement'];assert plan['algorithm_checksum']['serialized_ast']==(folder/(sourceid+'.translated.ast')).read_text();assert plan['algorithm_checksum']['checksum']==primary['header'][0]
  assert doc['translation_options']==doc['option_context']['effective'];assert doc['requested_translation_options']==doc['option_context']['requested']
  # Old-body edits/source context and complete module admission remain separate.
  native=plan['module_source'];(out/(ident+'.tla')).write_text(native)
  with tempfile.TemporaryDirectory(prefix='dive-source-context-public-')as tmp:
   path=Path(tmp)/(sourceid.replace('-','_')+'.tla');path.write_text(native)
   sany=java(['tla2sany.SANY','-error-codes',path]);save(ident,'native-sany',sany);assert sany.returncode==0 and b'Semantic errors:'not in sany.stdout
   reference=Path(tmp)/('primary/'+path.name);reference.parent.mkdir();reference.write_bytes((folder/(sourceid+'.translated.tla')).read_bytes())
   primarysany=java(['tla2sany.SANY','-error-codes',reference]);save(ident,'primary-sany',primarysany);assert primarysany.returncode==0 and b'Semantic errors:'not in primarysany.stdout
   l=execute([a.cst,path]);r=execute([a.cst,reference]);save(ident,'native-cst',l);save(ident,'primary-cst',r);left=json.loads(l.stdout);right=json.loads(r.stdout);assert l.returncode==r.returncode==0 and left['accepted']and right['accepted']and left['tree']==right['tree']
   statuses={}
   for config,flags in [('configured',primary['flags']),('unconfigured',[])]:
    nv,ns=validation(path,flags);pv,ps=validation(reference,flags);save(ident,'native-'+config,nv);save(ident,'primary-'+config,pv);assert ns==ps,(ns,ps);statuses[config]=ns
   assert 'NO_DIVERGENCE'in statuses['configured']
  outcome='admitted-exact-cst-sany-validator';rows.append({'id':ident,'outcome':outcome,'native':meta,'validator':statuses})
 except (AssertionError,KeyError,ValueError,TypeError)as err:print(ident,repr(err),flush=True);rows.append({'id':ident,'outcome':'disagree','native':meta})
 if len(rows)%20==0:print('public',len(rows),flush=True)
report={'schema_version':1,'script_sha256':sha(Path(__file__).read_bytes()),'binary_sha256':sha(a.binary.read_bytes()),'cst_sha256':sha(a.cst.read_bytes()),'comparison_sha256':sha((base/a.comparison/'report.json').read_bytes()),'selected':len(rows),'family_certified':False,'model_proved':False,'summary':dict(collections.Counter(r['outcome']for r in rows)),'rows':rows};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['summary']);raise SystemExit(bool(report['summary'].get('disagree')))
