---- MODULE TupleHistory ----
EXTENDS Naturals, Sequences, TLC
VARIABLES x,s
Drop(v) == Tail(v)
Init == x=0 /\ s = <<0,1>>
Next == x'=1 /\ s'=Drop(s)
Inv == x=0
====
