---- MODULE Periodic ----
EXTENDS Naturals,TLC
VARIABLE x
Init == x=0
Next == x'=1-x
Live == []<>(x=1)
Hook == PrintT("DIVE_PERIODIC") /\ FALSE
====
