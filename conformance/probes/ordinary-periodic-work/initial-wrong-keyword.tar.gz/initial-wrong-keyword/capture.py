from pathlib import Path
import subprocess,json,hashlib,itertools,time
base=Path(__file__).resolve().parent;classes=base/'classes';classes.mkdir(exist_ok=False)
java=Path('/Users/jeff/code/dive-shipping-cache/jre/190480874ccceb358cbc840393207f77ac3e63a4c5f8129d0e23e9518b96ad05/jdk-17.0.20.1+1-jre/Contents/Home/bin/java')
javac=Path('/tmp/claude-501/-Users-jeff-code-dive/7ef721df-a0bf-48ac-94b6-f7c0c8e766e7/scratchpad/jdk/jdk-17.0.20.1+1/Contents/Home/bin/javac')
jar=Path('/Users/jeff/code/dive-shipping-cache/sha256/7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d/tla2tools.jar');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(jar)=='7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d'
r=subprocess.run([str(javac),'-cp',str(jar),'-d',str(classes),str(base/'PeriodicProbe.java')],capture_output=True);(base/'compiler.stdout').write_bytes(r.stdout);(base/'compiler.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr.decode()
rows=[];cases=list(itertools.product([False,True],['0.0','0.2','0.9'],[False,True],[False,True],[False,True],['none','true','false'],[False,True]))
# Separate returning-error controls prove early return before PERIODIC/checkpoint/resume.
selection=[dict(liveness=l,ratio=r,growth=g,force=f,checkpoint=c,periodic=p,suspended=s,check_code=0) for l,r,g,f,c,p,s in cases]
selection += [dict(liveness=True,ratio=r,growth=True,force=f,checkpoint=True,periodic='false',suspended=True,check_code=2116) for r,f in itertools.product(['0.0','0.2','0.9','NaN'],[False,True])]
(base/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
for i,case in enumerate(selection):
 d=base/f'case-{i:03}';d.mkdir();meta=d/'meta';meta.mkdir()
 tla='---- MODULE Periodic ----\nEXTENDS Naturals,TLC\nVARIABLE x\nInit == x=0\nNext == x\'=1-x\nLive == []<>(x=1)\nHook == PrintT("DIVE_PERIODIC") /\\ '+('FALSE' if case['periodic']=='false' else 'TRUE')+'\n====\n'
 cfg='INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE\n'+('PROPERTY Live\n' if case['liveness'] else '')+('PERIODIC Hook\n' if case['periodic']!='none' else '')
 (d/'Periodic.tla').write_text(tla);(d/'Periodic.cfg').write_text(cfg)
 command=[str(java),'-cp',str(classes)+':'+str(jar),'PeriodicProbe',str(meta),case['ratio'],str(case['growth']).lower(),str(case['force']).lower(),str(case['checkpoint']).lower(),str(case['suspended']).lower(),str(case['check_code'])]
 try:r=subprocess.run(command,cwd=d,capture_output=True,timeout=10);code=r.returncode;stdout=r.stdout;stderr=r.stderr;timeout=False
 except subprocess.TimeoutExpired as e:code=None;stdout=e.stdout or b'';stderr=e.stderr or b'';timeout=True
 (d/'stdout').write_bytes(stdout);(d/'stderr').write_bytes(stderr);events=[line[6:] for line in stdout.decode().splitlines() if line.startswith('EVENT\t')];rows.append(dict(case=case,exit=code,timeout=timeout,events=events,stdout_sha256=sha(d/'stdout'),stderr_sha256=sha(d/'stderr')))
 if code!=0 or timeout:print('Captured failure row'+str(i),flush=True)
 if (i+1)%32==0:print('Captured '+str(i+1)+'/'+str(len(selection)),flush=True)
record={'oracle_sha256':sha(jar),'java_sha256':sha(java),'javac_sha256':sha(javac),'source_sha256':{'PeriodicProbe.java':sha(base/'PeriodicProbe.java'),'capture.py':sha(Path(__file__))},'scope':'Actual pinned ModelChecker.doPeriodicWork branch/order projection with controlled callback outcomes and observed ratio-update arguments. This is not actual graph growth, checkpoint persistence or full ordinary scheduling conformance.','rows':rows,'family_certified':False}
(base/'capture.json').write_text(json.dumps(record,indent=2)+'\n');print('Closed'+str(len(rows))+'; failures'+str(sum(row['exit']!=0 or row['timeout'] for row in rows)))
