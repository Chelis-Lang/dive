---- MODULE Prefix ----
EXTENDS Integers,TLC
VARIABLE x
Init == x \in 0..0
Gate(v) == TRUE
Next == Gate(x) /\ x' = 1 \div 0 /\ x' = IF x < 3 THEN x+1 ELSE x
Live == []<>(x >= 0)
Bad == <>(x=999)
Inv == x < 0
Hook == TRUE
====
