# Preserved first prefix adapter draft

Complete24 raw rows are retained. Known-error-before accidentally inherited
controlled finishAll rather than a real Worker error, and error-during used a
division error in every source. These rows earn no claimed error-timing agreement.
The inherited capture description also incorrectly said FastTool was unchanged;
ObservedTool is an explicit copy of pinned FastTool delegators with inherited
actual Tool.getNextStates body and an observation-only wrapper. Candidate1
corrects the driver selection/qualification without editing these raw outcomes.
