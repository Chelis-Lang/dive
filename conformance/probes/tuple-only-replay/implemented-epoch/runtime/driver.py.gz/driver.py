from pathlib import Path
import subprocess,json,hashlib,os,time,shutil,copy
root=Path('/Users/jeff/code/dive-tuple-only-replay-work');out=Path('/tmp/dive-tuple-only-replay-fresh-runtime');out.mkdir(exist_ok=False)
frozen=json.loads(Path('/tmp/dive-tuple-only-replay-retry1-frozen-source/source.json').read_text());gate=json.loads(Path('/tmp/dive-tuple-only-replay-retry1-gate-steps.json').read_text());assert len(gate)==8 and all(s['exit']==0 for s in gate)
env={**os.environ,'CARGO_TARGET_DIR':'/Users/jeff/code/dive-tuple-only-replay-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'2','DIVE_CACHE_DIR':'/Users/jeff/code/dive-tuple-only-replay-cache'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
steps=[]
def unchanged():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==frozen['source_commit']
 for rel,h in frozen['source_sha256'].items():assert sha(root/rel)==h,rel
 for rel,h in frozen['integrity_output_sha256'].items():assert sha(root/rel)==h,rel

def run(name,args,cwd=root):
 start=time.monotonic();p=out/'raw'/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.with_suffix('.stdout').open('w') as stdout,p.with_suffix('.stderr').open('w') as stderr:r=subprocess.run(args,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=600)
 row={'name':name,'command':args,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(p.with_suffix('.stdout')),'stderr_sha256':sha(p.with_suffix('.stderr'))};steps.append(row);(out/'steps.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'steps':steps},indent=2)+'\n')
 return row,p.with_suffix('.stdout')
unchanged()
for name,args in [('partitions',['python3','-I','scripts/check-test-partitions.py']),('focused',['cargo','test','--locked','-p','dive-trace','--test','runtime_names']),('cargo-guide',['cargo','run','--locked','-p','dive-api','--example','tuple_only_replay']),('release',['cargo','build','--release','--locked','-p','dive-cli','-p','dive-conformance'])]:
 row,p=run(name,args);assert row['exit']==0,name;unchanged()
 if name=='partitions':
  d=json.loads(p.read_text());assert d['disjoint_and_complete'] and d['ignored_tests']==0;(out/'inventory.json').write_text(json.dumps(d,indent=2)+'\n')
bins=out/'bins';bins.mkdir()
for name in ['dive','dive-conformance']:
 source=Path(env['CARGO_TARGET_DIR'])/'release'/name;dest=bins/name;shutil.copy2(source,dest);assert sha(source)==sha(dest);dest.chmod(0o555)
(out/'producer.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'source_tree':frozen['source_tree'],'source_index_sha256':sha(Path('/tmp/dive-tuple-only-replay-retry1-frozen-source/source.json')),'binary_sha256':{name:sha(bins/name) for name in ['dive','dive-conformance']},'family_certified':False},indent=2)+'\n')
positive=[('literal','','Tail(<<0,1>>)','',1),('definition','Pair == <<0,1>>','Tail(Pair)','',1),('tuple_if','','Tail(IF x=0 THEN <<0,1>> ELSE <<2,3>>)','',1),('concat','','<<0>> \\o <<1>>','',2),('subseq','','SubSeq(<<0,1>>,2,2)','',1),('wrapper','Drop(v) == Tail(v)','Drop(<<0,1>>)','',1),('let','','LET Pair == <<0,1>> IN Tail(Pair)','',1),('alias','Alias(v) == v','Alias(<<0,1>>)','CONSTANT Alias <- Tail\n',1)]
rows=[]
for name,defs,expr,config,value in positive:
 folder=out/'models'/name;folder.mkdir(parents=True);source=folder/'TupleReplay.tla';cfg=folder/'TupleReplay.cfg'
 source.write_text(f'---- MODULE TupleReplay ----\nEXTENDS Naturals, Sequences, TLC\nVARIABLE x\n{defs}\nInit == x=0\nNext == x\'=IF Len({expr})=1 THEN 1 ELSE 2\nInv == x=0\n====\n');cfg.write_text('INIT Init\nNEXT Next\nINVARIANT Inv\n'+config)
 for profile in ['tlc','dive']:
  for width in [1,4,8]:
   for store in ['fp','exact']:
    for chaos in [0,13]:
     label=f'{name}-{profile}-{width}-{store}-{chaos}';args=[str(bins/'dive'),'check',str(source),'--config',str(cfg),'--seed','0','--fp','0','--workers',str(width),'--store',store,'--chaos',str(chaos),'--output','json'];args+=['--compat=tlc'] if profile=='tlc' else []
     row,p=run(label+'-check',args);assert row['exit']==(12 if profile=='tlc' else 10);doc=json.loads(p.read_text());assert doc['verdict']=='invariant-violation' and doc['property']=='Inv';assert all(doc['statistics'][k]==2 for k in ['generated','distinct','depth']);assert doc['counterexample']['trace']['states'][1]['values']['x']==value
     for kind in ['original','mutant']:
      word=copy.deepcopy(doc)
      if kind=='mutant':word['counterexample']['trace']['states'][1]['values']['x']=3-value
      trace=folder/(label+'-'+kind+'.json');trace.write_text(json.dumps(word)+'\n');command=[str(bins/'dive'),'validate-trace',str(source),'--config',str(cfg),'--trace',str(trace),'--seed','0','--fp','0','--output','json'];command+=['--compat=tlc'] if profile=='tlc' else [];v,vr=run(label+'-'+kind,command);result=json.loads(vr.read_text());assert result['result']==('valid' if kind=='original' else 'invalid');rows.append({'model':name,'profile':profile,'workers':width,'store':store,'chaos':chaos,'kind':kind,'result':result['result']})
 print(name,'48replays closed',flush=True);unchanged()
assert len(rows)==384 and sum(r['result']=='valid' for r in rows)==192
(out/'replays.json').write_text(json.dumps({'rows':rows,'scope':'Eight proved tuple operands; actual and altered words are separate. No variable-stack or general namespace proof.'},indent=2)+'\n')
for corpus,listfile in [('examples','conformance/gates/cm1.txt'),('validation-smoke','conformance/gates/validation-smoke.txt')]:
 selection=[s.split('#',1)[0].strip() for s in (root/listfile).read_text().splitlines()];selection=[s for s in selection if s]
 args=[str(bins/'dive-conformance'),'run','--impl','dive','--impl-profile','tlc','--corpus',corpus,'--tier','all','--no-sany','--no-summary','--report-dir',str(out/('report-'+corpus)),'--dive-bin',str(bins/'dive'),'--workers','1,4,8']
 for model in selection:args+=['--filter',model]
 row,p=run('gate-'+corpus,args);assert row['exit']==0;reports=list((out/('report-'+corpus)).glob('*.json'));assert len(reports)==1;report=json.loads(reports[0].read_text());assert report['summary']['models_selected']==report['summary']['models']['agree']==len(selection)
 for model in report['models']:
  assert model['outcome']=='agree' and {r['workers'] for r in model['runs']}=={1,4,8};assert all(r['outcome']=='agree' and not r['diffs'] for r in model['runs'])
 unchanged()
(out/'closure.json').write_text(json.dumps({'source_commit':frozen['source_commit'],'all_consumers_closed':True,'steps':len(steps),'replays':len(rows),'family_certified':False},indent=2)+'\n');print('Fresh tuple-only CLI, Cargo, forged words and width gates closed',flush=True)
