# Tuple-only replay selection, original epoch

All thirty consumers closed against pinned TLC and immutable receiving binary 6ff7404. Six primary violations were reproduced. Current strict replay conservatively refuses all six cases; canonical replay accepts each actual next state and rejects its forged alternative.

The original driver labels the concat input x=1 as “actual”, but its Next produces x=2 because the concatenated tuple has length two. Preserve the original raw results: canonical replay correctly rejects x=1 and accepts x=2. This selection-label mistake is not a native validator bug, and the wrong labels cannot count as positive/negative support evidence. A corrected independent epoch must select x=2 as actual for concat; do not rewrite original rows or receipts.

Literal tuples, zero-arity tuple definitions and both-branch tuple IFs are candidates for an unevaluated shape proof. Strings and mixed tuple/string IFs remain refused under strict ordering. Existing predicate proof never evaluates operands, resolves scopes/bindings/redirects and separately checks all nested purity. Full trace replay must also audit assumptions, eagerly evaluated constants, configured roles, aliases and operator arguments; simply ignoring the global runtime-name marker is unsound. Variable stack support requires a separate source-wide inductive shape proof and must not rely on values supplied by the witness.

No code, feature ledger or family certification changed in this selection.
